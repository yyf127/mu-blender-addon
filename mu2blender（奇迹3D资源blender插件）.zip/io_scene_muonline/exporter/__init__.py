# -*- coding: utf-8 -*-
"""导出装配包 —— 把 Blender 场景数据写回 MU 格式(对应 OBJWriter 思路)。"""
