# -*- coding: utf-8 -*-
"""加解密算法包 —— 对应 TS 工程 src/crypto/。"""
