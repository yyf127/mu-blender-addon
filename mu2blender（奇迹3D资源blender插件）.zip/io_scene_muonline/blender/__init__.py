# -*- coding: utf-8 -*-
"""Blender 依赖层(bpy 算子/面板/属性)—— 对应 TS 工程的 Electron 壳与 UI。"""
