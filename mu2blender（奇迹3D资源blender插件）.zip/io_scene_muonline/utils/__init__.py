# -*- coding: utf-8 -*-
"""通用工具包 —— 对应 TS 工程 src/utils/。"""
