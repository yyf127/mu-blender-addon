# -*- coding: utf-8 -*-
"""格式读写包 —— 对应 TS 工程 src/terrain/formats/ 与 src/bmd-loader.ts 的数据层。"""
