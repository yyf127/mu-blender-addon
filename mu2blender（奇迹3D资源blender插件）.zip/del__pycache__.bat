@echo off
chcp 65001 >nul
echo 正在删除所有 __pycache__ 文件夹...

for /d /r . %%i in (__pycache__) do (
    if exist "%%i" (
        echo 删除: %%i
        rmdir /s /q "%%i"
    )
)

echo 操作完成。
pause