# muonline_map_editor.crypto - MU file encryption/decryption (incl. write-back).
