# -*- coding: utf-8 -*-
"""ModulusCryptor —— 对应 TS 工程 src/crypto/modulus-cryptor.ts。

ATT/MAP 文件若以 "ATT\\x01"/"MAP\\x01" 开头,则使用该容器:
  [0]      algorithm_2 (用于第二阶段,真实数据)
  [1]      algorithm_1 (用于第一阶段,恢复 key_2)
  [2..33]  第一阶段解密后得到 key_2(32B)
  [34..]   数据区(第二阶段用 key_2 解密)

算法编号(低 3 位): 0=TEA 1=ThreeWay 2=CAST5 3=RC5 4=RC6 5=MARS 6=IDEA 7=GOST

本实现完整移植 RC5/RC6/TEA(实际 .att/.map 最常见的三种);
其余算法按需可实现,当前抛 NotImplementedError。
"""
from .mars_cipher import MARSCipher
from .threeway_cipher import ThreeWayCipher
from .gost_cipher import GOSTCipher
from .idea_cipher import IDEACipher
from .cast5_cipher import CAST5Cipher

_MASK32 = 0xFFFFFFFF


def _rol(x, n):
    n &= 31
    return ((x << n) | (x >> (32 - n))) & _MASK32


def _ror(x, n):
    n &= 31
    return ((x >> n) | (x << (32 - n))) & _MASK32


# ---------------------------------------------------------------- RC5
class RC5Cipher:
    """RC5-32/16/16(块 8B),与 TS rc5-cipher.ts 一致。"""

    def __init__(self, key):
        self.block_size = 8
        self.rounds = 16
        self.s = self._expand_key(bytes(key)[:16])

    def get_block_size(self):
        return self.block_size

    def _expand_key(self, key):
        c = max(len(key) // 4, 1)
        l = [0] * c
        for i in range(len(key) - 1, -1, -1):
            l[i // 4] = ((l[i // 4] << 8) + key[i]) & _MASK32
        s_len = 2 * (self.rounds + 1)
        s = [0] * s_len
        s[0] = 0xB7E15163
        for i in range(1, s_len):
            s[i] = (s[i - 1] + 0x9E3779B9) & _MASK32
        a = b = 0
        ii = jj = 0
        v = 3 * max(s_len, c)
        for _ in range(v):
            a = s[ii] = _rol((s[ii] + a + b) & _MASK32, 3)
            b = l[jj] = _rol((l[jj] + a + b) & _MASK32, (a + b) & 31)
            ii = (ii + 1) % s_len
            jj = (jj + 1) % c
        return s

    def block_decrypt(self, data, length, out):
        for i in range(0, length, self.block_size):
            self._decrypt_block(data, i, out, i)

    def _decrypt_block(self, src, src_off, dst, dst_off):
        s = self.s
        a = (src[src_off] | (src[src_off + 1] << 8) |
             (src[src_off + 2] << 16) | (src[src_off + 3] << 24)) & _MASK32
        b = (src[src_off + 4] | (src[src_off + 5] << 8) |
             (src[src_off + 6] << 16) | (src[src_off + 7] << 24)) & _MASK32
        for i in range(self.rounds, 0, -1):
            b = (_ror((b - s[2 * i + 1]) & _MASK32, a & 31) ^ a) & _MASK32
            a = (_ror((a - s[2 * i]) & _MASK32, b & 31) ^ b) & _MASK32
        b = (b - s[1]) & _MASK32
        a = (a - s[0]) & _MASK32
        o = dst_off
        dst[o] = a & 255
        dst[o + 1] = (a >> 8) & 255
        dst[o + 2] = (a >> 16) & 255
        dst[o + 3] = (a >> 24) & 255
        dst[o + 4] = b & 255
        dst[o + 5] = (b >> 8) & 255
        dst[o + 6] = (b >> 16) & 255
        dst[o + 7] = (b >> 24) & 255


# ---------------------------------------------------------------- RC6
class RC6Cipher:
    """RC6-32/20/16(块 16B),与 TS rc6-cipher.ts 一致。"""

    def __init__(self, key):
        self.block_size = 16
        self.rounds = 20
        self.s = self._expand_key(bytes(key)[:16])

    def get_block_size(self):
        return self.block_size

    def _expand_key(self, key):
        c = max(len(key) // 4, 1)
        l = [0] * c
        for i in range(len(key) - 1, -1, -1):
            l[i // 4] = ((l[i // 4] << 8) + key[i]) & _MASK32
        s_len = 2 * self.rounds + 4
        s = [0] * s_len
        s[0] = 0xB7E15163
        for i in range(1, s_len):
            s[i] = (s[i - 1] + 0x9E3779B9) & _MASK32
        a = b = 0
        ii = jj = 0
        v = 3 * max(s_len, c)
        for _ in range(v):
            a = s[ii] = _rol((s[ii] + a + b) & _MASK32, 3)
            b = l[jj] = _rol((l[jj] + a + b) & _MASK32, (a + b) & 31)
            ii = (ii + 1) % s_len
            jj = (jj + 1) % c
        return s

    def block_decrypt(self, data, length, out):
        for i in range(0, length, self.block_size):
            self._decrypt_block(data, i, out, i)

    def _decrypt_block(self, src, src_off, dst, dst_off):
        s = self.s
        r = self.rounds
        a = int.from_bytes(src[src_off:src_off + 4], "little")
        b = int.from_bytes(src[src_off + 4:src_off + 8], "little")
        c = int.from_bytes(src[src_off + 8:src_off + 12], "little")
        d = int.from_bytes(src[src_off + 12:src_off + 16], "little")

        c = (c - s[2 * r + 3]) & _MASK32
        a = (a - s[2 * r + 2]) & _MASK32

        for i in range(r, 0, -1):
            # rotate (a,b,c,d) = (d,a,b,c)
            temp = d
            d = c
            c = b
            b = a
            a = temp

            u = _rol((d * ((2 * d + 1) & _MASK32)) & _MASK32, 5)
            t = _rol((b * ((2 * b + 1) & _MASK32)) & _MASK32, 5)
            c = (_ror((c - s[2 * i + 1]) & _MASK32, t & 31) ^ u) & _MASK32
            a = (_ror((a - s[2 * i]) & _MASK32, u & 31) ^ t) & _MASK32

        d = (d - s[1]) & _MASK32
        b = (b - s[0]) & _MASK32

        dst[dst_off:dst_off + 4] = a.to_bytes(4, "little")
        dst[dst_off + 4:dst_off + 8] = b.to_bytes(4, "little")
        dst[dst_off + 8:dst_off + 12] = c.to_bytes(4, "little")
        dst[dst_off + 12:dst_off + 16] = d.to_bytes(4, "little")


# ---------------------------------------------------------------- TEA
class TEACipher:
    """TEA(块 8B,64 轮),与 TS tea-cipher.ts 一致。"""

    def __init__(self, key):
        self.block_size = 8
        k = bytes(key)[:16]
        # C# TeaEngine (BouncyCastle) reads key & block words big-endian.
        self.key = [int.from_bytes(k[i * 4:i * 4 + 4], "big") for i in range(4)]
        self.delta = 0x9E3779B9

    def get_block_size(self):
        return self.block_size

    def block_decrypt(self, data, length, out):
        for i in range(0, length, self.block_size):
            self._decrypt_block(data, i, out, i)

    def _decrypt_block(self, src, src_off, dst, dst_off):
        k = self.key
        v0 = int.from_bytes(src[src_off:src_off + 4], "big")
        v1 = int.from_bytes(src[src_off + 4:src_off + 8], "big")
        s = (self.delta * 32) & _MASK32
        for _ in range(32):
            e0 = ((v0 << 4) + k[2]) & _MASK32
            e1 = (v0 + s) & _MASK32
            e2 = ((v0 >> 5) + k[3]) & _MASK32
            v1 = (v1 - (e0 ^ e1 ^ e2)) & _MASK32
            e0 = ((v1 << 4) + k[0]) & _MASK32
            e1 = (v1 + s) & _MASK32
            e2 = ((v1 >> 5) + k[1]) & _MASK32
            v0 = (v0 - (e0 ^ e1 ^ e2)) & _MASK32
            s = (s - self.delta) & _MASK32
        dst[dst_off:dst_off + 4] = v0.to_bytes(4, "big")
        dst[dst_off + 4:dst_off + 8] = v1.to_bytes(4, "big")


# ---------------------------------------------------------------- 未实现
class _UnsupportedCipher:
    def __init__(self, name):
        self._name = name

    def get_block_size(self):
        raise NotImplementedError(
            f"ModulusCryptor algorithm '{self._name}' not implemented; "
            "port from src/crypto/<name>-cipher.ts to use this .att/.map file."
        )

    def block_decrypt(self, data, length, out):
        self.get_block_size()


CIPHER_NAMES = ["TEA", "ThreeWay", "CAST5", "RC5", "RC6", "MARS", "IDEA", "GOST"]

_KEY1 = b"webzen#@!01webzen#@!01webzen#@!0"  # 32 字节


def _init_cipher(algorithm, key):
    alg = algorithm & 7
    if alg == 0:
        return TEACipher(key)
    if alg == 1:
        return ThreeWayCipher(key)
    if alg == 2:
        return CAST5Cipher(key)
    if alg == 3:
        return RC5Cipher(key)
    if alg == 4:
        return RC6Cipher(key)
    if alg == 5:
        return MARSCipher(key)
    if alg == 6:
        return IDEACipher(key)
    if alg == 7:
        return GOSTCipher(key)
    return _UnsupportedCipher(CIPHER_NAMES[alg])


def decrypt_modulus_cryptor(source: bytes) -> bytes:
    """解密 ModulusCryptor 容器,返回去掉 34 字节头后的明文。"""
    if len(source) < 34:
        raise ValueError("ModulusCryptor: source buffer too short")

    buf = bytearray(source)
    algorithm_1 = buf[1]
    algorithm_2 = buf[0]
    size = len(buf)
    data_size = size - 34

    # ---- 阶段一:用固定 KEY1 部分解密以恢复 key_2
    cipher1 = _init_cipher(algorithm_1, _KEY1)
    block_size = 1024 - (1024 % cipher1.get_block_size())

    if data_size > 4 * block_size:
        index = 2 + (data_size >> 1)
        block = bytearray(buf[index:index + block_size])
        cipher1.block_decrypt(block, len(block), block)
        buf[index:index + block_size] = block

    if data_size > block_size:
        # 尾部块
        index = size - block_size
        block = bytearray(buf[index:index + block_size])
        cipher1.block_decrypt(block, len(block), block)
        buf[index:index + block_size] = block
        # 头部块
        index = 2
        block = bytearray(buf[index:index + block_size])
        cipher1.block_decrypt(block, len(block), block)
        buf[index:index + block_size] = block

    # ---- 取出 key_2(字节 2..33)
    key2 = bytes(buf[2:34])

    # ---- 阶段二:用 key_2 解密真实数据
    cipher2 = _init_cipher(algorithm_2, key2)
    decrypt_size = data_size - (data_size % cipher2.get_block_size())

    if decrypt_size > 0:
        data_start = 34
        block = bytearray(buf[data_start:data_start + decrypt_size])
        cipher2.block_decrypt(block, len(block), block)
        buf[data_start:data_start + decrypt_size] = block

    return bytes(buf[34:])


def detect_and_decrypt(data: bytes) -> bytes:
    """自动识别并解密 ATT/MAP:
    - 以 b'ATT\\x01' / b'MAP\\x01' 开头 → ModulusCryptor(跳过 4 字节头)
    - 否则 → FileCryptor
    返回解密后的明文(ATT 尚未 XOR BUX)。
    """
    from .file_cryptor import decrypt_file_cryptor
    if len(data) > 4 and data[:4] in (b"ATT\x01", b"MAP\x01"):
        return decrypt_modulus_cryptor(data[4:])
    return decrypt_file_cryptor(data)
