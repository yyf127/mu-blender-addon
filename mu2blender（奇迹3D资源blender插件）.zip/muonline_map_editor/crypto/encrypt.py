# -*- coding: utf-8 -*-
"""ModulusCryptor / cipher ENCRYPTION side (write-back support).

The decryption-only classes live in the sibling *_cipher modules (ported from
the TS viewer and verified against the C# client).  This module attaches
`block_encrypt` to each cipher class -- the CryptoPP Encryption direction --
and implements `encrypt_modulus_cryptor`, the exact inverse of the C++
WorldEditor `MuCrypto::ModulusEncrypt`:

    buf = [algorithm_2][algorithm_1][key_2(32)] + plaintext
    1. data region [34..] encrypted with cipher2(key_2)
    2. head block buf[2..2+bs1] encrypted with cipher1(KEY1)
       (re-encrypts key_2 + the first bs1-32 bytes of the data region)
    3. tail block [size-bs1..size] and middle block [2+(ds>>1)..] for large data

Every encrypt is verified by round-trip:
    decrypt_modulus_cryptor(encrypt_modulus_cryptor(P)) == P
for every algorithm pair.
"""

_MASK32 = 0xFFFFFFFF

# The fixed first-phase key (32 bytes) used to hide key_2.
KEY1 = b"webzen#@!01webzen#@!01webzen#@!0"

from .modulus_cryptor import (RC5Cipher, RC6Cipher, TEACipher,
                              _init_cipher, _rol, _ror, _MASK32 as _M)
from .cast5_cipher import CAST5Cipher, _f1, _f2, _f3
from .gost_cipher import GOSTCipher, _rotl11, _sbox_substitute
from .idea_cipher import IDEACipher, _expand_key, _mul_mod, _add_mod
from .mars_cipher import MARSCipher, S_BOX
from .threeway_cipher import (ThreeWayCipher, _theta, _mu, _rho, _pi_gamma_pi)


def _encrypt_ecb(cipher, data, length, out):
    bs = cipher.block_size
    for i in range(0, length, bs):
        cipher._encrypt_block(data, i, out, i)


# ----------------------------------------------------------------------------
# TEA (block 8B, big-endian words).  The decrypt round uses the SAME key sum
# for both half-rounds, so encrypt advances s only after both updates.
# ----------------------------------------------------------------------------
def _tea_encrypt_block(self, src, src_off, dst, dst_off):
    k = self.key
    v0 = int.from_bytes(src[src_off:src_off + 4], "big")
    v1 = int.from_bytes(src[src_off + 4:src_off + 8], "big")
    s = 0
    delta = self.delta
    for _ in range(32):
        s = (s + delta) & _MASK32
        e0 = ((v1 << 4) + k[0]) & _MASK32
        e1 = (v1 + s) & _MASK32
        e2 = ((v1 >> 5) + k[1]) & _MASK32
        v0 = (v0 + (e0 ^ e1 ^ e2)) & _MASK32
        e0 = ((v0 << 4) + k[2]) & _MASK32
        e1 = (v0 + s) & _MASK32
        e2 = ((v0 >> 5) + k[3]) & _MASK32
        v1 = (v1 + (e0 ^ e1 ^ e2)) & _MASK32
    dst[dst_off:dst_off + 4] = v0.to_bytes(4, "big")
    dst[dst_off + 4:dst_off + 8] = v1.to_bytes(4, "big")


TEACipher.block_encrypt = _encrypt_ecb
TEACipher._encrypt_block = _tea_encrypt_block


# ----------------------------------------------------------------------------
# RC5 (block 8B, little-endian words)
# ----------------------------------------------------------------------------
def _rc5_encrypt_block(self, src, src_off, dst, dst_off):
    s = self.s
    a = (src[src_off] | (src[src_off + 1] << 8) |
         (src[src_off + 2] << 16) | (src[src_off + 3] << 24)) & _MASK32
    b = (src[src_off + 4] | (src[src_off + 5] << 8) |
         (src[src_off + 6] << 16) | (src[src_off + 7] << 24)) & _MASK32
    a = (a + s[0]) & _MASK32
    b = (b + s[1]) & _MASK32
    for i in range(1, self.rounds + 1):
        a = (_rol((a ^ b) & _MASK32, b & 31) + s[2 * i]) & _MASK32
        b = (_rol((b ^ a) & _MASK32, a & 31) + s[2 * i + 1]) & _MASK32
    o = dst_off
    dst[o] = a & 255
    dst[o + 1] = (a >> 8) & 255
    dst[o + 2] = (a >> 16) & 255
    dst[o + 3] = (a >> 24) & 255
    dst[o + 4] = b & 255
    dst[o + 5] = (b >> 8) & 255
    dst[o + 6] = (b >> 16) & 255
    dst[o + 7] = (b >> 24) & 255


RC5Cipher.block_encrypt = _encrypt_ecb
RC5Cipher._encrypt_block = _rc5_encrypt_block


# ----------------------------------------------------------------------------
# RC6 (block 16B, little-endian words)
# ----------------------------------------------------------------------------
def _rc6_encrypt_block(self, src, src_off, dst, dst_off):
    s = self.s
    r = self.rounds
    a = int.from_bytes(src[src_off:src_off + 4], "little")
    b = int.from_bytes(src[src_off + 4:src_off + 8], "little")
    c = int.from_bytes(src[src_off + 8:src_off + 12], "little")
    d = int.from_bytes(src[src_off + 12:src_off + 16], "little")
    b = (b + s[0]) & _MASK32
    d = (d + s[1]) & _MASK32
    for i in range(1, r + 1):
        t = _rol((b * ((2 * b + 1) & _MASK32)) & _MASK32, 5)
        u = _rol((d * ((2 * d + 1) & _MASK32)) & _MASK32, 5)
        a = (_rol((a ^ t) & _MASK32, u & 31) + s[2 * i]) & _MASK32
        c = (_rol((c ^ u) & _MASK32, t & 31) + s[2 * i + 1]) & _MASK32
        a, b, c, d = b, c, d, a
    a = (a + s[2 * r + 2]) & _MASK32
    c = (c + s[2 * r + 3]) & _MASK32
    dst[dst_off:dst_off + 4] = a.to_bytes(4, "little")
    dst[dst_off + 4:dst_off + 8] = b.to_bytes(4, "little")
    dst[dst_off + 8:dst_off + 12] = c.to_bytes(4, "little")
    dst[dst_off + 12:dst_off + 16] = d.to_bytes(4, "little")


RC6Cipher.block_encrypt = _encrypt_ecb
RC6Cipher._encrypt_block = _rc6_encrypt_block


# ----------------------------------------------------------------------------
# CAST5 (block 8B, big-endian words).  Ported decipher runs T_rounds..T_1 and
# returns (ri,li) with plaintext = (ri,li); encrypt runs T_1..T_rounds on the
# swapped halves.
# ----------------------------------------------------------------------------
def _cast5_encipher(self, l, r):
    li = l & _MASK32
    ri = r & _MASK32
    for i in range(1, self.rounds + 1):
        lp = li
        rp = ri
        # inverse round transform T_i^-1: (l, r) -> (r ^ f(l), l)
        li = (rp ^ _f1(lp, self.km[i], self.kr[i])) & _MASK32 if i in (1, 4, 7, 10, 13, 16) else 0
        if i in (2, 5, 8, 11, 14):
            li = (rp ^ _f2(lp, self.km[i], self.kr[i])) & _MASK32
        elif i not in (1, 4, 7, 10, 13, 16):
            li = (rp ^ _f3(lp, self.km[i], self.kr[i])) & _MASK32
        ri = lp
    return li, ri


def _cast5_encrypt_block(self, src, src_off, dst, dst_off):
    p0 = int.from_bytes(src[src_off:src_off + 4], 'big')
    p1 = int.from_bytes(src[src_off + 4:src_off + 8], 'big')
    c0, c1 = self._cast5_encipher(p1, p0)
    dst[dst_off:dst_off + 4] = c0.to_bytes(4, 'big')
    dst[dst_off + 4:dst_off + 8] = c1.to_bytes(4, 'big')


CAST5Cipher.block_encrypt = _encrypt_ecb
CAST5Cipher._encrypt_block = _cast5_encrypt_block
CAST5Cipher._cast5_encipher = _cast5_encipher


# ----------------------------------------------------------------------------
# GOST (block 8B, little-endian).  CryptoPP GOST::Enc: 3x forward keys k0..k7
# then reverse k7..k0, output written as (n2, n1).
# ----------------------------------------------------------------------------
def _patch_gost(cls):
    orig_init = cls.__init__

    def __init__(self, key):
        orig_init(self, key)
        k = bytes(key)[:32]
        self.key_words = [int.from_bytes(k[i * 4:i * 4 + 4], 'little')
                          for i in range(8)]

    cls.__init__ = __init__

    def _encrypt_block(self, src, src_off, dst, dst_off):
        n1 = int.from_bytes(src[src_off:src_off + 4], 'little')
        n2 = int.from_bytes(src[src_off + 4:src_off + 8], 'little')
        k = self.key_words
        f = lambda x: _rotl11(_sbox_substitute(x & _MASK32))
        for _ in range(3):
            n2 ^= f(n1 + k[0]); n1 ^= f(n2 + k[1])
            n2 ^= f(n1 + k[2]); n1 ^= f(n2 + k[3])
            n2 ^= f(n1 + k[4]); n1 ^= f(n2 + k[5])
            n2 ^= f(n1 + k[6]); n1 ^= f(n2 + k[7])
        n2 ^= f(n1 + k[7]); n1 ^= f(n2 + k[6])
        n2 ^= f(n1 + k[5]); n1 ^= f(n2 + k[4])
        n2 ^= f(n1 + k[3]); n1 ^= f(n2 + k[2])
        n2 ^= f(n1 + k[1]); n1 ^= f(n2 + k[0])
        dst[dst_off:dst_off + 4] = n2.to_bytes(4, 'little')
        dst[dst_off + 4:dst_off + 8] = n1.to_bytes(4, 'little')

    cls._encrypt_block = _encrypt_block
    cls.block_encrypt = _encrypt_ecb


_patch_gost(GOSTCipher)


# ----------------------------------------------------------------------------
# IDEA (block 8B, big-endian; forward keys, same round body)
# ----------------------------------------------------------------------------
def _idea_round(K, src, src_off, dst, dst_off):
    x0 = int.from_bytes(src[src_off:src_off + 2], 'big')
    x1 = int.from_bytes(src[src_off + 2:src_off + 4], 'big')
    x2 = int.from_bytes(src[src_off + 4:src_off + 6], 'big')
    x3 = int.from_bytes(src[src_off + 6:src_off + 8], 'big')
    p = 0

    for _round in range(8):
        x0 = _mul_mod(x0, K[p]); p += 1
        x1 = _add_mod(x1, K[p]); p += 1
        x2 = _add_mod(x2, K[p]); p += 1
        x3 = _mul_mod(x3, K[p]); p += 1

        t0 = x1
        t1 = x2
        x2 = x2 ^ x0
        x1 = x1 ^ x3

        x2 = _mul_mod(x2, K[p]); p += 1
        x1 = _add_mod(x1, x2)
        x1 = _mul_mod(x1, K[p]); p += 1
        x2 = _add_mod(x2, x1)

        x0 = x0 ^ x1
        x3 = x3 ^ x2
        x1 = x1 ^ t1
        x2 = x2 ^ t0

    X1 = _mul_mod(x0, K[p]); p += 1
    X2 = _add_mod(x2, K[p]); p += 1
    X3 = _add_mod(x1, K[p]); p += 1
    X4 = _mul_mod(x3, K[p]); p += 1

    dst[dst_off:dst_off + 2] = X1.to_bytes(2, 'big')
    dst[dst_off + 2:dst_off + 4] = X2.to_bytes(2, 'big')
    dst[dst_off + 4:dst_off + 6] = X3.to_bytes(2, 'big')
    dst[dst_off + 6:dst_off + 8] = X4.to_bytes(2, 'big')


def _patch_idea(cls):
    orig_init = cls.__init__

    def __init__(self, key):
        orig_init(self, key)
        self.encrypt_keys = _expand_key(bytes(key)[:16])

    cls.__init__ = __init__

    def _encrypt_block(self, src, src_off, dst, dst_off):
        _idea_round(self.encrypt_keys, src, src_off, dst, dst_off)

    cls._encrypt_block = _encrypt_block
    cls.block_encrypt = _encrypt_ecb


_patch_idea(IDEACipher)


# ----------------------------------------------------------------------------
# MARS (block 16B, little-endian) -- CryptoPP MARS::Enc::ProcessAndXorBlock
# ----------------------------------------------------------------------------
def _mars_encrypt_block(self, src, src_off, dst, dst_off):
    K = self.lKey
    S = S_BOX

    def S0(x):
        return S[x & 0xff]

    def S1(x):
        return S[(x & 0xff) + 256]

    def rol(x, n):
        n &= 31
        return ((x << n) | (x >> (32 - n))) & _MASK32

    def ror(x, n):
        n &= 31
        return ((x >> n) | (x << (32 - n))) & _MASK32

    a = int.from_bytes(src[src_off:src_off + 4], 'little')
    b = int.from_bytes(src[src_off + 4:src_off + 8], 'little')
    c = int.from_bytes(src[src_off + 8:src_off + 12], 'little')
    d = int.from_bytes(src[src_off + 12:src_off + 16], 'little')

    a = (a + K[0]) & _MASK32
    b = (b + K[1]) & _MASK32
    c = (c + K[2]) & _MASK32
    d = (d + K[3]) & _MASK32

    # backward mixing (8 rounds)
    for i in range(8):
        b = ((b ^ S0(a)) + S1(a >> 8)) & _MASK32
        c = (c + S0(a >> 16)) & _MASK32
        a = ror(a, 24)
        d = (d ^ S1(a)) & _MASK32
        a = (a + (d if (i % 4 == 0) else 0)) & _MASK32
        a = (a + (b if (i % 4 == 1) else 0)) & _MASK32
        a, b, c, d = b, c, d, a

    # forward keyed rounds (16)
    for i in range(16):
        t = rol(a, 13)
        r = rol((t * K[2 * i + 5]) & _MASK32, 10)
        m = (a + K[2 * i + 4]) & _MASK32
        l = rol((S[m & 0x1ff] ^ ror(r, 5) ^ r) & _MASK32, r & 31)
        c = (c + rol(m, ror(r, 5) & 31)) & _MASK32
        if i < 8:
            b = (b + l) & _MASK32
            d = (d ^ r) & _MASK32
        else:
            d = (d + l) & _MASK32
            b = (b ^ r) & _MASK32
        a, b, c, d = b, c, d, t

    # forward mixing (8 rounds)
    for i in range(8):
        a = (a - (d if (i % 4 == 2) else 0)) & _MASK32
        a = (a - (b if (i % 4 == 3) else 0)) & _MASK32
        b = (b ^ S1(a)) & _MASK32
        c = (c - S0(a >> 24)) & _MASK32
        t = rol(a, 24)
        d = ((d - S1(a >> 16)) ^ S0(t)) & _MASK32
        a, b, c, d = b, c, d, t

    a = (a - K[36]) & _MASK32
    b = (b - K[37]) & _MASK32
    c = (c - K[38]) & _MASK32
    d = (d - K[39]) & _MASK32

    dst[dst_off:dst_off + 4] = a.to_bytes(4, 'little')
    dst[dst_off + 4:dst_off + 8] = b.to_bytes(4, 'little')
    dst[dst_off + 8:dst_off + 12] = c.to_bytes(4, 'little')
    dst[dst_off + 12:dst_off + 16] = d.to_bytes(4, 'little')


MARSCipher._encrypt_block = _mars_encrypt_block
MARSCipher.block_encrypt = _encrypt_ecb


# ----------------------------------------------------------------------------
# ThreeWay (block 12B) -- CryptoPP ThreeWay::Enc: big-endian I/O,
# rc = START_E = 0x0000000B, no mu, raw key words.
# ----------------------------------------------------------------------------
def _patch_threeway(cls):
    orig_init = cls.__init__

    def __init__(self, key):
        orig_init(self, key)
        k = bytes(key)[:12]
        self.encrypt_keys = [0] * 3
        for i in range(3):
            self.encrypt_keys[i] = ((k[4 * i + 3] |
                                     (k[4 * i + 2] << 8) |
                                     (k[4 * i + 1] << 16) |
                                     (k[4 * i] << 24))) & _MASK32

    cls.__init__ = __init__

    def _encrypt_block(self, src, src_off, dst, dst_off):
        k = self.encrypt_keys
        t = {
            'a0': int.from_bytes(src[src_off:src_off + 4], 'big'),
            'a1': int.from_bytes(src[src_off + 4:src_off + 8], 'big'),
            'a2': int.from_bytes(src[src_off + 8:src_off + 12], 'big'),
        }
        rc = 0x00000B0B  # START_E (verified against CryptoPP 3wayval.dat)
        for _i in range(cls.ROUNDS):
            t['a0'] = (t['a0'] ^ k[0] ^ ((rc << 16) & _MASK32)) & _MASK32
            t['a1'] = (t['a1'] ^ k[1]) & _MASK32
            t['a2'] = (t['a2'] ^ k[2] ^ rc) & _MASK32
            _rho(t)
            rc = (rc << 1) & _MASK32
            if rc & 0x10000:
                rc ^= 0x11011
            rc &= 0xFFFF
        t['a0'] = (t['a0'] ^ k[0] ^ ((rc << 16) & _MASK32)) & _MASK32
        t['a1'] = (t['a1'] ^ k[1]) & _MASK32
        t['a2'] = (t['a2'] ^ k[2] ^ rc) & _MASK32
        _theta(t)

        dst[dst_off:dst_off + 4] = t['a0'].to_bytes(4, 'big')
        dst[dst_off + 4:dst_off + 8] = t['a1'].to_bytes(4, 'big')
        dst[dst_off + 8:dst_off + 12] = t['a2'].to_bytes(4, 'big')

    cls._encrypt_block = _encrypt_block
    cls.block_encrypt = _encrypt_ecb


_patch_threeway(ThreeWayCipher)


# ----------------------------------------------------------------------------
# ModulusCryptor container encryption (inverse of the C++ ModulusEncrypt)
# ----------------------------------------------------------------------------
def _encrypt_range(cipher, buf, start, end):
    bs = cipher.block_size
    for i in range(start, end, bs):
        cipher._encrypt_block(buf, i, buf, i)


def encrypt_modulus_cryptor(plaintext, algorithm_2=None, algorithm_1=None,
                            key_2=None):
    """Encrypt plaintext into a ModulusCryptor container (34-byte overhead).

    Matches the C++ WorldEditor MuCrypto::ModulusEncrypt byte-for-byte.
    `algorithm_2`/`algorithm_1` default to 0 (TEA); `key_2` defaults to KEY1.
    """
    if not plaintext:
        raise ValueError("ModulusCryptor: empty plaintext")
    data_size = len(plaintext)
    if algorithm_2 is None:
        algorithm_2 = 0
    if algorithm_1 is None:
        algorithm_1 = 0
    if key_2 is None:
        key_2 = KEY1
    key_2 = bytes(key_2)[:32]

    # Write the algorithm bytes EXACTLY as given (the original game files store
    # e.g. 0x0a for the data cipher; only the low 3 bits select the cipher).
    buf = bytearray([algorithm_2 & 0xFF, algorithm_1 & 0xFF])
    buf += key_2
    buf += plaintext

    cipher2 = _init_cipher(algorithm_2, key_2)
    bs2 = cipher2.get_block_size()
    enc_len = data_size - (data_size % bs2)
    if enc_len > 0:
        _encrypt_range(cipher2, buf, 34, 34 + enc_len)

    cipher1 = _init_cipher(algorithm_1, KEY1)
    bs1 = 1024 - (1024 % cipher1.get_block_size())
    if data_size > bs1:
        _encrypt_range(cipher1, buf, 2, 2 + bs1)               # head
        _encrypt_range(cipher1, buf, len(buf) - bs1, len(buf))  # tail
    if data_size > 4 * bs1:
        mid = 2 + (data_size >> 1)
        _encrypt_range(cipher1, buf, mid, mid + bs1)            # middle

    return bytes(buf)


def encrypt_att_map(plaintext, algorithm_2=None, algorithm_1=None, key_2=None,
                    magic=b"ATT\x01"):
    """Encrypt a plain ATT/MAP payload into the on-disk form:
    [magic(4)] + ModulusCryptor container.  For ATT the caller must pass the
    BUX-masked bytes (the file stores BUX-masked data)."""
    return magic + encrypt_modulus_cryptor(plaintext, algorithm_2,
                                           algorithm_1, key_2)
