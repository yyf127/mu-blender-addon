# -*- coding: utf-8 -*-
"""
Diagnostic: print the actual terrain UV shift for the CURRENTLY LOADED map.
Run inside Blender (Scripting workspace -> new text -> paste this -> Run Script)
AFTER importing World1 via the addon panel.

Expected (after the +X 2-tile ground-texture fix is applied):
    XOFFSET_TILES = {1: 2}
    cell(tx,5) minU ~= (tx-2)*bw     (i.e. 0.75, 1.00, 1.25 for tx=5,6,7)
    NOT ~= tx*bw                     (which would be the old no-offset 1.25,1.5,1.75)

If you see the no-offset values, the running Blender did NOT load the new code
or the terrain was NOT re-imported after the code update.
"""
import bpy
from muonline_map_editor.core import terrain_build as TB

print("=== MU TERRAIN UV DIAG ===")
print("MAP_OBJECT_X_OFFSET_TILES =", TB.MAP_OBJECT_X_OFFSET_TILES)

obj = bpy.data.objects.get("MU_Terrain")
print("terrain object found:", obj is not None)
if obj is None:
    print("-> The map was NOT imported by this addon (no MU_Terrain object).")
    raise SystemExit

me = obj.data
uv = me.uv_layers.get("uv1")
V = TB.TERRAIN_SIZE + 1
bw = 64.0 / 256.0
rows = {}
for poly in me.polygons:
    if poly.material_index == 0:
        continue
    ls = poly.loop_start
    lt = poly.loop_total
    tx = min(me.loops[ls + k].vertex_index % V for k in range(lt))
    ty = min(me.loops[ls + k].vertex_index // V for k in range(lt))
    if tx in (5, 6, 7, 8) and ty == 5:
        u = min(uv.data[ls + k].uv[0] for k in range(lt))
        rows.setdefault(tx, u)

if not rows:
    print("-> no textured cell found; check that tiles were loaded.")
    raise SystemExit

for tx in sorted(rows):
    print("cell(%d,5) minU = %.4f | -2tiles=%.4f | no-offset=%.4f" % (
        tx, rows[tx], (tx - 2) * bw, tx * bw))

off = all(abs(rows.get(tx, 0) - (tx - 2) * bw) < 0.01 for tx in (5, 6, 7))
print("=> SHIFTED by 2 tiles (new code applied):", off)
print("   if False, either old code is loaded (restart + delete __pycache__)")
print("   or the terrain was NOT re-imported after updating the code.")
