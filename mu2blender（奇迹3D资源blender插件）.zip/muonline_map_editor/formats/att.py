# -*- coding: utf-8 -*-
"""地形属性 ATT —— 对应 TS 工程 src/terrain/formats/ATTReader.ts。

布局(解密并 XOR BUX 后):
    [0] version | [1] index | [2] width | [3] height
    [4..] terrainWall[256*256]  (标准版 u8;扩展版 u16)
"""

from dataclasses import dataclass, field
from array import array

from .binary import BinaryReader
from ..crypto.file_cryptor import xor_bux_mask
from ..crypto.modulus_cryptor import detect_and_decrypt

TERRAIN_SIZE = 256


class TWFlags:
    """与 ATTReader.ts / TWFlags.cs 一致的地形标志位。"""
    None_ = 0x0000
    SafeZone = 0x0001
    Character = 0x0002
    NoMove = 0x0004
    NoGround = 0x0008
    Water = 0x0010
    Action = 0x0020
    Height = 0x0040
    CameraUp = 0x0080
    NoAttackZone = 0x0100
    Att1 = 0x0200
    Att2 = 0x0400
    Att3 = 0x0800
    Att4 = 0x1000
    Att5 = 0x2000
    Att6 = 0x4000
    Att7 = 0x8000


@dataclass
class TerrainAttributeData:
    version: int = 0
    index: int = 0
    width: int = 255
    height: int = 255
    is_extended: bool = False
    terrain_wall: list = field(default_factory=list)   # 65536 个 int


def read_att(buffer: bytes) -> TerrainAttributeData:
    u8 = detect_and_decrypt(buffer)
    u8 = xor_bux_mask(u8)

    expected_std = TERRAIN_SIZE * TERRAIN_SIZE + 4
    expected_ext = TERRAIN_SIZE * TERRAIN_SIZE * 2 + 4
    if len(u8) not in (expected_std, expected_ext):
        raise ValueError(
            f"ATT: unexpected size {len(u8)} (expected {expected_std} or {expected_ext})"
        )

    is_extended = len(u8) == expected_ext
    br = BinaryReader(u8)
    version = br.read_u8()
    index = br.read_u8()
    width = br.read_u8()
    height = br.read_u8()

    terrain_wall = array("H", (0 for _ in range(TERRAIN_SIZE * TERRAIN_SIZE)))
    if is_extended:
        for i in range(TERRAIN_SIZE * TERRAIN_SIZE):
            terrain_wall[i] = br.read_u16()
    else:
        for i in range(TERRAIN_SIZE * TERRAIN_SIZE):
            terrain_wall[i] = br.read_u8()

    return TerrainAttributeData(
        version=version, index=index, width=width, height=height,
        is_extended=is_extended, terrain_wall=list(terrain_wall),
    )
