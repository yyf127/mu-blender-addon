# -*- coding: utf-8 -*-
"""地图物件表 EncTerrain*.obj —— 对应 TS 工程 src/terrain/formats/OBJReader.ts / OBJWriter.ts。

布局(FileCryptor 解密后):
    [0] version | [1] mapNumber | [2..3] count(s16)
    记录 xN(版本相关长度):
        type(s16) | pos(f32x3) | angle(f32x3) | scale(f32) = 30B 基础
        v1=32B(v0+2B) v2=33B(v1+1B) v3=45B(v2+12B 光照) v4=46B v5=54B
"""

from dataclasses import dataclass, field

from .binary import BinaryReader, BinaryWriter
from ..crypto.file_cryptor import decrypt_file_cryptor, encrypt_file_cryptor

# 版本 → 每条记录字节数(与 MapObject.cs / OBJReader.ts 一致)
OBJ_RECORD_SIZES = {0: 30, 1: 32, 2: 33, 3: 45, 4: 46, 5: 54}
BASE_RECORD = 30


@dataclass
class MapObject:
    type: int = 0
    position: tuple = (0.0, 0.0, 0.0)     # (x,y,z)
    angle: tuple = (0.0, 0.0, 0.0)        # (x,y,z) 弧度
    scale: float = 1.0
    extra: bytes = b""                    # 版本特有的额外字节


@dataclass
class OBJData:
    version: int = 0
    map_number: int = 0
    objects: list = field(default_factory=list)   # [MapObject]


def read_obj(buffer: bytes) -> OBJData:
    u8 = decrypt_file_cryptor(buffer)
    br = BinaryReader(u8)
    version = br.read_u8()
    map_number = br.read_u8()
    count = br.read_s16()

    obj_size = OBJ_RECORD_SIZES.get(version)
    if obj_size is None:
        raise ValueError(f"OBJ: unsupported version {version}")

    objects = []
    for _ in range(count):
        type_ = br.read_s16()
        px, py, pz = br.read_vec3()
        ax, ay, az = br.read_vec3()
        scale = br.read_f32()
        extra_len = obj_size - BASE_RECORD
        extra = br.read(extra_len) if extra_len > 0 else b""
        objects.append(MapObject(type=type_, position=(px, py, pz),
                                 angle=(ax, ay, az), scale=scale, extra=extra))
    return OBJData(version=version, map_number=map_number, objects=objects)


def write_obj(data: OBJData) -> bytes:
    obj_size = OBJ_RECORD_SIZES.get(data.version)
    if obj_size is None:
        raise ValueError(f"OBJ: unsupported version {data.version}")
    if len(data.objects) > 0x7FFF:
        raise ValueError(f"OBJ: too many objects ({len(data.objects)})")

    br = BinaryWriter()
    br.write_u8(data.version & 0xFF)
    br.write_u8(data.map_number & 0xFF)
    br.write_s16(len(data.objects))

    for obj in data.objects:
        br.write_s16(obj.type)
        br.write_vec3(obj.position)
        br.write_vec3(obj.angle)
        br.write_f32(obj.scale)
        extra_len = obj_size - BASE_RECORD
        if extra_len > 0:
            extra = bytes(obj.extra)[:extra_len]
            br.write(extra.ljust(extra_len, b"\x00"))

    return encrypt_file_cryptor(br.getvalue())
