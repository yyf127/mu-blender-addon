# -*- coding: utf-8 -*-
"""地形贴图映射 MAP —— 对应 TS 工程 src/terrain/formats/MAPReader.ts。

布局(解密后):
    [0] version | [1] mapNumber
    [2..] layer1[65536] | layer2[65536] | alpha[65536]
"""

from dataclasses import dataclass, field

from .binary import BinaryReader
from .att import TERRAIN_SIZE
from ..crypto.modulus_cryptor import detect_and_decrypt


@dataclass
class TerrainMappingData:
    version: int = 0
    map_number: int = 0
    layer1: list = field(default_factory=list)   # 65536 基础贴图索引
    layer2: list = field(default_factory=list)   # 65536 叠加贴图索引
    alpha: list = field(default_factory=list)    # 65536 混合系数 0-255


def read_map(buffer: bytes) -> TerrainMappingData:
    u8 = detect_and_decrypt(buffer)
    tile_count = TERRAIN_SIZE * TERRAIN_SIZE
    br = BinaryReader(u8)
    version = br.read_u8()
    map_number = br.read_u8()
    layer1 = [br.read_u8() for _ in range(tile_count)]
    layer2 = [br.read_u8() for _ in range(tile_count)]
    alpha = [br.read_u8() for _ in range(tile_count)]
    return TerrainMappingData(version=version, map_number=map_number,
                              layer1=layer1, layer2=layer2, alpha=alpha)
