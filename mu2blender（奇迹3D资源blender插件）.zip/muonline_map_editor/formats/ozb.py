# -*- coding: utf-8 -*-
"""OZB 高度图/光照图 —— 对应 TS 工程 src/terrain/formats/OZBReader.ts 与 C# OZBReader.cs。

OZB 本质是带 "BM6"/"BM8"/"BM\\x18" 文件类型标识的标准 BMP 封装:
    [0..2]  fileType("BM6" 24bit RGB / "BM8" 或 "BM\x18" 8bit 调色板)
    [3]     version
    [4..]   BMP 文件头(14B)+信息头(40B)
BM6: 数据区每像素 B,G,R,3 字节(RGB)
BM8: 数据区每像素 1 字节灰度强度(R=G=B=该值)
"""

from dataclasses import dataclass, field

from .binary import BinaryReader


@dataclass
class OZBData:
    width: int = 0
    height: int = 0
    data: list = field(default_factory=list)   # RGBA 平坦数组(width*height*4)


def read_ozb(buffer: bytes) -> OZBData:
    br = BinaryReader(buffer)
    file_type = br.read(3).decode("ascii", errors="replace")
    version = br.read_u8()

    # BMP 文件头(14B)
    br.read_s16()   # bmp type
    br.read_s32()   # bmp size
    br.read_s16()   # res1
    br.read_s16()   # res2
    br.read_s32()   # offBits

    # BMP 信息头(40B)
    br.read_s32()   # biSize
    width = br.read_s32()
    height = br.read_s32()
    br.read_s16()   # planes
    bit_count = br.read_s16()
    br.read(24)     # compression/sizeImage/... 等

    pixel_count = width * height
    if file_type in ("BM8", "BM\x18"):
        # 跳过调色板(4B 颜色 * 256)
        br.read(1024)
        data = [0] * (pixel_count * 4)
        for i in range(pixel_count):
            v = br.read_u8()
            data[i * 4] = v
            data[i * 4 + 1] = 0
            data[i * 4 + 2] = 0
            data[i * 4 + 3] = 255
        return OZBData(width=width, height=height, data=data)

    if file_type == "BM6":
        data = [0] * (pixel_count * 4)
        for i in range(pixel_count):
            b = br.read_u8()
            g = br.read_u8()
            r = br.read_u8()
            data[i * 4] = r
            data[i * 4 + 1] = g
            data[i * 4 + 2] = b
            data[i * 4 + 3] = 255
        return OZBData(width=width, height=height, data=data)

    raise ValueError(f'OZB: unknown file type "{file_type}" (bitCount={bit_count})')
