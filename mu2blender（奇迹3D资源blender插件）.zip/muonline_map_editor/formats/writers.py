# -*- coding: utf-8 -*-
"""Write-back helpers for the map editor (ATT / MAP / OZB / OZJ).

Layouts mirror the readers in att.py / mapdata.py / ozb.py and the C++ / C#
references:

    .att -> "ATT\\x01" + ModulusCryptor( xorBux( plain ) )
    .map -> "MAP\\x01" + ModulusCryptor( plain )
    .ozb -> "BM6"/"BM8" + version + standard-BMP-file + pixel data

The ModulusCryptor encryption lives in crypto.encrypt (byte-identical with
the original game files, verified on World1/3/10/11/101/103/113 ...).
"""

import struct

from ..crypto.encrypt import encrypt_modulus_cryptor
from ..crypto.file_cryptor import xor_bux_mask, encrypt_file_cryptor
from .att import TERRAIN_SIZE, TerrainAttributeData
from .mapdata import TerrainMappingData


# ---------------------------------------------------------------------------
# ATT
# ---------------------------------------------------------------------------
def serialize_att(att: TerrainAttributeData) -> bytes:
    """Plaintext ATT payload (version/index/width/height + walls)."""
    out = bytearray()
    out.append(att.version & 0xFF)
    out.append(att.index & 0xFF)
    out.append(att.width & 0xFF)
    out.append(att.height & 0xFF)
    walls = att.terrain_wall
    if att.is_extended:
        for w in walls:
            out += struct.pack("<H", w & 0xFFFF)
    else:
        for w in walls:
            out.append(w & 0xFF)
    return bytes(out)


def write_att(att: TerrainAttributeData, algorithm_2=None, algorithm_1=None,
              key_2=None, use_modulus=True) -> bytes:
    """Encode an ATT payload to on-disk bytes (BUX-masked + encrypted)."""
    payload = xor_bux_mask(serialize_att(att))
    if use_modulus:
        return b"ATT\x01" + encrypt_modulus_cryptor(payload, algorithm_2,
                                                    algorithm_1, key_2)
    return encrypt_file_cryptor(payload)


# ---------------------------------------------------------------------------
# MAP
# ---------------------------------------------------------------------------
def serialize_map(mapping: TerrainMappingData) -> bytes:
    """Plaintext MAP payload (version + mapNumber + layer1/layer2/alpha)."""
    out = bytearray()
    out.append(mapping.version & 0xFF)
    out.append(mapping.map_number & 0xFF)
    out += bytes(mapping.layer1)
    out += bytes(mapping.layer2)
    out += bytes(mapping.alpha)
    return bytes(out)


def write_map(mapping: TerrainMappingData, algorithm_2=None, algorithm_1=None,
              key_2=None, use_modulus=True) -> bytes:
    """Encode a MAP payload to on-disk bytes (no BUX)."""
    payload = serialize_map(mapping)
    if use_modulus:
        return b"MAP\x01" + encrypt_modulus_cryptor(payload, algorithm_2,
                                                    algorithm_1, key_2)
    return encrypt_file_cryptor(payload)


# ---------------------------------------------------------------------------
# OZB (BMP container)
# ---------------------------------------------------------------------------
def _make_bmp(file_type: str, version: int, width: int, height: int,
              bit_count: int, pixel_data: bytes, palette: bytes = b"",
              xppm: int = 0, yppm: int = 0) -> bytes:
    """Build an OZB file: "BMx" + version + standard BMP + data.

    Standard BMP (starting at "BM"): 14B file header + 40B info header
    + optional 256-colour palette (8-bit) + pixel data.
    """
    data_offset = 14 + 40 + len(palette)
    file_size = data_offset + len(pixel_data)
    bmp = b"BM" + struct.pack("<IHHI", file_size, 0, 0, data_offset)
    bmp += struct.pack("<IiiHH", 40, width, height, 1, bit_count)
    # compression, sizeImage(=0 like the client), xPPM, yPPM, clrUsed
    bmp += struct.pack("<IiiII", 0, 0, xppm, yppm, 0)
    bmp += struct.pack("<I", 0)  # clrImportant -> info header is exactly 40B
    bmp += palette
    bmp += pixel_data
    return file_type.encode("ascii") + bytes([version & 0xFF]) + bmp


def make_ozb_light(rgb_rows, width=TERRAIN_SIZE, height=TERRAIN_SIZE,
                   version=0):
    """OZB light image (BM6 24-bit RGB).  `rgb_rows` is an iterable of
    (r, g, b) tuples, row-major, 256*256 entries.  Pixel bytes are BGR."""
    data = bytearray()
    for (r, g, b) in rgb_rows:
        data.append(b & 0xFF)
        data.append(g & 0xFF)
        data.append(r & 0xFF)
    return _make_bmp("BM6", version, width, height, 24, bytes(data))


def make_ozb_height(gray, width=TERRAIN_SIZE, height=TERRAIN_SIZE, version=0):
    """OZB height image (BM8 8-bit grayscale with palette).  `gray` is an
    iterable of 0..255 byte values (256*256).

    The client's 8-bit height files carry 2 extra trailing zero bytes, so we
    append them to stay byte-identical with the originals."""
    data = bytes(int(v) & 0xFF for v in gray)
    data += b"\x00\x00"
    # standard 256-entry grayscale palette (B,G,R,A per entry)
    pal = bytearray()
    for i in range(256):
        pal += bytes([i, i, i, 0])
    # the client writes xPPM=yPPM=2834 on the 8-bit height files
    return _make_bmp("BM8", version, width, height, 8, data, bytes(pal),
                     xppm=2834, yppm=2834)


def make_ozb_height_192k(rgb, width=TERRAIN_SIZE, height=TERRAIN_SIZE,
                         version=4):
    """OZB height image (BM6 24-bit, height+500 packed into RGB)."""
    data = bytearray()
    for (r, g, b) in rgb:
        data.append(b & 0xFF)
        data.append(g & 0xFF)
        data.append(r & 0xFF)
    return _make_bmp("BM6", version, width, height, 24, bytes(data))
