# -*- coding: utf-8 -*-
"""muonline_map_editor - a standalone Blender plugin to quickly edit imported
MU Online maps.

Reads a map directly from the client Data folder (ATT/MAP/OZB/OBJ + tile
textures), lets you paint terrain height / tiles / light / walls and edit
ground objects, then writes everything back with the same encryption and
format (verified byte-identical round-trip).

Inspired by VD's MuOnline-WorldEditor (in-game world editor for S16e1).
"""

import bpy

from . import properties
from . import operators
from . import panels

bl_info = {
    "name": "MU Online Map Editor",
    "author": "mu2blender",
    "version": (0, 2, 0),
    "blender": (4, 0, 0),
    "location": "3D View > Sidebar > MU \u5730\u56fe",
    "description": "\u5feb\u901f\u4fee\u6539\u5df2\u5bfc\u5165\u7684 MU \u5730\u56fe(\u9ad8\u5ea6/\u74e6\u7247/\u5149\u5f71/\u5899\u58c1/\u7269\u4f53)\u5e76\u5199\u56de",
    "category": "Import-Export",
}


def register():
    from bpy.utils import register_class
    props_cls = properties.MUONLINE_MAP_Props
    tile_cls = properties.MUONLINE_TILE_Item
    register_class(props_cls)
    register_class(tile_cls)
    bpy.types.Scene.muonline_map_props = bpy.props.PointerProperty(
        type=props_cls)
    bpy.types.Scene.muonline_tile_items = bpy.props.CollectionProperty(
        type=tile_cls)
    bpy.types.Scene.muonline_tile_index = bpy.props.IntProperty(default=0)
    for cls in operators.classes:
        register_class(cls)
    for cls in panels.classes:
        register_class(cls)


def unregister():
    from bpy.utils import unregister_class
    try:
        panels.drop_previews()
    except Exception:
        pass
    for cls in reversed(panels.classes):
        unregister_class(cls)
    for cls in reversed(operators.classes):
        unregister_class(cls)
    for name in ("muonline_tile_items", "muonline_tile_index",
                 "muonline_map_props"):
        try:
            delattr(bpy.types.Scene, name)
        except Exception:
            pass
    try:
        unregister_class(properties.MUONLINE_TILE_Item)
    except Exception:
        pass
    try:
        unregister_class(properties.MUONLINE_MAP_Props)
    except Exception:
        pass
