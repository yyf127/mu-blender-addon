# -*- coding: utf-8 -*-
"""Load a MU map straight from the Data folder into MapEditorData + a Blender
scene (standalone - does NOT depend on io_scene_muonline).

File layout used (mirrors the client / TS viewer / WorldEditor):
    Data/World{id}/EncTerrain{id}.att   terrain attributes (walls)
    Data/World{id}/EncTerrain{id}.map   tile mapping (layer1/2 + alpha)
    Data/World{id}/TerrainLight.OZB     per-cell light (BM6 RGB)
    Data/World{id}/TerrainHeight.OZB    per-cell height (BM8 gray or BM6 rgb)
    Data/World{id}/EncTerrain{id}.obj   ground objects (FileCryptor)
    Data/World{id}/Tile*.ozj/.ozt       tile textures
"""

import os

import bpy

from ..formats.att import read_att, TERRAIN_SIZE, TWFlags
from ..formats.mapdata import read_map
from ..formats.ozb import read_ozb
from ..formats.objdata import read_obj
from ..crypto.modulus_cryptor import decrypt_modulus_cryptor, _init_cipher, _KEY1
from ..crypto.file_cryptor import decrypt_file_cryptor
from ..core.editor_data import MapEditorData, FileMeta, TERRAIN_SCALE
from ..core import terrain_build

C_TERRAIN = "MU_地形"
C_OBJECTS = "MU_物体"


def _read_modulus_meta(body_bytes):
    """Recover algorithm bytes + key2 from a ModulusCryptor body."""
    buf = bytearray(body_bytes)
    alg2 = buf[0]
    alg1 = buf[1]
    c1 = _init_cipher(alg1, _KEY1)
    bs1 = 1024 - (1024 % c1.get_block_size())
    ds = len(buf) - 34
    if ds > 4 * bs1:
        mid = 2 + (ds >> 1)
        for i in range(mid, mid + bs1, c1.block_size):
            tmp = bytearray(buf[i:i + c1.block_size])
            c1.block_decrypt(tmp, len(tmp), tmp)
            buf[i:i + c1.block_size] = tmp
    if ds > bs1:
        for i in range(len(buf) - bs1, len(buf), c1.block_size):
            tmp = bytearray(buf[i:i + c1.block_size])
            c1.block_decrypt(tmp, len(tmp), tmp)
            buf[i:i + c1.block_size] = tmp
        for i in range(2, 2 + bs1, c1.block_size):
            tmp = bytearray(buf[i:i + c1.block_size])
            c1.block_decrypt(tmp, len(tmp), tmp)
            buf[i:i + c1.block_size] = tmp
    return alg2, alg1, bytes(buf[2:34])


def load_map(data_dir, world_id):
    """Parse the map files and return a populated MapEditorData."""
    data = MapEditorData(world_id=world_id, data_dir=data_dir)
    world_dir = os.path.join(data_dir, "World%d" % world_id)
    att_path = os.path.join(world_dir, "EncTerrain%d.att" % world_id)
    map_path = os.path.join(world_dir, "EncTerrain%d.map" % world_id)
    light_path = os.path.join(world_dir, "TerrainLight.OZB")
    height_path = os.path.join(world_dir, "TerrainHeight.OZB")
    obj_path = os.path.join(world_dir, "EncTerrain%d.obj" % world_id)

    # ---- ATT ----
    if os.path.exists(att_path):
        raw = open(att_path, "rb").read()
        use_modulus = raw[:4] == b"ATT\x01"
        data.att = read_att(raw)
        if use_modulus:
            a2, a1, k2 = _read_modulus_meta(raw[4:])
            data.att_meta = FileMeta('att', True, a2, a1, k2)
        else:
            data.att_meta = FileMeta('att', False)

    # ---- MAP ----
    if os.path.exists(map_path):
        raw = open(map_path, "rb").read()
        use_modulus = raw[:4] == b"MAP\x01"
        data.mapping = read_map(raw)
        if use_modulus:
            a2, a1, k2 = _read_modulus_meta(raw[4:])
            data.map_meta = FileMeta('map', True, a2, a1, k2)
        else:
            data.map_meta = FileMeta('map', False)

    # ---- Light / Height (OZB) ----
    if os.path.exists(light_path):
        ozb = read_ozb(open(light_path, "rb").read())
        raw_head = open(light_path, "rb").read()
        version = raw_head[3]
        data.light_meta = FileMeta('light', file_type=raw_head[:3].decode(),
                                   version=version)
        S = TERRAIN_SIZE
        for i in range(S * S):
            data.light[i] = (ozb.data[i * 4] / 255.0,
                             ozb.data[i * 4 + 1] / 255.0,
                             ozb.data[i * 4 + 2] / 255.0)
    if os.path.exists(height_path):
        raw = open(height_path, "rb").read()
        file_type = raw[:3].decode("ascii", errors="replace")
        version = raw[3]
        data.height_meta = FileMeta('height', file_type=file_type,
                                    version=version,
                                    is_192k=(file_type == "BM6"))
        ozb = read_ozb(raw)
        S = TERRAIN_SIZE
        # Terrain height = red channel * 1.5 units, for EVERY OZB variant
        # (BM8 gray and BM6 24-bit RGB alike).  This matches the reference
        # viewer (TerrainMesh.getHeight: `heightmap.data[idx*4] * 1.5`).  Note
        # the old `(r<<16|g<<8|b)-500` packing was WRONG for newer (BM6) maps -
        # it produced garbage (~10 000 000) heights.  Later-client heightmaps
        # are BM6 but still store elevation in the red byte.
        for i in range(S * S):
            data.height[i] = float(ozb.data[i * 4]) * 1.5

    # ---- Objects ----
    if os.path.exists(obj_path):
        data.objects = read_obj(open(obj_path, "rb").read())

    return data


# ---------------------------------------------------------------------------
# Scene building
# ---------------------------------------------------------------------------
def clear_editor_scene():
    for col_name in (C_TERRAIN, C_OBJECTS):
        col = bpy.data.collections.get(col_name)
        if col is not None:
            for obj in list(col.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove(col)
    # per-type instance groups created by build_object_instances (MUGrp_{model})
    for col in [c for c in list(bpy.data.collections)
                if c.name.startswith("MUGrp_")]:
        for obj in list(col.objects):
            bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.collections.remove(col)
    # also drop leftover terrain / object-template meshes
    for me in list(bpy.data.meshes):
        if me.name.startswith("MU_Terrain") or me.name.startswith("MUBMD_"):
            bpy.data.meshes.remove(me)
    # drop the tile preview textures created for the panel
    for tex in [t for t in list(bpy.data.textures)
                if t.name.startswith("mu_tile_tex_")]:
        try:
            bpy.data.textures.remove(tex, do_unlink=True)
        except Exception:
            pass


def build_scene(data, target_collection=None, object_mode="model"):
    """Create/refresh the terrain mesh + ground-object empties for `data`."""
    clear_editor_scene()

    scene = target_collection or bpy.context.scene.collection
    col_terr = bpy.data.collections.new(C_TERRAIN)
    col_obj = bpy.data.collections.new(C_OBJECTS)
    scene.children.link(col_terr)
    scene.children.link(col_obj)

    # terrain
    terrain_build._load_tile_images(data)
    obj = terrain_build.build_terrain_mesh(data)
    col_terr.objects.link(obj)
    terrain_build.assign_tile_materials(data, obj)
    data.terrain_obj = obj
    data.scene_collection = col_terr

    # ground objects -> real BMD models (one linked template per type)
    from ..core import bmd_display
    data.object_collection = col_obj
    bmd_display.build_object_instances(data, object_root=data.data_dir,
                                       mode=object_mode)
    return col_terr, col_obj
