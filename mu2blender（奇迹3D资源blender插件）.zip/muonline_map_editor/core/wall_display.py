# -*- coding: utf-8 -*-
"""Visualize terrain wall attributes as colored cells covering the whole map.

Every cell gets a quad.  Colors follow the reference AttInspector.ts palette
(src/att-inspector/AttInspector.ts) for each attribute flag, and the walkable
(no flags) cell is WHITE as the user specified.

The overlay is NEVER auto-hidden (user hides it manually in the outliner).
"""

import bpy

from .editor_data import TERRAIN_SIZE, TERRAIN_SCALE

# World1 (Lorencia) obj data carries an inherent +2 tile X offset.  Placed
# objects and the wall overlay both shift +X by this amount so they line up
# with each other and the ground; it is subtracted back on export.
MAP_OBJECT_X_OFFSET_TILES = {1: 2}

WALL_OBJ_NAME = "MU_Walls"


# bit -> (priority, color, label) - higher priority wins on conflict
# Colors match AttInspector.ts FLAG_COLOR_MAP (RGB 0-255 -> 0..1).
WALL_DEFS = [
    (0x0001, 100, (0.267, 0.533, 1.000), "SafeZone"),
    (0x0002, 90,  (0.961, 0.620, 0.043), "Character"),
    (0x0004, 85,  (0.973, 0.443, 0.443), "NoMove"),
    (0x0008, 80,  (0.655, 0.545, 0.980), "NoGround"),
    (0x0010, 70,  (0.133, 0.827, 0.933), "Water"),
    (0x0020, 65,  (0.204, 0.827, 0.600), "Action"),
    (0x0040, 60,  (0.984, 0.573, 0.235), "Height"),
    (0x0080, 55,  (0.910, 0.475, 0.976), "CameraUp"),
    (0x0100, 50,  (0.957, 0.447, 0.714), "NoAttackZone"),
    (0x0200, 45,  (0.980, 0.800, 0.082), "Att1"),
    (0x0400, 40,  (0.639, 0.902, 0.208), "Att2"),
    (0x0800, 35,  (0.176, 0.831, 0.749), "Att3"),
    (0x1000, 30,  (0.376, 0.647, 0.980), "Att4"),
    (0x2000, 25,  (0.984, 0.443, 0.522), "Att5"),
    (0x4000, 20,  (0.612, 0.639, 0.686), "Att6"),
    (0x8000, 15,  (0.820, 0.835, 0.859), "Att7"),
]

# default walkable (no flags) color = WHITE (user-specified)
WALK_COLOR = (1.0, 1.0, 1.0)


def _wall_color(wall):
    """Return (color, label) for a wall bitmask (highest priority)."""
    best = None
    for bit, pri, color, label in WALL_DEFS:
        if wall & bit:
            if best is None or pri > best[0]:
                best = (pri, color, label)
    return best


def _build_wall_material():
    name = "mu_walls_mat"
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    vcol = nt.nodes.new("ShaderNodeVertexColor")
    vcol.layer_name = "Col"
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(bsdf.inputs["Base Color"], vcol.outputs["Color"])
    nt.links.new(bsdf.inputs["Alpha"], vcol.outputs["Alpha"])
    nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    mat.blend_method = "BLEND"
    mat.show_transparent_back = True
    return mat


def build_wall_overlay(data, name=WALL_OBJ_NAME):
    """Create (or replace) the wall overlay mesh object for `data`."""
    old = bpy.data.objects.get(name)
    if old is not None:
        me = old.data
        bpy.data.objects.remove(old, do_unlink=True)
        bpy.data.meshes.remove(me)

    S = TERRAIN_SIZE
    positions = []
    colors = []
    faces = []
    # Wall-color X offset (tiles): only World1 has the +2 object-coordinate quirk
    # in this data, so it needs the -2 color sampling (attr[k] shown at cell k+2).
    # All other worlds have xoff=0 -> wall color shows the attribute at the same
    # cell (no shift).  This keeps World1 aligned and lets every other map's wall
    # coloring match its own terrain.
    xoff = MAP_OBJECT_X_OFFSET_TILES.get(data.world_id, 0)

    for cy in range(S):
        for cx in range(S):
            # Each quad at cell cx shows the attribute color from cx - xoff, so
            # the wall-color layer is X-offset by xoff tiles to match the
            # terrain/object convention.  Clamp so we never sample < 0.
            ccx = cx - xoff if cx >= xoff else 0
            wall = data.att.terrain_wall[cy * S + ccx]
            wc = _wall_color(wall)
            if wc is not None:
                color = wc[1]
            else:
                color = WALK_COLOR  # walkable -> purple
            z = data.height[cy * S + cx] + 8.0
            # Shift the wall mesh -X by 2 tiles (World1) so it no longer lines
            # up with the +2-tile object offset (which stays unchanged).
            x0, y0 = cx * TERRAIN_SCALE, cy * TERRAIN_SCALE
            base = len(positions)
            positions.append((x0, y0, z))
            positions.append((x0 + TERRAIN_SCALE, y0, z))
            positions.append((x0 + TERRAIN_SCALE, y0 + TERRAIN_SCALE, z))
            positions.append((x0, y0 + TERRAIN_SCALE, z))
            for _ in range(4):
                colors.append((color[0], color[1], color[2], 0.5))
            faces.append((base, base + 1, base + 2, base + 3))

    me = bpy.data.meshes.new(name)
    clean = [f for f in faces
             if 0 <= f[0] < len(positions) and 0 <= f[1] < len(positions)
             and 0 <= f[2] < len(positions) and 0 <= f[3] < len(positions)]
    me.from_pydata(positions, [], clean)
    me.update()
    if colors:
        col = me.vertex_colors.new(name="Col")
        flat = []
        for li in range(len(me.loops)):
            c = colors[me.loops[li].vertex_index]
            flat.extend((c[0], c[1], c[2], c[3]))
        col.data.foreach_set("color", flat)
    me.materials.append(_build_wall_material())

    obj = bpy.data.objects.new(name, me)
    obj["mu_is_walls"] = True
    return obj


def update_wall_overlay(data):
    """Rebuild the wall overlay in its current collection (or create it)."""
    obj = build_wall_overlay(data)
    col = data.scene_collection
    if col is None:
        col = data.terrain_obj.users_collection[0] if data.terrain_obj else None
    if col is not None:
        col.objects.link(obj)
    return obj


def remove_wall_overlay():
    old = bpy.data.objects.get(WALL_OBJ_NAME)
    if old is not None:
        me = old.data
        bpy.data.objects.remove(old, do_unlink=True)
        bpy.data.meshes.remove(me)


