# muonline_map_editor.core - map editing model, terrain build and brushes.
