# -*- coding: utf-8 -*-
"""Module-level store for the currently-loaded MapEditorData."""

_current = None


def get_current():
    return _current


def set_current(data):
    global _current
    _current = data


def clear():
    global _current
    _current = None
