# -*- coding: utf-8 -*-
"""Build (and rebuild) the editable terrain mesh from MapEditorData.

The mesh is a 257x257 vertex grid over the 256x256 map cells, with per-tile
UV, a Lightmap vertex-color layer, a `mu_alpha` float corner attribute and
per-tile materials that replicate the game shader:
    final = light * lerp(layer1, layer2, alpha/255)

A brush that edits the height / tiles / light arrays calls the matching
targeted updater here so the viewport reflects the edit immediately.
"""

import os
import math

import bpy

from ..formats.att import TWFlags
from ..formats import textures as tex_mod
from .editor_data import MapEditorData, TERRAIN_SIZE, TERRAIN_SCALE

TERRAIN_WORLD_SIZE = TERRAIN_SIZE * TERRAIN_SCALE
SPECIAL_HEIGHT = 1200.0

# World1's OBJ coords are shifted +2 tiles in X in this data (and ground objects
# are placed at raw+2).  Only worlds listed here get a ground-texture +X shift of
# that many tiles; all other worlds stay unshifted.
MAP_OBJECT_X_OFFSET_TILES = {1: 2}

# Blender id-properties cannot hold a dict with int keys, so the cell->polygon
# lookup lives here (keyed by terrain object name).
_CELL_POLYS = {}


def register_cell_polys(obj, cell_polys):
    _CELL_POLYS[obj.name] = cell_polys


def get_cell_polys(obj):
    return _CELL_POLYS.get(obj.name, {})


def clear_cell_polys(name):
    _CELL_POLYS.pop(name, None)

# Default client tile texture files (index -> file name).  Mirrors
# TerrainData.cs / TerrainLoader.ts.
DEFAULT_TEXTURE_FILES = {
    0: "TileGrass01.ozj", 1: "TileGrass02.ozj", 2: "TileGround01.ozj",
    3: "TileGround02.ozj", 4: "TileGround03.ozj", 5: "TileWater01.ozj",
    6: "TileWood01.ozj", 7: "TileRock01.ozj", 8: "TileRock02.ozj",
    9: "TileRock03.ozj", 10: "TileRock04.ozj", 11: "TileRock05.ozj",
    12: "TileRock06.ozj", 13: "TileRock07.ozj",
    30: "TileGrass01.ozt", 31: "TileGrass02.ozt", 32: "TileGrass03.ozt",
    100: "leaf01.ozt", 101: "leaf02.ozj", 102: "rain01.ozt",
    103: "rain02.ozt", 104: "rain03.ozt",
}
# Later-client (post-update) maps use tile indices 14..29 which map to the
# ExtTile01..16 textures (C# TerrainLoader textureMapFiles[13+i] /
# TS TerrainLoader.ts "ExtTile{idx-13:02}.ozj").  Adding these so new maps'
# ground textures load.  ((idx-13) -> 14..29 -> 01..16)
for _ext_idx in range(14, 30):
    DEFAULT_TEXTURE_FILES[_ext_idx] = "ExtTile%02d.ozj" % (_ext_idx - 13)



def height_at(data, tx, ty):
    """Terrain height at cell (tx,ty), including the Height wall bonus."""
    cell = data.cell(tx, ty)
    h = data.height[cell]
    if data.att.terrain_wall[cell] & TWFlags.Height:
        h += SPECIAL_HEIGHT
    return h


def _tile_file_candidates(idx):
    """Candidate file NAMES (in priority order) for one tile index.
    Mirrors TS TerrainLoader.tryLoadTexture:
      1) exact name from DEFAULT_TEXTURE_FILES
      2) ExtTile{idx-13:02}.ozj for indices 14..29
      3) same base name retried with .ozj/.ozt/.jpg/.png
    """
    candidates = []
    default_name = DEFAULT_TEXTURE_FILES.get(idx)
    if default_name:
        candidates.append(default_name)
    if 14 <= idx <= 29:
        candidates.append("ExtTile%02d.ozj" % (idx - 13))
    if default_name:
        import re as _re
        base = _re.sub(r"\.[^.]+$", "", default_name)
        for ext in (".ozj", ".ozt", ".jpg", ".png"):
            nm = base + ext
            if nm != default_name and nm not in candidates:
                candidates.append(nm)
    return candidates


def _load_tile_images(data):
    """Decode every tile texture used by layer1/layer2 into data.tile_textures.
    Returns the set of usable indices."""
    root = data.data_dir
    if not root:
        return set()
    world_root = os.path.join(root, "World%d" % data.world_id)
    tex_files = {}
    for idx in DEFAULT_TEXTURE_FILES:
        for fname in _tile_file_candidates(idx):
            path = os.path.join(world_root, fname)
            if os.path.exists(path):
                tex_files[idx] = path
                break
    used = set(data.mapping.layer1) | set(data.mapping.layer2)
    usable = set()
    for idx in used - {255}:
        path = tex_files.get(idx)
        if not path:
            continue
        try:
            with open(path, "rb") as f:
                pil = tex_mod.decode_texture(
                    f.read(), os.path.splitext(path)[1].lower())
            data.tile_textures[idx] = pil
            usable.add(idx)
        except Exception:
            continue
    return usable


def _tile_image_name(idx):
    """Blender image datablock name for a tile = its original file name
    (e.g. TileGrass01) so it is easy to identify in the asset browser; falls
    back to mu_tile_{idx} if the source file name is unknown."""
    base = DEFAULT_TEXTURE_FILES.get(idx, "")
    stem = os.path.splitext(base)[0]
    return stem if stem else "mu_tile_%d" % idx


def _ensure_image(idx, pil_img):
    import tempfile
    img_name = _tile_image_name(idx)
    bimg = bpy.data.images.get(img_name)
    if bimg is None:
        tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        try:
            pil_img.convert("RGBA").save(tmp.name, format="PNG")
            tmp.close()
            bimg = bpy.data.images.load(tmp.name)
            # PACK the pixels so the image keeps its data in-memory even though
            # the temp source file is deleted right below. Without packing,
            # Blender tries to reload the (now-missing) filepath when it uploads
            # the texture to the GPU -> repeatedly logs
            #   gpu.texture | ERROR Failed to create GPU texture from Blender image
            # in the 3D viewport whenever a material uses this image.
            # (Packing is safe now: the preview icons are built from im.pixels in
            # panels.build_previews(), not from this image's filepath.)
            try:
                bimg.pack()
            except Exception:
                pass
            try:
                bimg.name = img_name
            except Exception:
                bimg.name = img_name
        finally:
            try:
                os.unlink(tmp.name)
            except OSError:
                pass
    return bimg


def _add_uvmap_wire(nt, tex):
    uvmap = nt.nodes.new("ShaderNodeUVMap")
    uvmap.uv_map = "uv1"
    nt.links.new(tex.inputs["Vector"], uvmap.outputs["UV"])


def _tile_material(idx, pil_img):
    mat = bpy.data.materials.get("terrain_tile_%d" % idx)
    if mat is None:
        mat = bpy.data.materials.new("terrain_tile_%d" % idx)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = _ensure_image(idx, pil_img)
    _add_uvmap_wire(nt, tex)
    light = nt.nodes.new("ShaderNodeVertexColor")
    light.layer_name = "Lightmap"
    mul = nt.nodes.new("ShaderNodeMix")
    mul.data_type = "RGBA"
    mul.blend_type = "MULTIPLY"
    mul.inputs[0].default_value = 1.0
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(mul.inputs["A"], tex.outputs["Color"])
    nt.links.new(mul.inputs["B"], light.outputs["Color"])
    nt.links.new(bsdf.inputs["Base Color"], mul.outputs["Result"])
    nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat


def _tile_material_double(l1, l2, img1, img2):
    key = "%d_%d" % (l1, l2)
    mat = bpy.data.materials.get("terrain_tile_%s" % key)
    if mat is None:
        mat = bpy.data.materials.new("terrain_tile_%s" % key)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    tex1 = nt.nodes.new("ShaderNodeTexImage")
    tex1.image = _ensure_image(l1, img1)
    _add_uvmap_wire(nt, tex1)
    tex2 = nt.nodes.new("ShaderNodeTexImage")
    tex2.image = _ensure_image(l2, img2)
    _add_uvmap_wire(nt, tex2)
    an = nt.nodes.new("ShaderNodeAttribute")
    an.attribute_name = "mu_alpha"
    mix = nt.nodes.new("ShaderNodeMix")
    mix.data_type = "RGBA"
    mix.blend_type = "MIX"
    nt.links.new(mix.inputs[0], an.outputs["Factor"])
    nt.links.new(mix.inputs["A"], tex1.outputs["Color"])
    nt.links.new(mix.inputs["B"], tex2.outputs["Color"])
    light = nt.nodes.new("ShaderNodeVertexColor")
    light.layer_name = "Lightmap"
    mul = nt.nodes.new("ShaderNodeMix")
    mul.data_type = "RGBA"
    mul.blend_type = "MULTIPLY"
    mul.inputs[0].default_value = 1.0
    bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    nt.links.new(mul.inputs["A"], mix.outputs["Result"])
    nt.links.new(mul.inputs["B"], light.outputs["Color"])
    nt.links.new(bsdf.inputs["Base Color"], mul.outputs["Result"])
    nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat


def build_terrain_mesh(data, name="MU_Terrain"):
    """Build (or rebuild) the terrain mesh object from `data`."""
    S = TERRAIN_SIZE
    V = S + 1

    # ---- vertices / normals / colors ----
    positions = []
    normals = []
    colors = []
    for vy in range(V):
        for vx in range(V):
            tx = min(vx, S - 1)
            ty = min(vy, S - 1)
            positions.append((vx * TERRAIN_SCALE, vy * TERRAIN_SCALE,
                              height_at(data, tx, ty)))
            cell = data.cell(tx, ty)
            colors.append(data.light[cell])

    for vy in range(V):
        for vx in range(V):
            tx = min(vx, S - 1)
            ty = min(vy, S - 1)
            h_l = height_at(data, tx - 1, ty)
            h_r = height_at(data, tx + 1, ty)
            h_d = height_at(data, tx, ty - 1)
            h_u = height_at(data, tx, ty + 1)
            nx = h_l - h_r
            ny = h_u - h_d
            nz = 2 * TERRAIN_SCALE
            ln = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
            normals.append((nx / ln, ny / ln, nz / ln))

    # ---- faces (skip NoGround cells) ----
    faces = []
    cell_polys = {}
    for ty in range(S):
        for tx in range(S):
            cell = ty * S + tx
            if data.att.terrain_wall[cell] & TWFlags.NoGround:
                cell_polys[cell] = []
                continue
            v0 = ty * V + tx
            v1 = ty * V + tx + 1
            v2 = (ty + 1) * V + tx + 1
            v3 = (ty + 1) * V + tx
            p0 = len(faces)
            faces.append((v0, v1, v3))
            faces.append((v1, v2, v3))
            cell_polys[cell] = [p0, p0 + 1]

    clean = [f for f in faces
             if 0 <= f[0] < len(positions) and 0 <= f[1] < len(positions)
             and 0 <= f[2] < len(positions)
             and f[0] != f[1] and f[1] != f[2] and f[0] != f[2]]

    me = bpy.data.meshes.new(name)
    me.from_pydata(positions, [], clean)
    me.update()

    # mu_normals (used by brushes to recompute)
    attr_n = me.attributes.new(name="mu_normals", type="FLOAT_VECTOR",
                               domain="POINT")
    for i, n in enumerate(normals):
        attr_n.data[i].vector = n

    # Lightmap vertex colors (corner domain)
    col = me.vertex_colors.new(name="Lightmap")
    flat = []
    for li in range(len(me.loops)):
        c = colors[me.loops[li].vertex_index]
        flat.extend((c[0], c[1], c[2], 1.0))
    col.data.foreach_set("color", flat)

    obj = bpy.data.objects.new(name, me)
    obj["mu_map_world"] = data.world_id
    register_cell_polys(obj, cell_polys)
    return obj


def assign_tile_materials(data, obj, rebuild_uv=True):
    """Assign per-cell materials + UV + mu_alpha from mapping data."""
    S = TERRAIN_SIZE
    V = S + 1
    me = obj.data

    usable = _load_tile_images(data)
    avail = sorted(data.tile_textures.keys())
    if not avail:
        if not obj.data.materials:
            dmat = bpy.data.materials.new("terrain_default")
            dmat.use_nodes = True
            obj.data.materials.append(dmat)
        return
    fallback = {}
    fb = avail[0]
    for idx in (set(data.mapping.layer1) | set(data.mapping.layer2)) - {255}:
        if idx not in data.tile_textures:
            fallback[idx] = fb

    uv = me.uv_layers.get("uv1") or me.uv_layers.new(name="uv1")
    uv_data = uv.data
    me.uv_layers.active_index = me.uv_layers.find("uv1")
    if hasattr(me.uv_layers, "active_render"):
        me.uv_layers.active_render = uv

    single_slot = {}
    double_slot = {}

    def single_slot_of(l1):
        if l1 in single_slot:
            return single_slot[l1]
        if l1 not in data.tile_textures:
            return None
        mat = _tile_material(l1, data.tile_textures[l1])
        if mat.name not in obj.data.materials:
            obj.data.materials.append(mat)
        single_slot[l1] = len(obj.data.materials) - 1
        return single_slot[l1]

    def double_slot_of(l1, l2):
        key = (l1, l2)
        if key in double_slot:
            return double_slot[key]
        if l1 not in data.tile_textures or l2 not in data.tile_textures:
            return None
        mat = _tile_material_double(l1, l2, data.tile_textures[l1],
                                    data.tile_textures[l2])
        if mat.name not in obj.data.materials:
            obj.data.materials.append(mat)
        double_slot[key] = len(obj.data.materials) - 1
        return double_slot[key]

    # Ground-texture +X shift (tiles) for this world's terrain: only worlds in
    # MAP_OBJECT_X_OFFSET_TILES get offset (World1 = 2 tiles); others stay 0.
    xoff = MAP_OBJECT_X_OFFSET_TILES.get(data.world_id, 0)

    for poly in me.polygons:
        ls = poly.loop_start
        lt = poly.loop_total
        tx = min(me.loops[ls + k].vertex_index % V for k in range(lt))
        ty = min(me.loops[ls + k].vertex_index // V for k in range(lt))
        # The visible ground "texture" is the per-cell tile TYPE.  To align the
        # ground with the (confirmed-correct) walls - which show attr[cx-2] at
        # geometric cell cx, i.e. +X offset by xoff - the tile material shown at
        # geometric cell (tx,ty) must come from (tx-xoff, ty).  This shifts the
        # whole ground-tile distribution +X by xoff tiles.
        stx = tx - xoff if tx >= xoff else 0
        cell = ty * S + stx
        l1 = fallback.get(data.mapping.layer1[cell], data.mapping.layer1[cell])
        raw_l2 = data.mapping.layer2[cell]
        l2 = fallback.get(raw_l2, raw_l2) if raw_l2 != 255 else 255
        slot = double_slot_of(l1, l2) if l2 != 255 else None
        if slot is None:
            slot = single_slot_of(l1)
        if slot is None:
            poly.material_index = 0
            continue
        poly.material_index = slot
        pil = data.tile_textures.get(l1)
        if pil is not None and pil.size[0] > 0 and pil.size[1] > 0:
            bw = 64.0 / pil.size[0]
            bh = 64.0 / pil.size[1]
        else:
            bw = bh = 0.5
        for k in range(lt):
            vi = me.loops[ls + k].vertex_index
            vx = vi % V
            vy = vi // V
            # This polygon's tile came from source cell (tx - xoff); anchor the
            # UV tiling to that source so the texture is laid out correctly
            # within the moved cell (matches how the wall color is sampled).
            uv_data[ls + k].uv = ((vx - xoff) * bw, vy * bh)

    # mu_alpha per corner
    attr = me.attributes.get("mu_alpha")
    if attr is None:
        attr = me.attributes.new(name="mu_alpha", type="FLOAT", domain="CORNER")
    loops = me.loops
    n_loops = len(loops)
    aval = [0.0] * n_loops
    for li in range(n_loops):
        vi = loops[li].vertex_index
        vx = vi % V
        vy = vi // V
        cell = min(vy, S - 1) * S + min(vx, S - 1)
        aval[li] = data.mapping.alpha[cell] / 255.0
    attr.data.foreach_set("value", aval)
    me.update()


def _tile_preview_path(data, idx, fname):
    return os.path.join(data.data_dir, "World%d" % data.world_id, fname)


def _resolve_tile_path(data, idx):
    """First candidate file that exists for tile `idx` (see _tile_file_candidates)."""
    world_root = os.path.join(data.data_dir, "World%d" % data.world_id)
    for fname in _tile_file_candidates(idx):
        p = os.path.join(world_root, fname)
        if os.path.exists(p):
            return p
    return None


def build_tile_previews(data):
    """Create ALL tile-preview Blender images.  CALL ONLY FROM AN OPERATOR
    (never from a panel draw - Blender forbids writing image/name IDs while
    drawing).  Returns {tile_index: bpy image}."""
    if not data.data_dir:
        return {}
    out = {}
    for idx in DEFAULT_TEXTURE_FILES:
        path = _resolve_tile_path(data, idx)
        if not path:
            continue
        pil = None
        try:
            with open(path, "rb") as f:
                pil = tex_mod.decode_texture(
                    f.read(), os.path.splitext(path)[1].lower())
        except Exception:
            pil = None
        if pil is None:
            continue
        data.tile_textures[idx] = pil
        try:
            out[idx] = _ensure_image(idx, pil)
        except Exception:
            continue
    return out


def get_tile_preview_images(data):
    """READ-ONLY: return {tile_index: bpy image} for already-built previews.
    Safe to call from a panel draw (no ID writes)."""
    if not data.data_dir:
        return {}
    out = {}
    for idx in DEFAULT_TEXTURE_FILES:
        if _resolve_tile_path(data, idx) is None:
            continue
        bimg = bpy.data.images.get(_tile_image_name(idx))
        if bimg is not None:
            out[idx] = bimg
    return out


# ---------------------------------------------------------------------------
# Targeted brush updaters (edit data arrays AND mesh in one place)
# ---------------------------------------------------------------------------
def update_light_at_verts(obj, verts, light_color):
    """Set Lightmap vertex color for the given vertex indices."""
    me = obj.data
    col = me.vertex_colors["Lightmap"]
    flat = []
    for li in range(len(me.loops)):
        vi = me.loops[li].vertex_index
        if vi in verts:
            flat.extend((light_color[0], light_color[1], light_color[2], 1.0))
        else:
            c = col.data[li].color
            flat.extend((c[0], c[1], c[2], 1.0))
    col.data.foreach_set("color", flat)
    me.update()


def update_height_verts(obj, vert_indices, heights, normals):
    """Set vertex Z positions and mu_normals for affected vertices."""
    me = obj.data
    for i, v in enumerate(vert_indices):
        me.vertices[v].co.z = heights[i]
    attr = me.attributes["mu_normals"]
    for i, v in enumerate(vert_indices):
        attr.data[v].vector = normals[i]
    me.update()


def recompute_light_from_normals(data):
    """Approximate per-cell light from terrain slope (simple ambient).

    This is a lightweight stand-in: the real TerrainLight is stored per-cell
    and edited with the light brush.  This helper only refreshes vertex colors
    after a height edit so the shading follows the new terrain.
    """
    # The game keeps an explicit light map; we only refresh the viewport by
    # re-applying data.light.  Height edits do not change data.light here.
    pass
