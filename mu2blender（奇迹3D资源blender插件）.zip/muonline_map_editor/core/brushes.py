# -*- coding: utf-8 -*-
"""Brush editing: every brush updates the MapEditorData arrays AND the terrain
mesh in the viewport in one call.

Cell <-> mesh mapping:
    vertex (vx,vy)  -> index vy*(256+1)+vx
    cell   (cx,cy)  -> corners (cx,cy),(cx+1,cy),(cx,cy+1),(cx+1,cy+1)
    polygon -> stored per cell in obj["mu_cell_polys"] (two triangles/cell)
"""

import math

import bpy

from ..formats.att import TWFlags
from .editor_data import TERRAIN_SIZE, TERRAIN_SCALE
from . import terrain_build

V = TERRAIN_SIZE + 1


def _cells_in_disk(cx, cy, radius):
    """Yield (x, y, falloff) for cells within `radius` of (cx, cy).

    radius 0 -> exactly the single center cell (1-grid brush, falloff 1.0).
    radius N -> all cells whose Chebyshev-ish disk distance <= N, with linear
    falloff toward the edge (used for height/light smoothing).
    """
    radius = max(0, int(radius))
    if radius == 0:
        yield (cx, cy, 1.0)
        return
    r = float(radius)
    for dy in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            d = math.hypot(dx, dy)
            if d > radius:
                continue
            lf = (r - d) / r
            yield (cx + dx, cy + dy, max(0.0, lf))


def _cell_verts(cx, cy):
    x = cx & (TERRAIN_SIZE - 1)
    y = cy & (TERRAIN_SIZE - 1)
    return [y * V + x, y * V + x + 1, (y + 1) * V + x, (y + 1) * V + x + 1]


# ---------------------------------------------------------------------------
# Height
# ---------------------------------------------------------------------------
def brush_height(data, obj, cx, cy, radius, mode="raise", strength=10.0,
                 flatten_h=0.0, smooth_iter=1):
    """mode: raise | lower | flatten | smooth"""
    cells = list(_cells_in_disk(cx, cy, radius))
    touched_verts = set()
    height_changes = {}

    if mode in ("raise", "lower"):
        sign = 1.0 if mode == "raise" else -1.0
        for (x, y, lf) in cells:
            idx = data.cell(x, y)
            data.height[idx] += sign * strength * lf
            height_changes[idx] = data.height[idx]
            touched_verts.update(_cell_verts(x, y))
    elif mode == "flatten":
        for (x, y, lf) in cells:
            idx = data.cell(x, y)
            data.height[idx] += (flatten_h - data.height[idx]) * 0.5 * lf
            height_changes[idx] = data.height[idx]
            touched_verts.update(_cell_verts(x, y))
    elif mode == "smooth":
        base = {}
        for (x, y, lf) in cells:
            base[(x, y)] = data.height[data.cell(x, y)]
        for _ in range(smooth_iter):
            for (x, y, lf) in cells:
                s = 0.0
                cnt = 0
                for (nx, ny) in ((x, y - 1), (x, y + 1), (x - 1, y), (x + 1, y)):
                    nk = (nx & (TERRAIN_SIZE - 1), ny & (TERRAIN_SIZE - 1))
                    if nk in base or (0 <= nx < TERRAIN_SIZE
                                      and 0 <= ny < TERRAIN_SIZE):
                        s += data.height[data.cell(nx, ny)]
                        cnt += 1
                if cnt:
                    idx = data.cell(x, y)
                    data.height[idx] += (s / cnt - data.height[idx]) * 0.5 * lf
            for (x, y, lf) in cells:
                touched_verts.update(_cell_verts(x, y))

    if not touched_verts:
        return
    # push to mesh: set vertex Z for the 4 corners of each changed cell
    verts = sorted(touched_verts)
    new_pos = {}
    for vi in verts:
        vx = vi % V
        vy = vi // V
        tx = min(vx, TERRAIN_SIZE - 1)
        ty = min(vy, TERRAIN_SIZE - 1)
        new_pos[vi] = terrain_build.height_at(data, tx, ty)
    for vi in verts:
        obj.data.vertices[vi].co.z = new_pos[vi]
    obj.data.update()

    # recompute mu_normals for a neighbourhood of the touched vertices
    _recompute_normals(data, obj, verts)


def _recompute_normals(data, obj, verts):
    me = obj.data
    attr = me.attributes.get("mu_normals")
    if attr is None:
        return
    extra = set()
    for vi in verts:
        vx = vi % V
        vy = vi // V
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                nx = (vx + dx) & (TERRAIN_SIZE - 1)
                ny = (vy + dy) & (TERRAIN_SIZE - 1)
                extra.add(ny * V + nx)
    for vi in extra:
        vx = vi % V
        vy = vi // V
        tx = min(vx, TERRAIN_SIZE - 1)
        ty = min(vy, TERRAIN_SIZE - 1)
        h_l = terrain_build.height_at(data, tx - 1, ty)
        h_r = terrain_build.height_at(data, tx + 1, ty)
        h_d = terrain_build.height_at(data, tx, ty - 1)
        h_u = terrain_build.height_at(data, tx, ty + 1)
        nx = h_l - h_r
        ny = h_u - h_d
        nz = 2 * TERRAIN_SCALE
        ln = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
        attr.data[vi].vector = (nx / ln, ny / ln, nz / ln)
    me.update()


# ---------------------------------------------------------------------------
# Tile (mapping)
# ---------------------------------------------------------------------------
def brush_tile(data, obj, cx, cy, radius, layer=0, tile_index=0,
               alpha_delta=0.1):
    """Paint layer1/layer2 tile index + blend alpha within the brush disk.

    Painting layer1 (the default tile picker) resets layer2 to 255 and alpha
    to 0 so the cell shows ONLY the chosen single tile (clearly visible).
    """
    cells = list(_cells_in_disk(cx, cy, radius))
    touched_cells = set()
    for (x, y, lf) in cells:
        idx = data.cell(x, y)
        if layer == 0:
            data.mapping.layer1[idx] = tile_index & 0xFF
            # pure single-layer display: clear the blend on top
            data.mapping.layer2[idx] = 255
            data.mapping.alpha[idx] = 0
        else:
            data.mapping.layer2[idx] = tile_index & 0xFF
            # paint alpha up on layer2
            a = data.mapping.alpha[idx] + int(alpha_delta * 255 * lf)
            data.mapping.alpha[idx] = max(0, min(255, a))
        touched_cells.add((x, y))
    if touched_cells:
        _apply_tile_to_mesh(data, obj, touched_cells)


def erase_tile(data, obj, cx, cy, radius, layer=1):
    """Right-button layer2 erase: set layer2=255 and alpha=0."""
    cells = list(_cells_in_disk(cx, cy, radius))
    touched = set()
    for (x, y, lf) in cells:
        idx = data.cell(x, y)
        if layer == 1:
            data.mapping.layer2[idx] = 255
            data.mapping.alpha[idx] = 0
        touched.add((x, y))
    if touched:
        _apply_tile_to_mesh(data, obj, touched)


def _apply_tile_to_mesh(data, obj, cells):
    me = obj.data
    cell_polys = terrain_build.get_cell_polys(obj)
    uv = me.uv_layers.get("uv1")
    attr = me.attributes.get("mu_alpha")
    loops = me.loops

    for (cx, cy) in cells:
        cell = data.cell(cx, cy)
        poly_list = cell_polys.get(cell, [])
        # figure the material slot (reuse assign logic in a cheap way)
        l1 = data.mapping.layer1[cell]
        raw_l2 = data.mapping.layer2[cell]
        l2 = raw_l2 if raw_l2 != 255 else 255
        slot = _find_material_slot(data, obj, l1, l2)
        for pi in poly_list:
            poly = me.polygons[pi]
            poly.material_index = slot
            pil = data.tile_textures.get(l1)
            if pil is not None and pil.size[0] > 0 and pil.size[1] > 0:
                bw = 64.0 / pil.size[0]
                bh = 64.0 / pil.size[1]
            else:
                bw = bh = 0.5
            for k in range(poly.loop_total):
                li = poly.loop_start + k
                vi = loops[li].vertex_index
                vx = vi % V
                vy = vi // V
                if uv:
                    uv.data[li].uv = (vx * bw, vy * bh)
                if attr:
                    cc = min(vy, TERRAIN_SIZE - 1) * TERRAIN_SIZE + \
                        min(vx, TERRAIN_SIZE - 1)
                    attr.data[li].value = data.mapping.alpha[cc] / 255.0
    me.update()


def _find_material_slot(data, obj, l1, l2):
    """Return the material slot index for a (l1, l2) pair, creating it if
    needed (mirrors assign_tile_materials)."""
    if l2 == 255:
        name = "terrain_tile_%d" % l1
        if l1 in data.tile_textures:
            mat = terrain_build._tile_material(l1, data.tile_textures[l1])
            if mat.name not in obj.data.materials:
                obj.data.materials.append(mat)
        else:
            return 0
    else:
        key = "%d_%d" % (l1, l2)
        name = "terrain_tile_%s" % key
        if l1 in data.tile_textures and l2 in data.tile_textures:
            mat = terrain_build._tile_material_double(
                l1, l2, data.tile_textures[l1], data.tile_textures[l2])
            if mat.name not in obj.data.materials:
                obj.data.materials.append(mat)
        else:
            return 0
    return obj.data.materials.find(name)


# ---------------------------------------------------------------------------
# Light
# ---------------------------------------------------------------------------
def brush_light(data, obj, cx, cy, radius, color, mode="set"):
    """mode: set (paint color) | smooth (5-neighbour average)"""
    cells = list(_cells_in_disk(cx, cy, radius))
    touched = set()
    for (x, y, lf) in cells:
        idx = data.cell(x, y)
        if mode == "set":
            c = data.light[idx]
            data.light[idx] = (c[0] + (color[0] - c[0]) * 0.8 * lf,
                               c[1] + (color[1] - c[1]) * 0.8 * lf,
                               c[2] + (color[2] - c[2]) * 0.8 * lf)
        touched.update(_cell_verts(x, y))
    if mode == "smooth":
        newv = {}
        for (x, y, lf) in cells:
            idx = data.cell(x, y)
            s = [0.0, 0.0, 0.0]
            cnt = 0
            for (nx, ny) in ((x, y - 1), (x, y + 1), (x - 1, y), (x + 1, y),
                             (x, y)):
                nidx = data.cell(nx, ny)
                c = data.light[nidx]
                s[0] += c[0]; s[1] += c[1]; s[2] += c[2]
                cnt += 1
            cur = data.light[idx]
            data.light[idx] = (cur[0] + (s[0] / cnt - cur[0]) * 0.5,
                               cur[1] + (s[1] / cnt - cur[1]) * 0.5,
                               cur[2] + (s[2] / cnt - cur[2]) * 0.5)
            touched.update(_cell_verts(x, y))
    if touched:
        _apply_light_to_mesh(data, obj, touched)


def _apply_light_to_mesh(data, obj, verts):
    me = obj.data
    col = me.vertex_colors["Lightmap"]
    # Build the whole per-loop flat array from data.light WITHOUT reading
    # col.data per loop (per-loop color access over ~393k loops is
    # pathologically slow in Blender 5.x).
    loops = me.loops
    n = len(loops)
    flat = [0.0] * (n * 4)
    S = TERRAIN_SIZE
    for li in range(n):
        vi = loops[li].vertex_index
        c = data.light[data.cell(vi % V, (vi // V) & (S - 1))]
        j = li * 4
        flat[j] = c[0]
        flat[j + 1] = c[1]
        flat[j + 2] = c[2]
        flat[j + 3] = 1.0
    col.data.foreach_set("color", flat)
    me.update()


# ---------------------------------------------------------------------------
# Wall (attributes)
# ---------------------------------------------------------------------------
def brush_wall(data, cx, cy, radius, wall_type=TWFlags.SafeZone, on=True,
               overwrite=False):
    """Paint/clear wall attributes on the cells in the disk.

    overwrite=True replaces the whole attribute with `wall_type` (used by the
    brush "swap region" behaviour); otherwise it toggles just that bit.
    """
    for (x, y, lf) in _cells_in_disk(cx, cy, radius):
        idx = data.cell(x, y)
        if on:
            if overwrite:
                data.att.terrain_wall[idx] = wall_type
            else:
                data.att.terrain_wall[idx] |= wall_type
        else:
            data.att.terrain_wall[idx] &= ~wall_type
