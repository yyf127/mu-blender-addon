# -*- coding: utf-8 -*-
"""Single source of truth for the ground-object "type" list.

The game stores each placed object as a numeric *type*; the meaning of that
number depends on the map (World 1 / Lorencia uses the table below, matched to
the reference viewer).  Types that fall into an unknown range have no friendly
name and are shown with a generic label, but can still be placed and exported.

Each table entry is a 4-tuple:
    (type_number, model_name, category_label, short_description)
The enum used by the UI (see object_type_enum()) is built from this table so
panels / operators / export all stay consistent with one definition.

NOTE: this file must stay pure ASCII.  All Chinese text is written as \\uXXXX
escapes inside string literals (raw Chinese would be corrupted to GBK bytes).
"""

import os

# --- category labels (Chinese, kept as \\uXXXX escapes for ASCII safety) ---
_TREE = "\u6811\u6728"            # Tree
_GRASS = "\u8349\u4e1b"           # Grass
_STONE = "\u77f3\u5934"           # Stone
_STATUE = "\u96d5\u50cf"          # Statue
_TOMB = "\u575f\u5893"            # Tomb
_FIRE = "\u706b\u5149"           # Fire light
_STRUCTURE = "\u5efa\u7b51"       # Structure / building
_FENCE = "\u6805\u680f"           # Fence
_BRIDGE = "\u6865\u6881"          # Bridge
_LIGHT = "\u706f\u5149"           # Light
_WAR = "\u519b\u7528"             # Military
_PROP = "\u9053\u5177"            # Prop
_FURNITURE = "\u5bb6\u5177"       # Furniture
_DRINK = "\u996e\u54c1"           # Drink
_HOUSE = "\u623f\u5c4b"           # House

# short Chinese description per category (\\uXXXX)
_CN_TREE = "\u6a71\u6728"          # maple tree
_CN_GRASS = "\u8349"              # grass
_CN_STONE = "\u77f3"              # stone
_CN_STATUE = "\u96d5\u50cf"        # statue
_CN_TOMB = "\u575f\u5893"          # tomb
_CN_FIRE = "\u706b\u5149"          # fire light
_CN_GATE = "\u57ce\u95e8"          # city gate
_CN_MERCHANT = "\u5546\u8d29"      # merchant
_CN_TREASURE = "\u5b9d\u7bb1"      # treasure box
_CN_SHIP = "\u8239"                # ship
_CN_STEELWALL = "\u94a2\u5899"     # steel wall
_CN_STEELDOOR = "\u94a2\u95e8"     # steel door
_CN_STONEWALL = "\u77f3\u5899"     # stone wall
_CN_BRIDGE = "\u6865"              # bridge
_CN_FENCE = "\u6805\u680f"         # fence
_CN_STREETLIGHT = "\u8def\u706f"   # street lamp
_CN_CANNON = "\u70ae"              # cannon
_CN_CURTAIN = "\u5e37\u5e55"       # curtain
_CN_SIGN = "\u62db\u724c"          # sign
_CN_CARRIAGE = "\u9a6c\u8f66"      # carriage
_CN_STRAW = "\u5e72\u8349"         # dry grass / straw
_CN_WATERSPOUT = "\u51fa\u6c34\u53e3"  # waterspout
_CN_WELL = "\u4e95"                # well
_CN_HANGING = "\u540a\u6302"       # hanging
_CN_STAIR = "\u9636\u68af"         # stairs
_CN_HOUSE = "\u623f\u5c4b"         # house
_CN_TENT = "\u5e10\u7bf7"          # tent
_CN_HOUSEWALL = "\u623f\u5899"     # house wall
_CN_HOUSEEtc = "\u623f\u5c4b\u9644\u5c5e"  # house accessory
_CN_LIGHT = "\u706f"               # lamp
_CN_POSEBOX = "\u59ff\u52bf\u7bb1"  # pose box
_CN_FURNITURE = "\u5bb6\u5177"      # furniture
_CN_CANDLE = "\u8721\u70db"         # candle
_CN_BEER = "\u5564\u9152"           # beer
_CN_STEELSTATUE = "\u94a2\u50cf"     # steel statue

# (type, model_name, category, short_desc)
_OBJ_TABLE = []
# trees 0..12
for _i in range(13):
    _OBJ_TABLE.append((_i, "Tree%02d" % (_i + 1), _TREE, _CN_TREE))
# grass 20..27
for _i in range(8):
    _OBJ_TABLE.append((20 + _i, "Grass%02d" % (_i + 1), _GRASS, _CN_GRASS))
# stone 30..34
for _i in range(5):
    _OBJ_TABLE.append((30 + _i, "Stone%02d" % (_i + 1), _STONE, _CN_STONE))
# statue 40..42
for _i in range(3):
    _OBJ_TABLE.append((40 + _i, "StoneStatue%02d" % (_i + 1), _STATUE, _CN_STATUE))
_OBJ_TABLE.append((43, "SteelStatue01", _STATUE, _CN_STEELSTATUE))
# tomb 44..46
for _i in range(3):
    _OBJ_TABLE.append((44 + _i, "Tomb%02d" % (_i + 1), _TOMB, _CN_TOMB))
# fire light 50..51 + bonfire 52
for _i in range(2):
    _OBJ_TABLE.append((50 + _i, "FireLight%02d" % (_i + 1), _FIRE, _CN_FIRE))
_OBJ_TABLE.append((52, "Bonfire01", _FIRE, _CN_FIRE))
# gate 55
_OBJ_TABLE.append((55, "DoungeonGate01", _STRUCTURE, _CN_GATE))
# merchant 56..57
for _i in range(2):
    _OBJ_TABLE.append((56 + _i, "MerchantAnimal%02d" % (_i + 1), _PROP, _CN_MERCHANT))
_OBJ_TABLE.append((58, "TreasureDrum01", _PROP, _CN_TREASURE))
_OBJ_TABLE.append((59, "TreasureChest01", _PROP, _CN_TREASURE))
# ship 60
_OBJ_TABLE.append((60, "Ship01", _STRUCTURE, _CN_SHIP))
# steel wall 65..67 + steel door 68
for _i in range(3):
    _OBJ_TABLE.append((65 + _i, "SteelWall%02d" % (_i + 1), _STRUCTURE, _CN_STEELWALL))
_OBJ_TABLE.append((68, "SteelDoor01", _STRUCTURE, _CN_STEELDOOR))
# stone wall 69..74
for _i in range(6):
    _OBJ_TABLE.append((69 + _i, "StoneWall%02d" % (_i + 1), _STRUCTURE, _CN_STONEWALL))
# stone mu wall 75..78
for _i in range(4):
    _OBJ_TABLE.append((75 + _i, "StoneMuWall%02d" % (_i + 1), _STRUCTURE, _CN_STONEWALL))
# bridge 80, fence 81..84, stone bridge 85
_OBJ_TABLE.append((80, "Bridge01", _BRIDGE, _CN_BRIDGE))
for _i in range(4):
    _OBJ_TABLE.append((81 + _i, "Fence%02d" % (_i + 1), _FENCE, _CN_FENCE))
_OBJ_TABLE.append((85, "BridgeStone01", _BRIDGE, _CN_BRIDGE))
# street light 90, cannon 91..93
_OBJ_TABLE.append((90, "StreetLight01", _LIGHT, _CN_STREETLIGHT))
for _i in range(3):
    _OBJ_TABLE.append((91 + _i, "Cannon%02d" % (_i + 1), _WAR, _CN_CANNON))
# curtain 95, sign 96..97
_OBJ_TABLE.append((95, "Curtain01", _PROP, _CN_CURTAIN))
for _i in range(2):
    _OBJ_TABLE.append((96 + _i, "Sign%02d" % (_i + 1), _PROP, _CN_SIGN))
# carriage 98..101
for _i in range(4):
    _OBJ_TABLE.append((98 + _i, "Carriage%02d" % (_i + 1), _PROP, _CN_CARRIAGE))
# straw 102..103
for _i in range(2):
    _OBJ_TABLE.append((102 + _i, "Straw%02d" % (_i + 1), _PROP, _CN_STRAW))
# waterspout 105, well 106..109
_OBJ_TABLE.append((105, "Waterspout01", _STRUCTURE, _CN_WATERSPOUT))
for _i in range(4):
    _OBJ_TABLE.append((106 + _i, "Well%02d" % (_i + 1), _STRUCTURE, _CN_WELL))
# hanging 110, stair 111
_OBJ_TABLE.append((110, "Hanging01", _PROP, _CN_HANGING))
_OBJ_TABLE.append((111, "Stair01", _STRUCTURE, _CN_STAIR))
# house 115..119
for _i in range(5):
    _OBJ_TABLE.append((115 + _i, "House%02d" % (_i + 1), _HOUSE, _CN_HOUSE))
# tent 120
_OBJ_TABLE.append((120, "Tent01", _HOUSE, _CN_TENT))
# house wall 121..126
for _i in range(6):
    _OBJ_TABLE.append((121 + _i, "HouseWall%02d" % (_i + 1), _HOUSE, _CN_HOUSEWALL))
# house etc 127..129
for _i in range(3):
    _OBJ_TABLE.append((127 + _i, "HouseEtc%02d" % (_i + 1), _HOUSE, _CN_HOUSEEtc))
# light 130..132
for _i in range(3):
    _OBJ_TABLE.append((130 + _i, "Light%02d" % (_i + 1), _LIGHT, _CN_LIGHT))
# pose box 133
_OBJ_TABLE.append((133, "PoseBox01", _PROP, _CN_POSEBOX))
# furniture 140..146
for _i in range(7):
    _OBJ_TABLE.append((140 + _i, "Furniture%02d" % (_i + 1), _FURNITURE, _CN_FURNITURE))
# candle 150, beer 151..153
_OBJ_TABLE.append((150, "Candle01", _LIGHT, _CN_CANDLE))
for _i in range(3):
    _OBJ_TABLE.append((151 + _i, "Beer%02d" % (_i + 1), _DRINK, _CN_BEER))

# --- precompute once at import so the enum callback does ZERO runtime string
# assembly (avoids any byte/encoding mishap in running-generated Chinese). ---
# The visible label starts with the type number so the user always knows which
# number each entry maps to (important when typing a custom type number).
_ENUM_ITEMS = []
_LABEL_MAP = {}
for (_num, _mname, _cat, _desclabel) in _OBJ_TABLE:
    _label = (str(_num) + u" " + _desclabel + u" " + _mname)
    _tip = (_cat + u" " + _mname + u" (" + str(_num) + u")")
    _ENUM_ITEMS.append(("t%d" % _num, _label, _tip))
    _LABEL_MAP[_num] = (_desclabel + u" " + _mname + u" (" + str(_num) + u")")
_ENUM_ITEMS.append((
    "custom",
    "\u81ea\u5b9a\u4e49\u7c7b\u578b",
    "\u4f7f\u7528\u4e0b\u65b9\u6570\u5b57\u8f93\u5165\u4efb\u610f\u7c7b\u578b\u7f16\u53f7",
))


def model_name_for_type(t):
    """Return the model name (no extension) for a numerical type, or None."""
    for (num, name, _cat, _desc) in _OBJ_TABLE:
        if num == t:
            return name
    return None


def label_for_type(t):
    """Return a friendly label: 'desc modelname (type)' or 'Type N'."""
    if t in _LABEL_MAP:
        return _LABEL_MAP[t]
    return "\u7c7b\u578b %d" % t   # "Type {t}"


def object_type_enum():
    """Return the precomputed Blender EnumProperty items list.

    The 'custom' entry lets the user place a type number that isn't in the
    known table.  Identifiers are strings encoding the integer so Blender's
    enum can round-trip them safely (e.g. 't12', 'custom').
    """
    return list(_ENUM_ITEMS)


def _scan_world_items(data_dir, world_id):
    """For a non-Lorencia world, list every type that actually has a model.

    The game resolves an object record's type to a BMD by the uniform
    convention `Object{world}/Object{(type+1):02}.bmd`, so the per-world "type
    list" is just the files present in that world's Object folder. We list
    those type numbers (with the file name as the label), so the user knows
    which numbers exist and a custom number cannot collide with them.
    Returns a list of (identifier, label, tooltip) for all found types.
    """
    items = []
    world_obj = os.path.join(str(data_dir or ""), "Object%d" % world_id)
    if not os.path.isdir(world_obj):
        return items
    try:
        names = os.listdir(world_obj)
    except OSError:
        return items
    seen = set()
    for fn in names:
        low = fn.lower()
        if not low.endswith(".bmd"):
            continue
        stem = fn[:-4]                       # e.g. "Object13"
        if len(stem) < 6 or not stem.startswith("Object"):
            continue
        num_part = stem[6:]
        if not num_part.isdigit():
            continue
        n = int(num_part)                    # n = type + 1
        t = n - 1
        if t in seen:
            continue
        seen.add(t)
        items.append(("t%d" % t,
                      str(t) + "  " + fn,
                      "Object%d/%s.bmd" % (world_id, stem)))
    items.sort(key=lambda it: it[2])
    return items


def object_type_enum_for_world(world_id, data_dir=None):
    """Return the enum items appropriate for the given world.

    World 1 (Lorencia) has a named table (Chinese labels). Every other world
    has no name table - its object types are simply whatever `Object{world}/`
    contains, so we scan that folder. This guarantees the numbers offered in
    the dropdown are real for the current world and a 'custom' typed number
    cannot silently collide with a defined one.
    """
    if int(world_id or 0) == 1:
        return list(_ENUM_ITEMS)
    items = _scan_world_items(data_dir, int(world_id or 0))
    items.append((
        "custom",
        "\u81ea\u5b9a\u4e49\u7c7b\u578b",
        "\u4f7f\u7528\u4e0b\u65b9\u6570\u5b57\u8f93\u5165\u4efb\u610f\u7c7b\u578b\u7f16\u53f7",
    ))
    return items


def enum_to_type(enum_value, custom_number=0):
    """Convert an enum identifier ('t%d' or 'custom') back to an int type."""
    if enum_value and enum_value.startswith("t"):
        try:
            return int(enum_value[1:])
        except ValueError:
            return 0
    return int(custom_number) if custom_number else 0


def type_to_enum(t):
    """Find the enum identifier for a numeric type; 'custom' if unknown."""
    if model_name_for_type(t) is not None:
        return "t%d" % t
    return "custom"
