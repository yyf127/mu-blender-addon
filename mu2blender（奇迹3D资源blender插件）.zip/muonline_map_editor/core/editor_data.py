# -*- coding: utf-8 -*-
"""In-memory map editing model for the muonline_map_editor addon.

Holds every 256x256 terrain grid the game world editor edits, plus the ground
object table and the file metadata needed to write everything back with the
same encryption/format as the source files.
"""

from ..formats.att import TerrainAttributeData
from ..formats.mapdata import TerrainMappingData
from ..formats.objdata import OBJData

TERRAIN_SIZE = 256
TERRAIN_SCALE = 100.0


class FileMeta:
    """How one source file was encrypted/structured, so save_map can write it
    back identically (byte-for-byte when nothing changed)."""

    __slots__ = ("kind", "use_modulus", "algorithm_2", "algorithm_1",
                 "key_2", "file_type", "version", "is_192k")

    def __init__(self, kind, use_modulus=True, algorithm_2=3, algorithm_1=4,
                 key_2=None, file_type="BM6", version=0, is_192k=False):
        self.kind = kind            # 'att' | 'map' | 'light' | 'height'
        self.use_modulus = use_modulus
        self.algorithm_2 = algorithm_2
        self.algorithm_1 = algorithm_1
        self.key_2 = key_2
        self.file_type = file_type  # 'BM6' | 'BM8' (ozb only)
        self.version = version      # ozb version byte
        self.is_192k = is_192k      # height stored as 24-bit rgb

    def copy(self):
        return FileMeta(self.kind, self.use_modulus, self.algorithm_2,
                        self.algorithm_1, self.key_2, self.file_type,
                        self.version, self.is_192k)


class MapEditorData:
    """The whole editable state of one map."""

    def __init__(self, world_id=1, data_dir=""):
        self.world_id = world_id
        self.data_dir = data_dir

        self.att = TerrainAttributeData()
        self.mapping = TerrainMappingData()
        # float heights (BackTerrainHeight) and light (0..1 RGB), 256x256
        self.height = [0.0] * (TERRAIN_SIZE * TERRAIN_SIZE)
        self.light = [(1.0, 1.0, 1.0)] * (TERRAIN_SIZE * TERRAIN_SIZE)
        self.objects = OBJData()

        self.att_meta = FileMeta('att')
        self.map_meta = FileMeta('map')
        self.light_meta = FileMeta('light')
        self.height_meta = FileMeta('height')

        # Blender scene references (filled by load_map / terrain_build)
        self.scene_collection = None
        self.terrain_obj = None
        self.object_collection = None
        self.tile_textures = {}     # idx -> PIL Image (decoded tile texture)

    # -- helpers -----------------------------------------------------------
    def cell(self, x, y):
        """Terrain index with wrapping (same as TERRAIN_INDEX_REPEAT)."""
        return (y & (TERRAIN_SIZE - 1)) * TERRAIN_SIZE + (x & (TERRAIN_SIZE - 1))

    def get_height(self, x, y):
        return self.height[self.cell(x, y)]

    def set_height(self, x, y, v):
        self.height[self.cell(x, y)] = v

    def get_light(self, x, y):
        return self.light[self.cell(x, y)]

    def set_light(self, x, y, rgb):
        self.light[self.cell(x, y)] = rgb

    def layer1(self, x, y):
        return self.mapping.layer1[self.cell(x, y)]

    def set_layer1(self, x, y, v):
        self.mapping.layer1[self.cell(x, y)] = v

    def layer2(self, x, y):
        return self.mapping.layer2[self.cell(x, y)]

    def set_layer2(self, x, y, v):
        self.mapping.layer2[self.cell(x, y)] = v

    def alpha(self, x, y):
        return self.mapping.alpha[self.cell(x, y)]

    def set_alpha(self, x, y, v):
        self.mapping.alpha[self.cell(x, y)] = int(max(0, min(255, v)))

    def wall(self, x, y):
        return self.att.terrain_wall[self.cell(x, y)]

    def set_wall(self, x, y, v):
        self.att.terrain_wall[self.cell(x, y)] = v


# The Blender collection that holds the map's ground-object models is named by
# the importer (load_map.C_OBJECTS, a Chinese literal).  It is stored as a
# direct bpy ref on MapEditorData.object_collection, which can go stale
# (ReferenceError "StructRNA ... has been removed") once the collection is
# deleted/recreated, e.g. by clear_editor_scene() on a re-import.  To avoid
# duplicating the Chinese name here (and re-introducing an encoding trap), we
# import the canonical name from the importer at call time.


def resolve_object_collection(data):
    """Return a *live* bpy Collection for the map's objects, or None.

    Never return the stored `data.object_collection` reference directly: it can
    point to a collection that was already removed (which raises ReferenceError
    on access).  We validate the stored ref is still present in bpy.data, and
    otherwise look the objects collection up by its canonical name so a
    recreated collection is found.
    """
    try:
        import bpy
    except Exception:
        return None
    # Canonical objects-collection name (Chinese) lives in the importer.
    try:
        from ..importer import load_map as _lm
        col_name = _lm.C_OBJECTS
    except Exception:
        col_name = None
    col = getattr(data, "object_collection", None)
    if col is not None:
        try:
            if col.name in bpy.data.collections:
                return bpy.data.collections[col.name]
        except ReferenceError:
            pass
    if col_name is not None:
        try:
            return bpy.data.collections.get(col_name)
        except Exception:
            return None
    return None

