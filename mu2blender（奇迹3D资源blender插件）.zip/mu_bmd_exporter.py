# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

"""
奇迹 MU Online BMD 模型导出插件 (静态_?__?)
基于 muonline-bmd-viewer 项目分析_? BMD/OZJ/OZT 二进制格式实现_?

BMD 格式 (明文 version=10 / 0x0A):
  - 4字节_?: "BMD" + version(uint8)
  - 32字节模型_?
  - uint16 meshCount, uint16 boneCount, uint16 actionCount
  - 每个Mesh: 顶点(16B) + 法线(20B) + UV(8B) + 三_?__?(64B) + 32B纹理_?
  - Actions(动画): 静态_?__?1个action, 1_?
  - Bones: 骨_?__?(32B) + 父索_?(int16) + 位置/旋转帧数_?

OZJ 格式 (JPEG容器, C# OZJReader):
  - 24字节头部 + JPEG原_?_数_?
  - 偏移0-3: magicNumber, 4-5: version, 6-9: format("JPEG")
  - 偏移17: topDownSort标志 (1=正常, 0=需垂直翻转)
  - 偏移24+: JPEG原_?_数_?

OZT 格式 (原_?_像_?, C# OZTReader):
  - 16字节头部 + int16_? + int16_? + uint8深度(32) + uint8保留
  - 偏移22+: top-down 行序_? RGBA 像素数据
"""

import bpy
import bmesh
import struct
import os
import math
import mathutils
import tempfile
import shutil
from bpy_extras.io_utils import ExportHelper
from bpy.props import StringProperty, BoolProperty, IntProperty, EnumProperty, FloatProperty
from bpy.types import Operator

bl_info = {
    "name": "MU Online BMD Exporter",
    "author": "Based on muonline-bmd-viewer format analysis",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "File > Export > MU Online BMD (.bmd)",
    "description": "导出静_? BMD 模型_? OZJ/OZT 纹理 (奇迹MU客户_?格式)",
    "category": "Import-Export",
}


# ============================================================
#  工具函数
# ============================================================

def coord_blender_to_bmd(x, y, z):
    """Blender 坐标直接输出 (不做轴旋_?, 用户模型已在正确坐标_?)"""
    return (x, y, z)


def compute_mesh_bounds(mesh_objects):
    """计算所有网格的合并包围_? (Blender 世界坐标)
    返回 (min_x, min_y, min_z, max_x, max_y, max_z)
    """
    min_x = min_y = min_z = float('inf')
    max_x = max_y = max_z = float('-inf')
    for mesh_obj in mesh_objects:
        matrix_world = mesh_obj.matrix_world
        for vert in mesh_obj.data.vertices:
            world_pos = matrix_world @ vert.co
            min_x = min(min_x, world_pos.x)
            min_y = min(min_y, world_pos.y)
            min_z = min(min_z, world_pos.z)
            max_x = max(max_x, world_pos.x)
            max_y = max(max_y, world_pos.y)
            max_z = max(max_z, world_pos.z)
    if min_x == float('inf'):
        return (0, 0, 0, 0, 0, 0)
    return (min_x, min_y, min_z, max_x, max_y, max_z)


def compute_bottom_center_origin(mesh_objects):
    """计算模型底面_?心作为原点偏_? (Blender 坐标_?)
    底面 = Z 最小值平_?, _?_? = X/Y 的中_?
    返回 (offset_x, offset_y, offset_z)
    """
    min_x, min_y, min_z, max_x, max_y, max_z = compute_mesh_bounds(mesh_objects)
    center_x = (min_x + max_x) * 0.5
    center_y = (min_y + max_y) * 0.5
    return (center_x, center_y, min_z)


def vec_blender_to_bmd(v):
    return coord_blender_to_bmd(v.x, v.y, v.z)


def euler_blender_to_bmd(euler):
    """Blender 欧拉角转 BMD 角度 (直接输出)"""
    return (euler.x, euler.y, euler.z)


def write_fixed_string(buf, text, length):
    """写入定长 ASCII 字_?__? (null-terminated, 不足_?0)"""
    encoded = text.encode('ascii', errors='replace')[:length - 1]
    buf += encoded
    buf += b'\x00' * (length - len(encoded))
    return buf


def find_armature_from_mesh(mesh_obj):
    """从网格向上查_? Armature (通过_?改器或父_?)"""
    for mod in mesh_obj.modifiers:
        if mod.type == 'ARMATURE' and mod.object:
            return mod.object
    # 否则无法分辨层级
    if mesh_obj.parent and mesh_obj.parent.type == 'ARMATURE':
        return mesh_obj.parent
    return None


def collect_mesh_objects(selected_objects, armature, scene=None):
    """收集要_?_出的所有网格_?__?
    1. 遍历选中对象及其子级
    2. 补全绑定_? Armature 的网_? (无_?_架_?)
    3. 显式绑定 Armature 的网_?
    4. 处理 selected_only=False, 从场_?收集
    """
    meshes = []
    selected_set = set(selected_objects)

    # 遍历选择对象及子_?
    for obj in selected_objects:
        stack = [obj]
        while stack:
            current = stack.pop()
            if current.type == 'MESH':
                meshes.append(current)
            stack.extend(current.children)

    # 若有 Armature, 补全所有与其绑定的网格 (同时技_?在范围内)
    if armature:
        search_scope = scene.objects if scene else selected_set
        for obj in search_scope:
            if obj.type != 'MESH':
                continue
            # 找到 Armature 的网_?
            for mod in obj.modifiers:
                if mod.type == 'ARMATURE' and mod.object == armature:
                    meshes.append(obj)
                    break
            else:
                # 否则_? Armature 的直接子绑定
                if obj.parent == armature:
                    meshes.append(obj)

    # 去重 (同一网格_?能_??多_?_收_?, 保畡_?一次出现的)
    seen = set()
    unique = []
    for m in meshes:
        if m.name not in seen:
            seen.add(m.name)
            unique.append(m)
    return unique


def _image_has_alpha(image):
    """True if the texture carries (or plausibly uses) an alpha channel.

    The game client marks a mesh two-sided when its loaded texture has 4
    components (ModelObject: _meshIsRGBA = tex.Components == 4) and culls the
    back face otherwise (CullClockwiseFace).  A .ozj is always JPEG (3
    components, no alpha), so a flat single-layer cloth/flag/banner mesh
    exported as .ozj gets back-face culled and VANISHES in-game.  Exporting
    it as .ozt (RGBA, 4 components) makes the game render it from both sides.
    """
    if image is None:
        return False
    # A .tga source is inherently alpha-capable (the game treats tga as .ozt).
    try:
        p = (getattr(image, "filepath", "") or "").lower()
        if p.endswith(".tga"):
            return True
    except Exception:
        pass
    # Otherwise report transparency only if any pixel is really non-opaque.
    # This keeps fully-opaque textures as .ozj (3-comp -> bright solid pass);
    # making them .ozt puts them in the transparent/alpha pass and they render
    # DARK in-game while viewers/Blender (raw bytes) still look correct.
    try:
        w = image.size[0]
        h = image.size[1]
        if w > 0 and h > 0:
            px = [0.0] * (w * h * 4)
            image.pixels.foreach_get(px)
            for i in range(3, w * h * 4, 4):
                if px[i] < 0.99:
                    return True
            return False
    except Exception:
        pass
    return False


def get_texture_from_mesh(mesh_obj):
    """From a mesh return its first texture image (image, filepath, is_tga).

    `is_tga` is ALWAYS True: every source texture is converted to TGA and
    exported as .ozt (RGBA, 4 components).  This keeps single-layer / flat
    meshes (cloth, flags, banners, planes) visible in-game: the game renders
    .ozt (Components==4) meshes double-sided, so a plane is not back-face
    culled.  If we exported an opaque plane as .ozj (3-comp, one-sided) it
    would VANISH (back-face culled).  User confirmed the all-.ozt approach is
    the correct one.
    """
    if not mesh_obj.material_slots:
        return None, None, False
    for slot in mesh_obj.material_slots:
        mat = slot.material
        if not mat or not mat.use_nodes:
            continue
        for node in mat.node_tree.nodes:
            if node.type == 'TEX_IMAGE' and node.image:
                img = node.image
                fpath = bpy.path.abspath(img.filepath) if img.filepath else ""
                return img, fpath, True
    return None, None, False


def triangulate_mesh(mesh_obj):
    """将网格三角化, 返回 bmesh (使用原_?_数_?, 不应用Armature_?改器, _?_? bind pose)"""
    bm = bmesh.new()
    # _? mesh 创建 bmesh 并三角化 (不应用Armature_?改器, _?_? bind pose)
    bm.from_mesh(mesh_obj.data)
    bmesh.ops.triangulate(bm, faces=bm.faces[:])
    return bm


def get_vertex_bone_index(vertex_index, mesh_obj, armature, bone_name_to_index):
    """从顶点组取得最大权重的骨_?__?_? (BMD 架构里每_?顶点_?能属于一_?骨_??)
    vertex_index: 原_?? mesh 顶点的索_?
    """
    if not armature or not mesh_obj.vertex_groups:
        return 0
    mesh_data = mesh_obj.data
    if vertex_index >= len(mesh_data.vertices):
        return 0
    vert = mesh_data.vertices[vertex_index]
    if not vert.groups:
        return 0
    # 处理顶点并获取_?__?__?_?
    max_weight = 0.0
    best_group_idx = -1
    for g in vert.groups:
        if g.weight > max_weight:
            max_weight = g.weight
            best_group_idx = g.group
    if best_group_idx < 0 or best_group_idx >= len(mesh_obj.vertex_groups):
        return 0
    group_name = mesh_obj.vertex_groups[best_group_idx].name
    return bone_name_to_index.get(group_name, 0)


# ============================================================
#  纹理_?_?: JPG _? -> OZJ
# ============================================================

MAX_TEXTURE_SIZE = 1024  # C# 客户_? OZJReader/OZTReader 尺_?_上限每_? <=1024


def _next_power_of_two(value):
    """返回 >= value 的最_? 2 的幂次方"""
    p = 1
    while p < value:
        p *= 2
    return p


def _closest_standard_ratio(w, h):
    """找到最接近的标准比_? (长边/_?_?: 1, 2, 4, 8, 16)"""
    ratio = max(w, h) / min(w, h) if min(w, h) > 0 else 16.0
    standard_ratios = [1.0, 2.0, 4.0, 8.0, 16.0]
    closest = min(standard_ratios, key=lambda r: abs(r - ratio))
    return closest


def prepare_texture(image):
    """准_?_纹_?: 拉伸到最接近的标准比_?, 且长宽均_? 2 的幂次方且不超过 1024

    标准比例: 1:1, 1:2, 2:1, 1:4, 4:1, 1:8, 8:1, 1:16, 16:1
    所有纹理最终都_?标准比例 + 2 的幂次方, 直接拉伸 (不填_?), UV 不变_?

    返回 (处理后的image, u_scale=1.0, v_scale=1.0, is_new_image)
    """
    w, h = image.size[0], image.size[1]

    # 1. 找到最接近的标准比_?
    std_ratio = _closest_standard_ratio(w, h)

    # 2. _?定长边目标尺_? (2的幂次方, 不超_?1024)
    long_side = max(w, h)
    if long_side > MAX_TEXTURE_SIZE:
        target_long = MAX_TEXTURE_SIZE
    else:
        target_long = min(_next_power_of_two(long_side), MAX_TEXTURE_SIZE)

    # 3. _?_? = 长边 / 标准比例 (标准比例_?2的幂次方, 所以短边也_?2的幂次方)
    target_short = max(1, int(target_long / std_ratio))

    # 4. 保持宽高方向
    if w >= h:
        new_w, new_h = target_long, target_short
    else:
        new_w, new_h = target_short, target_long

    # 5. 尺_?_一致则直接返回
    if w == new_w and h == new_h:
        return image, 1.0, 1.0, False

    # 6. 直接拉伸到目标尺_?
    scaled = image.copy()
    scaled.scale(new_w, new_h)
    return scaled, 1.0, 1.0, True


def convert_image_to_jpg_bytes(image, quality=90):
    """_? Blender Image _?_?_? JPEG 字节数据
    不修_? image.file_format (DDS等格式_?_属性无效会报错),
    改用 scene.render.image_settings 控制输出格式_?
    """
    tmpdir = tempfile.mkdtemp(prefix="mu_bmd_")
    try:
        tmp_path = os.path.join(tmpdir, "temp_output.jpg")
        scene = bpy.context.scene
        render_settings = scene.render.image_settings

        # 保存原_?_渲染_?__?
        old_file_format = render_settings.file_format
        old_quality = render_settings.quality

        try:
            render_settings.file_format = 'JPEG'
            render_settings.quality = quality
            image.save_render(tmp_path, scene=scene)
        finally:
            # _?_?_渲染_?__? (用上下文 try 包裹, 防_?_旧值无_?)
            try:
                render_settings.file_format = old_file_format
            except Exception:
                render_settings.file_format = 'PNG'
            render_settings.quality = old_quality

        if not os.path.exists(tmp_path) or os.path.getsize(tmp_path) == 0:
            raise RuntimeError("save_render _?生成有效_? JPEG 文件")

        with open(tmp_path, 'rb') as f:
            return f.read()
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def write_ozj(output_path, jpeg_bytes, width, height):
    """写入 OZJ 文件: 24字节头部 + JPEG数据
    C# OZJReader 格式:
      0-3:  magicNumber (uint32)
      4-5:  version (int16)
      6-9:  format (4字节ASCII)
      10-16: 保留
      17:   isTopDownSort (bool, 1=正常)
      18-23: 保留
      24+:  JPEG原_?_数_?
    """
    with open(output_path, 'wb') as f:
        # 0-3: magicNumber
        f.write(struct.pack('<I', 0))
        # 4-5: version
        f.write(struct.pack('<h', 0))
        # 6-9: format (4字节)
        f.write(b'JPEG')
        # 10-16: 保留 (7字节)
        f.write(b'\x00' * 7)
        # 17: isTopDownSort (1=正常顺序, 不需要翻_?)
        f.write(struct.pack('<B', 1))
        # 18-23: 保留 (6字节)
        f.write(b'\x00' * 6)
        # 24+: JPEG 原_?_数_?
        f.write(jpeg_bytes)


def _mesh_has_open_edges(mesh_obj):
    """True if the mesh has any boundary / non-manifold edge (an edge shared by
    fewer than two faces).  Open surfaces (single-layer sheets, joined thin
    panels) leave such edges and must be double-layered so both sides are lit;
    closed watertight solids have none and must NOT be doubled (doubling them
    creates dark inner faces and darkens otherwise-correct solid models).
    """
    try:
        if mesh_obj is None or mesh_obj.data is None or not mesh_obj.data.polygons:
            return False
        bm = bmesh.new()
        try:
            bm.from_mesh(mesh_obj.data)
            for e in bm.edges:
                if not e.is_manifold:
                    return True
            return False
        finally:
            bm.free()
    except Exception:
        return False


# ============================================================
#  纹理_?_?: TGA/Image -> OZT
# ============================================================

def convert_image_to_ozt(output_path, image, brightness=1.0):
    """_? Blender Image _?_?_? OZT
    C# OZTReader 格式:
      0-15:  头部 (跳过)
      16-17: width (int16 LE)
      18-19: height (int16 LE)
      20:    depth (必须=32)
      21:    保留
      22+:   像素数据 (top-down 行序, RGBA 字节_?)
    C# 读取后会_? RGBA _?_? BGRA 存储, 并翻_?行序_? bottom-up
    """
    width = image.size[0]
    height = image.size[1]
    # 获取像素数据 (Blender: RGBA float32, top-down)
    pixels = list(image.pixels)
    # _?_?_? RGBA uint8, top-down 行序 (与文件格式一_?)
    pixel_data = bytearray()
    for y in range(height):  # top-down
        row_offset = y * width * 4
        for x in range(width):
            idx = row_offset + x * 4
            r = int(max(0.0, min(1.0, pixels[idx])) * 255 * brightness)
            g = int(max(0.0, min(1.0, pixels[idx + 1])) * 255 * brightness)
            b = int(max(0.0, min(1.0, pixels[idx + 2])) * 255 * brightness)
            a = int(max(0.0, min(1.0, pixels[idx + 3])) * 255)
            r = min(255, r); g = min(255, g); b = min(255, b)
            # OZT pixel layout is B,G,R,A (the viewer/C# OZTReader reads
            # b=src[0]; g=src[1]; r=src[2]; a=src[3]).  Writing RGBA here made
            # R and B swap on load (red showed as blue, blue as red).
            pixel_data.extend([b, g, r, a])  # BGRA (file format)

    with open(output_path, 'wb') as f:
        # 0-15: 头部 (16字节)
        f.write(b'\x00' * 16)
        # 16-17: _? (int16 LE)
        f.write(struct.pack('<h', width))
        # 18-19: _? (int16 LE)
        f.write(struct.pack('<h', height))
        # 20: 深度 (32 = RGBA)
        f.write(struct.pack('<B', 32))
        # 21: 保留
        f.write(struct.pack('<B', 0))
        # 22+: RGBA 像素数据 (top-down)
        f.write(pixel_data)




def _is_single_layer_mesh(mesh_obj, thickness_ratio=0.08):
    """True if the mesh is essentially a flat single-layer surface (a plane,
    cloth, flag...) rather than a volumetric solid.  Used to apply a modest
    brightness boost because the game renders flat .ozt (double-sided) meshes
    darker than viewers/Blender show them.

    Robust method: use a mesh face as the reference normal (any face works for
    a genuinely flat mesh since all faces are coplanar) and project every
    vertex onto it.  Flat -> thickness ~0; solid body -> spans it -> not flat.
    This also handles arbitrarily rotated / tilted planes.
    """
    try:
        if mesh_obj is None or mesh_obj.data is None or not mesh_obj.data.polygons:
            return False
        me = mesh_obj.data
        mw = mesh_obj.matrix_world
        mw3 = mw.to_3x3()
        # reference normal from the first face
        n = mw3 @ me.polygons[0].normal
        if n.length_squared <= 1e-12:
            return False
        n = n.normalized()
        verts = me.vertices
        vcount = len(verts)
        if vcount == 0:
            return False
        cx = cy = cz = 0.0
        for v in verts:
            wp = mw @ v.co
            cx += wp.x; cy += wp.y; cz += wp.z
        cx /= vcount; cy /= vcount; cz /= vcount
        cent = mathutils.Vector((cx, cy, cz))
        lo = 1e18; hi = -1e18
        max_inplane = 0.0
        for v in verts:
            wp = mw @ v.co
            d = (wp - cent).dot(n)
            if d < lo: lo = d
            if d > hi: hi = d
            rel = wp - cent - (n * d)
            rlen = rel.length
            if rlen > max_inplane: max_inplane = rlen
        thickness = hi - lo
        if max_inplane <= 1e-6:
            return False
        return (thickness / max_inplane) < thickness_ratio
    except Exception:
        return False

# ============================================================
#  BMD 数据结构
# ============================================================

class BMDVertex:
    __slots__ = ('node', 'x', 'y', 'z')

    def __init__(self, node, x, y, z):
        self.node = node
        self.x = x
        self.y = y
        self.z = z


class BMDNormal:
    __slots__ = ('node', 'nx', 'ny', 'nz', 'bind_vertex')

    def __init__(self, node, nx, ny, nz, bind_vertex):
        self.node = node
        self.nx = nx
        self.ny = ny
        self.nz = nz
        self.bind_vertex = bind_vertex


class BMDTexCoord:
    __slots__ = ('u', 'v')

    def __init__(self, u, v):
        self.u = u
        self.v = v


class BMDTriangle:
    __slots__ = ('polygon', 'vertex_index', 'normal_index', 'texcoord_index')

    def __init__(self):
        self.polygon = 3
        self.vertex_index = [0, 0, 0, 0]
        self.normal_index = [0, 0, 0, 0]
        self.texcoord_index = [0, 0, 0, 0]


class BMDMesh:
    def __init__(self, texture_path):
        self.texture_path = texture_path
        self.texture_index = 0
        self.vertices = []
        self.normals = []
        self.texcoords = []
        self.triangles = []


class BMDBone:
    def __init__(self, name, parent):
        self.name = name
        self.parent = parent
        self.is_dummy = False
        self.position = (0.0, 0.0, 0.0)
        self.rotation = (0.0, 0.0, 0.0)


# ============================================================
#  网格合并 (层级收缩: 按纹理分_?)
# ============================================================

def merge_meshes_by_texture(mesh_objects, armature, bone_name_to_index, texture_name_map, origin_offset=(0, 0, 0), scale=1.0, name_prefix=""):
    """
    按纹理分组合并网_? (_?动收缩层_?)_?
    相同纹理的网格合并为一_? BMDMesh_?
    返回 (bmd_meshes列表, 纹理文件列表)
    """
    groups = {}  # key: 纹理文件名, value: 网格列表
    texture_info = {}  # 纹理文件名 -> (processed_image, is_tga, u_scale, v_scale, is_new_img)
    # Game-client fix: when DIFFERENT models share the same source texture, the
    # client resolves textures by file name per object type.  If we merge them
    # into one shared file, the first type to load claims that name and later
    # types fail to load.  So we give every mesh object its OWN unique texture
    # file name (base, base_2, base_3, ...) -- never reused across models.
    used_tex_names = set()
    tex_counter = iter(range(1, 1 << 30))

    for mesh_obj in mesh_objects:
        img, fpath, is_tga = get_texture_from_mesh(mesh_obj)
        if img is None:
            tex_name = "default.ozj"
            if tex_name not in texture_info:
                texture_info[tex_name] = (None, False, 1.0, 1.0, False, False)
        else:
            base_name = os.path.splitext(os.path.basename(fpath or img.name))[0]
            # Every texture is exported as .ozt (RGBA) so single-layer / flat
            # meshes stay double-sided and visible in-game (see
            # get_texture_from_mesh).  No texture is written as .ozj.
            ext = '.ozt'
            # Texture file name = f"{bmd_name}_{tex_base}" so each exported
            # model's textures are distinct in the same folder and easy to
            # associate with its model.  Collisions (same model + same base,
            # or repeated export into one folder) get a _1/_2 suffix so files
            # are never overwritten.
            # Cap the stem so stem + '.jpg'/'.tga'/'.ozj'/'.ozt' always fits the
            # BMD's fixed 32-byte texture_path field (io_scene_muonline caps at
            # 28).  Otherwise a long model-name prefix makes the BMD path get
            # truncated while the on-disk .ozj keeps the long name, and the
            # game cannot find the texture.
            # Texture file name = f"{bmd_name}_N" where N is a running index
            # (1, 2, 3, ...).  Using ONLY the BMD name + index (not the original
            # texture name) keeps the name short -- it always fits the BMD's
            # 32-byte texture_path field -- and unique per exported model, so no
            # texture fails to load from long or colliding original names.
            nbase = (name_prefix or "tex")[:24].rstrip("_") or "tex"
            n = next(tex_counter)
            while ("%s_%d%s" % (nbase, n, ext)) in used_tex_names:
                n = next(tex_counter)
            tex_name = "%s_%d%s" % (nbase, n, ext)
            used_tex_names.add(tex_name)
            if tex_name not in texture_info:
                # 处理纹理并预处理 (原始尺寸+2的幂次方)
                proc_img, u_scale, v_scale, is_new = prepare_texture(img)
                texture_info[tex_name] = (proc_img, is_tga, u_scale, v_scale, is_new, _is_single_layer_mesh(mesh_obj))
        if tex_name not in groups:
            groups[tex_name] = []
        groups[tex_name].append(mesh_obj)

    bmd_meshes = []
    texture_list = []

    for tex_name, obj_list in groups.items():
        # BMD _?_? texturePath: OZJ_?.jpg后缀, OZT_?.tga后缀
        # 客户_?会自动把 .jpg_?.ozj, .tga_?.ozt 查找实际文件
        proc_img, is_tga, u_scale, v_scale, is_new_img, is_flat = texture_info[tex_name]
        base_name = os.path.splitext(tex_name)[0]
        tex_path_bmd = base_name + ('.tga' if is_tga else '.jpg')
        bmd_mesh = BMDMesh(tex_path_bmd)
        texture_list.append((tex_name, proc_img, is_tga, is_new_img, is_flat))

        # 用于去重顶点/法线/UV的映_?
        vertex_cache = {}
        normal_cache = {}
        uv_cache = {}

        for mesh_obj in obj_list:
            bm = triangulate_mesh(mesh_obj)
            try:
                # _?保有 UV _?
                if not bm.loops.layers.uv:
                    bm.loops.layers.uv.new()
                uv_layer = bm.loops.layers.uv.active

                # 获取世界空间矩阵 (如果父级_?骨_??, 使用物体_?_?变换)
                matrix_world = mesh_obj.matrix_world
                # A negative-determinant world matrix means the object is
                # mirrored (negative scale on an axis); we flip the UV U axis
                # later to compensate for the mirrored baked geometry.
                try:
                    mirror_u = matrix_world.determinant() < 0.0
                except Exception:
                    mirror_u = False

                # 处理顶点
                vertex_local_to_bmd = {}  # bmvert index -> BMD vertex index
                for bmvert in bm.verts:
                    # 处理顶点
                    world_pos = matrix_world @ bmvert.co
                    # 处理顶点 (通过原_?? mesh 顶点索引获取骨_?__?)
                    ox, oy, oz = origin_offset
                    px = (world_pos.x - ox) * scale
                    py = (world_pos.y - oy) * scale
                    pz = (world_pos.z - oz) * scale
                    bx, by, bz = coord_blender_to_bmd(px, py, pz)
                    # 获取骨_?__?_? (通过原_?_mesh顶点索引获取顶点_?)
                    bone_idx = get_vertex_bone_index(bmvert.index, mesh_obj, armature, bone_name_to_index)
                    key = (bone_idx, round(bx, 6), round(by, 6), round(bz, 6))
                    if key in vertex_cache:
                        v_idx = vertex_cache[key]
                    else:
                        v_idx = len(bmd_mesh.vertices)
                        bmd_mesh.vertices.append(BMDVertex(bone_idx, bx, by, bz))
                        vertex_cache[key] = v_idx
                    vertex_local_to_bmd[bmvert.index] = v_idx

                # 处理_? (三_?__?)
                for face in bm.faces:
                    tri = BMDTriangle()
                    tri.polygon = 3
                    for i, loop in enumerate(face.loops[:3]):
                        bmvert = loop.vert
                        v_idx = vertex_local_to_bmd[bmvert.index]

                        # 法线 (世界空间)
                        world_normal = matrix_world.to_3x3() @ bmvert.normal
                        world_normal.normalize()
                        nx, ny, nz = coord_blender_to_bmd(world_normal.x, world_normal.y, world_normal.z)
                        nkey = (round(nx, 6), round(ny, 6), round(nz, 6), v_idx)
                        if nkey in normal_cache:
                            n_idx = normal_cache[nkey]
                        else:
                            n_idx = len(bmd_mesh.normals)
                            bmd_mesh.normals.append(BMDNormal(
                                bmd_mesh.vertices[v_idx].node,
                                nx, ny, nz, v_idx
                            ))
                            normal_cache[nkey] = n_idx

                        # UV (应用纹理_?充后的缩放因_?, _?采样有效区域)
                        # Mirror fix: when this object's world matrix has a
                        # negative determinant (e.g. scaled by -1 on an axis),
                        # the baked geometry is mirrored.  Blender leaves the
                        # UVs un-mirrored, so we must flip U (u -> 1-u) so the
                        # texture reads correctly through the mirror.
                        uv = loop[uv_layer].uv
                        # Mirror: negative world determinant => object is
                        # mirrored (negative scale), so the baked geometry is
                        # reflected.  Flip U so the texture reads correctly.
                        u_in = (1.0 - uv.x) if mirror_u else uv.x
                        # Match io_scene_muonline: Blender v=0 bottom ->
                        # BMD v=0 top (MU texture convention is top-down).
                        v_in = 1.0 - uv.y
                        scaled_u = u_in * u_scale
                        scaled_v = v_in * v_scale
                        ukey = (round(scaled_u, 6), round(scaled_v, 6))
                        if ukey in uv_cache:
                            t_idx = uv_cache[ukey]
                        else:
                            t_idx = len(bmd_mesh.texcoords)
                            bmd_mesh.texcoords.append(BMDTexCoord(scaled_u, scaled_v))
                            uv_cache[ukey] = t_idx

                        tri.vertex_index[i] = v_idx
                        tri.normal_index[i] = n_idx
                        tri.texcoord_index[i] = t_idx

                    bmd_mesh.triangles.append(tri)
            finally:
                bm.free()

            # Double-sided triangle export: after baking the front triangles
            # (+N), emit a back triangle (-N) for EVERY face, sharing the same
            # texture/UV.  The game renders .ozt (Components=4) meshes
            # double-sided, so giving each face an outward normal on the back
            # keeps both sides lit (matches official obj01.bmd, which stores
            # [1,2,0]/+N paired with [0,2,1]/-N).
            bm2 = triangulate_mesh(mesh_obj)
            try:
                if not bm2.loops.layers.uv:
                    bm2.loops.layers.uv.new()
                uv_layer2 = bm2.loops.layers.uv.active
                # Back-face bias: offset the back triangles slightly rearward
                # so they never coplanar-overlap the front triangles.  This is
                # the key to ONE universal scheme that works for BOTH solid
                # bodies (back face sits just behind the outer face, is
                # occluded, outer texture stays clean) AND single-layer sheets
                # (both layers lit, no z-fighting), without needing to tell
                # them apart.
                try:
                    dim = mesh_obj.dimensions
                    bias = max([abs(d) for d in dim] or [1e-4]) * 0.01
                except Exception:
                    bias = 0.001
                back_vertex = {}
                for face in bm2.faces:
                    tri = BMDTriangle()
                    tri.polygon = 3
                    for i, loop in enumerate(face.loops[:3]):
                        bmvert = loop.vert
                        bmvert_idx = bmvert.index
                        # back triangle outward normal = -N (points to the back
                        # viewer), used both to offset and to light
                        wn = matrix_world.to_3x3() @ bmvert.normal
                        wnf = wn
                        try:
                            wn = wn.normalized()
                        except Exception:
                            wn = mathutils.Vector((0.0, 0.0, 1.0))
                        # offset vertex rearward along the front normal
                        world_pos = (matrix_world @ bmvert.co) - (wn * bias)
                        ox, oy, oz = origin_offset
                        px = (world_pos.x - ox) * scale
                        py = (world_pos.y - oy) * scale
                        pz = (world_pos.z - oz) * scale
                        bx, by, bz = coord_blender_to_bmd(px, py, pz)
                        bone_idx = get_vertex_bone_index(bmvert_idx, mesh_obj, armature, bone_name_to_index)
                        vkey = (bone_idx, round(bx, 6), round(by, 6), round(bz, 6))
                        if vkey in back_vertex:
                            v_idx = back_vertex[vkey]
                        else:
                            v_idx = len(bmd_mesh.vertices)
                            bmd_mesh.vertices.append(BMDVertex(bone_idx, bx, by, bz))
                            back_vertex[vkey] = v_idx
                        # back normal = -N
                        nback = -wn
                        nx, ny, nz = coord_blender_to_bmd(nback.x, nback.y, nback.z)
                        nkey = (round(nx, 6), round(ny, 6), round(nz, 6), v_idx)
                        if nkey in normal_cache:
                            n_idx = normal_cache[nkey]
                        else:
                            n_idx = len(bmd_mesh.normals)
                            bmd_mesh.normals.append(BMDNormal(
                                bmd_mesh.vertices[v_idx].node,
                                nx, ny, nz, v_idx
                            ))
                            normal_cache[nkey] = n_idx
                        uv = loop[uv_layer2].uv
                        u_in = (1.0 - uv.x) if mirror_u else uv.x
                        v_in = 1.0 - uv.y
                        su = u_in * u_scale
                        sv = v_in * v_scale
                        ukey = (round(su, 6), round(sv, 6))
                        if ukey in uv_cache:
                            t_idx = uv_cache[ukey]
                        else:
                            t_idx = len(bmd_mesh.texcoords)
                            bmd_mesh.texcoords.append(BMDTexCoord(su, sv))
                            uv_cache[ukey] = t_idx
                        k = 2 - i  # reversed winding on the back triangle
                        tri.vertex_index[k] = v_idx
                        tri.normal_index[k] = n_idx
                        tri.texcoord_index[k] = t_idx
                    bmd_mesh.triangles.append(tri)
            finally:
                bm2.free()

        bmd_meshes.append(bmd_mesh)

    return bmd_meshes, texture_list


# ============================================================
#  骨_?_数_?收集
# ============================================================

def collect_bones(armature, origin_offset=(0, 0, 0), scale=1.0):
    """_? Armature 收集骨_?_数_?, 返回 (bones列表, name_to_index映射)
    origin_offset: 模型原点偏移 (Blender 世界坐标), 仅应用于根_?__?_的绝_?_位_?
    """
    if not armature or not armature.data:
        # 无_?_架时创建一_?虚拟根_?__?? (位置在偏移后的原_?, _? BMD 坐标 (0,0,0))
        bone = BMDBone("root", -1)
        return [bone], {"root": 0}

    bones = []
    name_to_index = {}
    # 处理骨_?_的相_?_位_?及旋_? (相_?_于父_?__??)
    bone_list = list(armature.data.bones)
    # 先排_?: 根_?__?_在_?
    ordered = []
    processed = set()

    def add_bone_recursive(bone):
        if bone.name in processed:
            return
        processed.add(bone.name)
        ordered.append(bone)
        for child in bone.children:
            add_bone_recursive(child)

    for bone in bone_list:
        if bone.parent is None:
            add_bone_recursive(bone)
    # 补充剩余骨_??
    for bone in bone_list:
        if bone.name not in processed:
            add_bone_recursive(bone)

    for i, bone in enumerate(ordered):
        name_to_index[bone.name] = i

    ox, oy, oz = origin_offset
    armature_matrix = armature.matrix_world

    for bone in ordered:
        parent_idx = name_to_index.get(bone.parent.name, -1) if bone.parent else -1
        bmd_bone = BMDBone(bone.name, parent_idx)
        # 处理每个骨_?_的相_?_位_?及旋_? (相_?_于父_?__??)
        if bone.parent:
            # 子_?__??: 计算相_?__?_?
            local_mat = bone.parent.matrix_local.inverted() @ bone.matrix_local
            pos = local_mat.to_translation()
            rot = local_mat.to_euler('XYZ')
        else:
            # 根_?__??: 世界位置 - 原点偏移, 应用缩放
            world_pos = armature_matrix @ bone.matrix_local.to_translation()
            pos = mathutils.Vector((
                (world_pos.x - ox) * scale,
                (world_pos.y - oy) * scale,
                (world_pos.z - oz) * scale
            ))
            # 根_?__?_旋_?: 使用 matrix_local 的旋_? (Armature _?_?旋转不君_?)
            # 做法: 使用 matrix_local 的旋_?_?
            rot = bone.matrix_local.to_euler('XYZ')
        bmd_bone.position = coord_blender_to_bmd(pos.x, pos.y, pos.z)
        bmd_bone.rotation = euler_blender_to_bmd(rot)
        bones.append(bmd_bone)

    return bones, name_to_index


# ============================================================
#  BMD 写入
# ============================================================

def write_bmd_file(filepath, model_name, bmd_meshes, bones):
    """写入 BMD 二进制文_?"""
    buf = bytearray()

    # ---- 文件_? ----
    buf += b'BMD'
    buf += struct.pack('<B', 10)  # version = 10 (0x0A, 明文格式, 奇迹客户_?_?_?)

    # ---- 模型_? (32字节) ----
    buf = write_fixed_string(buf, model_name, 32)

    # ---- 计数 ----
    buf += struct.pack('<H', len(bmd_meshes))   # meshCount
    buf += struct.pack('<H', len(bones))        # boneCount
    buf += struct.pack('<H', 1)                 # actionCount = 1 (静_?)

    # ---- Meshes ----
    for mesh in bmd_meshes:
        buf += struct.pack('<h', len(mesh.vertices))
        buf += struct.pack('<h', len(mesh.normals))
        buf += struct.pack('<h', len(mesh.texcoords))
        buf += struct.pack('<h', len(mesh.triangles))
        buf += struct.pack('<h', mesh.texture_index)

        # 顶点 (16 bytes each)
        for v in mesh.vertices:
            buf += struct.pack('<h', v.node)       # int16 node
            buf += struct.pack('<h', 0)            # int16 padding
            buf += struct.pack('<fff', v.x, v.y, v.z)  # float32 x,y,z

        # 法线 (20 bytes each)
        for n in mesh.normals:
            buf += struct.pack('<h', n.node)       # int16 node
            buf += struct.pack('<h', 0)            # int16 padding
            buf += struct.pack('<fff', n.nx, n.ny, n.nz)  # float32 normal
            buf += struct.pack('<h', n.bind_vertex)  # int16 bindVertex
            buf += struct.pack('<h', 0)            # int16 padding

        # UV (8 bytes each)
        for t in mesh.texcoords:
            buf += struct.pack('<ff', t.u, t.v)

        # 三_?__? (64 bytes each)
        for tri in mesh.triangles:
            tri_buf = bytearray(64)
            # offset 0: polygon type
            struct.pack_into('<B', tri_buf, 0, tri.polygon)
            # offset 1: padding
            tri_buf[1] = 0
            # offset 2-9: vertexIndex[4]
            for i in range(4):
                struct.pack_into('<h', tri_buf, 2 + i * 2, tri.vertex_index[i])
            # offset 10-17: normalIndex[4]
            for i in range(4):
                struct.pack_into('<h', tri_buf, 10 + i * 2, tri.normal_index[i])
            # offset 18-25: texCoordIndex[4]
            for i in range(4):
                struct.pack_into('<h', tri_buf, 18 + i * 2, tri.texcoord_index[i])
            # offset 26-63: 保留 (lightMap相关, _?0)
            buf += tri_buf

        # 纹理_?_? (32字节)
        buf = write_fixed_string(buf, mesh.texture_path, 32)

    # ---- Actions (1_?静态action) ----
    buf += struct.pack('<h', 1)   # numAnimationKeys = 1
    buf += struct.pack('<B', 0)   # lockPositions = 0

    # ---- Bones ----
    for bone in bones:
        buf += struct.pack('<B', 1 if bone.is_dummy else 0)  # isDummy
        if not bone.is_dummy:
            buf = write_fixed_string(buf, bone.name, 32)
            buf += struct.pack('<h', bone.parent)
            # 1个action, 1_?: position (12 bytes)
            buf += struct.pack('<fff', bone.position[0], bone.position[1], bone.position[2])
            # 1个action, 1_?: rotation (12 bytes)
            buf += struct.pack('<fff', bone.rotation[0], bone.rotation[1], bone.rotation[2])

    with open(filepath, 'wb') as f:
        f.write(buf)

    return len(buf)


# ============================================================
#  出口_?_? / 菜单
# ============================================================

class ExportMUOnlineBMD(Operator, ExportHelper):
    """导出静_? MU Online BMD 模型"""
    bl_idname = "export_mu.bmd"
    bl_label = "导出 BMD"
    bl_options = {'PRESET', 'UNDO'}

    filename_ext = ".bmd"
    filter_glob: StringProperty(default="*.bmd", options={'HIDDEN'})

    # JPEG质量
    jpeg_quality: IntProperty(
        name="JPEG 质量",
        description="OZJ 存储_? JPEG 时的压缩质量 (1-100)",
        default=90,
        min=1,
        max=100,
    )

    export_textures: BoolProperty(
        name="导出纹理",
        description="同时导出 OZJ/OZT 纹理文件_? BMD _?_?",
        default=True,
    )

    selected_only: BoolProperty(
        name="仅_?_出所选_?__?",
        description="_?导出当前选中的_?__? (取消则_?_出场_?全部网格)",
        default=True,
    )

    apply_transform: BoolProperty(
        name="应用变换",
        description="将网格的移动/旋转/缩放烘炒到顶_?",
        default=True,
    )

    scale: FloatProperty(
        name="缩放比例",
        description="输出坐标的缩放因_? (1.0 = 原_?__?_?)",
        default=1.0,
        min=0.001,
        max=1000.0,
        precision=4,
    )

    def execute(self, context):
        scene = context.scene
        selected_objects = context.selected_objects if self.selected_only else list(scene.objects)

        # 1. 直接选中 Armature
        armature = None
        for obj in selected_objects:
            if obj.type == 'ARMATURE':
                armature = obj
                break

        # 2. _? Armature, 尝试从所选网格找 Armature
        if armature is None:
            for obj in selected_objects:
                if obj.type == 'MESH':
                    found = find_armature_from_mesh(obj)
                    if found:
                        armature = found
                        break

        # 3. 仍无 Armature, 尝试从场_?网格_? Armature
        if armature is None and not self.selected_only:
            for obj in scene.objects:
                if obj.type == 'MESH':
                    found = find_armature_from_mesh(obj)
                    if found:
                        armature = found
                        break

        # 处理网格对象
        mesh_objects = collect_mesh_objects(selected_objects, armature, scene)

        if not mesh_objects:
            self.report({'ERROR'}, "没有找到_?导出的网格_?__?, 请先选择网格或其父级多_?__?")
            return {'CANCELLED'}

        # 处理变换 (若开_?)
        if self.apply_transform:
            # 保存原_?__?_?, 不修改场_?
            original_matrices = {}
            for obj in mesh_objects:
                original_matrices[obj] = obj.matrix_world.copy()
            # 说明: 矢量_?_?已经考虑,在合并时使用 matrix_world
            # (merge_meshes_by_texture 后续使用的是 matrix_world)

        # 计算底面_?心原点偏_? (Blender 坐标<->BMD 坐标_?_?)
        origin_offset = compute_bottom_center_origin(mesh_objects)

        # 收集骨_?_数_? (根据上面计算的偏移和缩放)
        bones, bone_name_to_index = collect_bones(armature, origin_offset, self.scale)

        # 按纹理合并网_? (_?动收缩层_?, 按纹理分_?)
        model_name = os.path.splitext(os.path.basename(self.filepath))[0]
        texture_name_map = {}
        bmd_meshes, texture_list = merge_meshes_by_texture(
            mesh_objects, armature, bone_name_to_index, texture_name_map, origin_offset, self.scale,
            name_prefix=model_name
        )

        if not bmd_meshes:
            self.report({'ERROR'}, "_?生成任何 BMD 网格")
            return {'CANCELLED'}

        # 处理网格对象
        for i, mesh in enumerate(bmd_meshes):
            mesh.texture_index = i

        # 获取名称
        model_name = os.path.splitext(os.path.basename(self.filepath))[0]

        # 写入 BMD
        bmd_size = write_bmd_file(self.filepath, model_name, bmd_meshes, bones)

        # 导出纹理 (_? merge_meshes_by_texture _?已_?__?_理_?2的幂次方)
        output_dir = os.path.dirname(self.filepath)
        exported_textures = []
        temp_images = []  # 需要清理的临时图像
        if self.export_textures:
            for tex_name, img, is_tga, is_new_img, is_flat in texture_list:
                if img is None:
                    continue
                out_path = os.path.join(output_dir, tex_name)
                try:
                    if is_tga:
                        # single-layer meshes are double-layered (flipped
                        # normals) so both sides are lit; no brightness hack.
                        convert_image_to_ozt(out_path, img)
                    else:
                        jpg_bytes = convert_image_to_jpg_bytes(img, self.jpeg_quality)
                        write_ozj(out_path, jpg_bytes, img.size[0], img.size[1])
                    exported_textures.append(tex_name)
                    if is_new_img:
                        temp_images.append(img)
                except Exception as e:
                    self.report({'WARNING'}, f"纹理 {tex_name} 导出失败: {str(e)}")
                    if is_new_img:
                        temp_images.append(img)

        # 清理临时图像
        for img in temp_images:
            try:
                bpy.data.images.remove(img)
            except Exception:
                pass

        # 报告
        msg = f"导出完成: {model_name}.bmd ({bmd_size} bytes), {len(bmd_meshes)} _?网格, {len(bones)} _?骨_??"
        if exported_textures:
            msg += f", {len(exported_textures)} _?纹理"
        self.report({'INFO'}, msg)

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="导出设置", icon='SETTINGS')
        box.prop(self, "selected_only")
        box.prop(self, "apply_transform")
        box.prop(self, "export_textures")
        if self.export_textures:
            box.prop(self, "jpeg_quality")
        box.prop(self, "scale")

        box2 = layout.box()
        box2.label(text="说明", icon='INFO')
        box2.label(text="仅_?_出静态网_?, 不包_?动画")
        box2.label(text="纹理尺_?_会_?处理_? 2 的幂次方 (最_? 1024)")
        box2.label(text="_? TGA纹理导出_? OZT, 其他_? JPG 导出_? OZJ")
        box2.label(text="_?透明_?/布料纹理将_?_出_? OZT以实现双面显_?")


# ============================================================
#  注册 / 注销
# ============================================================

def menu_func_export(self, context):
    self.layout.operator(ExportMUOnlineBMD.bl_idname, text="MU Online BMD (.bmd)")


def register():
    bpy.utils.register_class(ExportMUOnlineBMD)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    bpy.utils.unregister_class(ExportMUOnlineBMD)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)


if __name__ == "__main__":
    register()
