# -*- coding: utf-8 -*-
"""Display ground objects as their real BMD models instead of empties.

One mesh template per object *type* is built from the BMD (bind pose baked
into model space), then every ground object becomes a linked copy sharing that
mesh data, placed with the obj record's position / angle / scale.

BMD vertices/normals are stored in bone-local space; we transform them with the
bone's bind world matrix (same as the C# client) so the model aligns with the
terrain and other objects.
"""

import math
import os

import bpy
from mathutils import Matrix, Quaternion, Vector

from ..formats.bmd import BMDData
from .editor_data import TERRAIN_SCALE, resolve_object_collection
from ..formats import textures as tex_mod

# World1 (Lorencia) obj coordinates carry an inherent +2 tile X offset in the
# game data; we shift placed objects +X by that amount here so they line up
# with the ground, and subtract it back on export.
MAP_OBJECT_X_OFFSET_TILES = {1: 2}

# map number -> {obj Type: bmd model name (no extension)}.  World 1 = Lorencia.


_LORENCIA_MODELS = {}
for _i in range(13):
    _LORENCIA_MODELS[_i] = "Tree%02d" % (_i + 1)
for _i in range(8):
    _LORENCIA_MODELS[20 + _i] = "Grass%02d" % (_i + 1)
for _i in range(5):
    _LORENCIA_MODELS[30 + _i] = "Stone%02d" % (_i + 1)
for _i in range(3):
    _LORENCIA_MODELS[40 + _i] = "StoneStatue%02d" % (_i + 1)
_LORENCIA_MODELS[43] = "SteelStatue01"
for _i in range(3):
    _LORENCIA_MODELS[44 + _i] = "Tomb%02d" % (_i + 1)
for _i in range(2):
    _LORENCIA_MODELS[50 + _i] = "FireLight%02d" % (_i + 1)
_LORENCIA_MODELS[52] = "Bonfire01"
_LORENCIA_MODELS[55] = "DoungeonGate01"
for _i in range(2):
    _LORENCIA_MODELS[56 + _i] = "MerchantAnimal%02d" % (_i + 1)
_LORENCIA_MODELS[58] = "TreasureDrum01"
_LORENCIA_MODELS[59] = "TreasureChest01"
_LORENCIA_MODELS[60] = "Ship01"
for _i in range(3):
    _LORENCIA_MODELS[65 + _i] = "SteelWall%02d" % (_i + 1)
_LORENCIA_MODELS[68] = "SteelDoor01"
for _i in range(6):
    _LORENCIA_MODELS[69 + _i] = "StoneWall%02d" % (_i + 1)
for _i in range(4):
    _LORENCIA_MODELS[75 + _i] = "StoneMuWall%02d" % (_i + 1)
_LORENCIA_MODELS[80] = "Bridge01"
for _i in range(4):
    _LORENCIA_MODELS[81 + _i] = "Fence%02d" % (_i + 1)
_LORENCIA_MODELS[85] = "BridgeStone01"
_LORENCIA_MODELS[90] = "StreetLight01"
for _i in range(3):
    _LORENCIA_MODELS[91 + _i] = "Cannon%02d" % (_i + 1)
_LORENCIA_MODELS[95] = "Curtain01"
for _i in range(2):
    _LORENCIA_MODELS[96 + _i] = "Sign%02d" % (_i + 1)
for _i in range(4):
    _LORENCIA_MODELS[98 + _i] = "Carriage%02d" % (_i + 1)
for _i in range(2):
    _LORENCIA_MODELS[102 + _i] = "Straw%02d" % (_i + 1)
_LORENCIA_MODELS[105] = "Waterspout01"
for _i in range(4):
    _LORENCIA_MODELS[106 + _i] = "Well%02d" % (_i + 1)
_LORENCIA_MODELS[110] = "Hanging01"
_LORENCIA_MODELS[111] = "Stair01"
for _i in range(5):
    _LORENCIA_MODELS[115 + _i] = "House%02d" % (_i + 1)
_LORENCIA_MODELS[120] = "Tent01"
for _i in range(6):
    _LORENCIA_MODELS[121 + _i] = "HouseWall%02d" % (_i + 1)
for _i in range(3):
    _LORENCIA_MODELS[127 + _i] = "HouseEtc%02d" % (_i + 1)
for _i in range(3):
    _LORENCIA_MODELS[130 + _i] = "Light%02d" % (_i + 1)
_LORENCIA_MODELS[133] = "PoseBox01"
for _i in range(7):
    _LORENCIA_MODELS[140 + _i] = "Furniture%02d" % (_i + 1)
_LORENCIA_MODELS[150] = "Candle01"
for _i in range(3):
    _LORENCIA_MODELS[151 + _i] = "Beer%02d" % (_i + 1)

MAP_MODEL_TABLES = {1: _LORENCIA_MODELS}


def resolve_object_bmd(object_root, world_index, obj_type):
    """Locate the BMD file for a map object of the given type.

    Priority (matches the TS viewer TerrainObjects resolution):
      1) Object{WorldIndex}/Object{(Type+1):00}.bmd
      2) per-world model table -> Object{WorldIndex}/{Model}.bmd
      3) Object9 / Object111 / Object{(Type+1):00}.bmd fallback
    Returns an absolute path or None.
    """
    if not object_root or not os.path.isdir(object_root):
        return None
    n = obj_type + 1
    obj_folder = "Object%d" % world_index
    for fn in ("Object%02d.bmd" % n, "Object%d.bmd" % n):
        c = os.path.join(object_root, obj_folder, fn)
        if os.path.isfile(c):
            return c
    table = MAP_MODEL_TABLES.get(world_index)
    if table:
        m = table.get(obj_type)
        if m:
            c = os.path.join(object_root, obj_folder, "%s.bmd" % m)
            if os.path.isfile(c):
                return c
    for folder in ("Object9", "Object111"):
        base = os.path.join(object_root, folder)
        for fn in ("Object%02d.bmd" % n, "Object%d.bmd" % n):
            c = os.path.join(base, fn)
            if os.path.isfile(c):
                return c
    return None


def world_bind_matrices(bmd):
    """Per-bone bind-pose world matrix (action 0 frame 0), parent chained."""
    world = []
    for i, bone in enumerate(bmd.bones):
        if bone.is_dummy or not bone.matrixes:
            world.append(Matrix.Identity(4))
            continue
        mat = bone.matrixes[0]
        p = mat.positions[0] if mat.positions else (0, 0, 0)
        q = mat.quaternions[0] if mat.quaternions else (0, 0, 0, 1)
        loc = Vector((p[0], p[1], p[2]))
        quat = Quaternion((q[3], q[0], q[1], q[2]))
        m = Matrix.LocRotScale(loc, quat, Vector((1, 1, 1)))
        parent = bone.parent
        if 0 <= parent < len(world):
            m = world[parent] @ m
        world.append(m)
    return world


def _bind_point(bind_world, node, pos):
    if bind_world is None or node < 0 or node >= len(bind_world):
        return pos
    v = bind_world[node] @ Vector((pos[0], pos[1], pos[2], 1.0))
    return (v[0], v[1], v[2])


def _extract_arrays(sub_mesh, bind_world):
    """Expand one BMD sub-mesh into flat position/normal/uv/face arrays."""
    pos_map = {}
    positions, normals, uvs = [], [], []

    def corner(v_idx, n_idx, t_idx):
        if v_idx < 0 or v_idx >= len(sub_mesh.vertices):
            return -1
        v = sub_mesh.vertices[v_idx]
        n = (sub_mesh.normals[n_idx][1]
             if 0 <= n_idx < len(sub_mesh.normals) else (0, 1, 0))
        t = sub_mesh.tex_coords[t_idx] if 0 <= t_idx < len(sub_mesh.tex_coords) else (0, 0)
        node = v[0]
        pos = _bind_point(bind_world, node, v[1])
        if bind_world is not None and 0 <= node < len(bind_world):
            nm = bind_world[node].to_3x3() @ Vector(n)
        else:
            nm = Vector(n)
        key = (round(pos[0], 5), round(pos[1], 5), round(pos[2], 5),
               round(nm.x, 5), round(nm.y, 5), round(nm.z, 5),
               round(t[0], 6), round(t[1], 6), node)
        if key not in pos_map:
            pos_map[key] = len(positions)
            positions.append(pos)
            normals.append((nm.x, nm.y, nm.z))
            uvs.append(t)
        return pos_map[key]

    faces = []
    for tri in sub_mesh.triangles:
        vi, ni, ti = tri.vertex_index, tri.normal_index, tri.tex_coord_index
        i0 = corner(vi[0], ni[0], ti[0])
        i1 = corner(vi[1], ni[1], ti[1])
        i2 = corner(vi[2], ni[2], ti[2])
        if i0 < 0 or i1 < 0 or i2 < 0:
            continue
        faces.append((i0, i1, i2))  # BMD winding CCW (0,1,2)
        if tri.polygon == 4:
            i3 = corner(vi[3], ni[3], ti[3])
            if i3 >= 0:
                faces.append((i0, i2, i3))
    return positions, normals, uvs, faces


def _load_image(idx_tag, texture_path, search_roots):
    """Load a BMD texture (ozj/ozt/...) into a Blender image (cached)."""
    import tempfile
    name = "mu_bmd_img_%s" % idx_tag
    bimg = bpy.data.images.get(name)
    if bimg is not None:
        return bimg
    rel = texture_path.replace("\\", "/")
    base = os.path.basename(rel)
    stem = os.path.splitext(base)[0]
    ext = os.path.splitext(base)[1].lower()
    cands = [base]
    if ext in (".jpg", ".jpeg", ".bmp", ".png"):
        cands.append(stem + ".ozj")
    elif ext == ".tga":
        cands.append(stem + ".ozt")
    resolved = None
    for root in search_roots:
        for c in cands:
            p = os.path.join(root, c)
            if os.path.exists(p):
                resolved = p
                break
        if resolved:
            break
    if not resolved:
        return None
    try:
        with open(resolved, "rb") as f:
            tex = tex_mod.decode_texture(
                f.read(), os.path.splitext(resolved)[1].lower())
        # Pillow-free: builds a packed Blender image from the raw RGBA bytes
        from ..formats import teximage as _te
        return _te.to_blender_image(tex, name, pack=True)
    except Exception:
        return None


def _build_material(name, image):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    if image is not None:
        tex = nt.nodes.new("ShaderNodeTexImage")
        tex.image = image
        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
        out = nt.nodes.new("ShaderNodeOutputMaterial")
        nt.links.new(bsdf.inputs["Base Color"], tex.outputs["Color"])
        nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    else:
        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
        out = nt.nodes.new("ShaderNodeOutputMaterial")
        nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat


def build_bmd_mesh(bmd, name, search_roots=None, flip_uv=True):
    """Build a single Blender mesh (all BMD sub-meshes merged, one material
    per sub-mesh) with the bind pose baked into model space."""
    bind_world = world_bind_matrices(bmd)
    search_roots = search_roots or []

    all_pos = []
    all_uvs = []
    all_norms = []
    all_faces = []          # (vi0, vi1, vi2)
    all_mat_index = []      # per face
    mats = []               # Blender materials

    for sm in bmd.meshes:
        positions, normals, uvs, faces = _extract_arrays(sm, bind_world)
        if not faces:
            continue
        base = len(all_pos)
        mat_name = "mu_bmd_%s_m%d" % (name, len(mats))
        image = _load_image("%s_%d" % (name, len(mats)), sm.texture_path,
                            search_roots)
        mats.append(_build_material(mat_name, image))
        idx = len(mats) - 1
        all_pos.extend(positions)
        all_uvs.extend(uvs)
        all_norms.extend(normals)
        for f in faces:
            all_faces.append((base + f[0], base + f[1], base + f[2]))
            all_mat_index.append(idx)

    me = bpy.data.meshes.new(name)
    clean = [f for f in all_faces
             if f[0] != f[1] and f[1] != f[2] and f[0] != f[2]]
    me.from_pydata(all_pos, [], clean)
    me.update()
    if all_uvs:
        uv_layer = me.uv_layers.new(name="UVMap")
        for poly in me.polygons:
            for li in range(poly.loop_start, poly.loop_start + poly.loop_total):
                vi = me.loops[li].vertex_index
                u, v = all_uvs[vi]
                uv_layer.data[li].uv = (u, 1.0 - v if flip_uv else v)
    if all_norms:
        try:
            me.use_auto_smooth = True
            me.normals_split_custom_set_from_vertices(all_norms)
        except Exception:
            pass
    for mat in mats:
        me.materials.append(mat)
    # per-face material index
    pi = 0
    for poly in me.polygons:
        poly.material_index = all_mat_index[pi]
        pi += 1
    me.update()
    return me


def build_object_instances(data, object_root=None, mode="model"):
    """Create the ground-object objects.  mode='model' shows real BMD meshes
    (one template mesh per unique model TYPE, shared by every instance - true
    instancing/grouping), mode='empty' falls back to arrow empties.

    Optimization:
      * One Blender mesh per unique object type (`MUBMD_t{type}`) built once
        and reused by all instances - so a model used 500 times costs 1 mesh
        (huge reduction in memory / GPU / file size).
      * All instances of the same type are grouped into a per-type sub-collection
        `MU_Type{type}` under the main object collection, so they are easy to
        select / hide / edit together while each copy keeps its own transform.
    """
    col = resolve_object_collection(data)
    if col is None:
        return
    object_root = object_root or data.data_dir
    offx = MAP_OBJECT_X_OFFSET_TILES.get(data.world_id, 0) * TERRAIN_SCALE
    templates = {}   # type -> mesh data name
    mesh_cache = {}

    # map type -> resolved model name (per type)
    model_name_cache = {}

    for i, mo in enumerate(data.objects.objects):
        px, py, pz = mo.position
        ax, ay, az = mo.angle
        rad = (math.radians(ax), math.radians(ay), math.radians(az))
        sc = mo.scale if mo.scale else 1.0
        obj_type = mo.type

        # ---- resolve the BMD path + a friendly model name (cached per type) ----
        if obj_type not in model_name_cache:
            path = resolve_object_bmd(object_root, data.world_id, obj_type)
            model_name_cache[obj_type] = (path, _model_label(path, obj_type))
        bmd_path, mname = model_name_cache[obj_type]

        # ---- one shared mesh per unique type (instancing) ----
        src_mesh = None
        if mode == "model":
            if obj_type not in mesh_cache:
                src_mesh = None
                if bmd_path:
                    try:
                        from ..formats.bmd import parse_bmd
                        bmd = parse_bmd(open(bmd_path, "rb").read(),
                                        bind_pose_only=True)
                        folder = os.path.dirname(bmd_path)
                        src_mesh = build_bmd_mesh(
                            bmd, "MUBMD_%s" % mname,
                            search_roots=[folder, object_root])
                    except Exception:
                        src_mesh = None
                mesh_cache[obj_type] = src_mesh
            else:
                src_mesh = mesh_cache.get(obj_type)
            if src_mesh is not None:
                obj = bpy.data.objects.new("MUObj_%s_%d" % (mname, i),
                                           src_mesh)
                obj.location = (px + offx, py, pz)
                obj.rotation_euler = rad
                obj.scale = (sc, sc, sc)
            else:
                obj = _make_empty(mname, i)
                obj.location = (px + offx, py, pz)
                obj.rotation_euler = rad
                obj.scale = (sc, sc, sc)
        else:
            obj = _make_empty(mname, i)
            obj.location = (px + offx, py, pz)
            obj.rotation_euler = rad
            obj.scale = (sc, sc, sc)

        obj["mu_type"] = obj_type
        obj["mu_obj_index"] = i
        obj["mu_scale"] = sc
        # keep the original record so an unmodified save stays byte-identical
        obj["mu_init_pos"] = (px, py, pz)
        obj["mu_init_angle"] = (ax, ay, az)
        obj["mu_init_scale"] = sc
        # per-object light (record versions >= 1): stored so the panel can
        # show/toggle it and the exporter can write it back.
        if mo.light_enable:
            obj["mu_light_enable"] = list(mo.light_enable)
            if mo.light_rgb:
                obj["mu_light_rgb"] = tuple(mo.light_rgb)

        # ---- group every instance of a model under one named sub-collection ----
        type_col_name = "MUGrp_%s" % mname
        tcol = bpy.data.collections.get(type_col_name)
        if tcol is None:
            tcol = bpy.data.collections.new(type_col_name)
            col.children.link(tcol)   # nest it under the object collection
        # link the instance only into the type group (folders in the outliner)
        tcol.objects.link(obj)

    data.object_collection = col


def _model_label(bmd_path, obj_type):
    """A friendly, Blender-safe model name for a resolved BMD path (or type)."""
    if bmd_path:
        base = os.path.splitext(os.path.basename(bmd_path))[0]
        if base:
            return _sanitize_name(base)
    return "t%d" % obj_type


def _sanitize_name(name):
    out = []
    for ch in str(name):
        out.append(ch if (ch.isalnum() or ch in "_-.") else "_")
    s = "".join(out).strip("_. ")
    return s or "model"


def _make_empty(mname, i):
    empty = bpy.data.objects.new("MUEmpty_%s_%d" % (mname, i), None)
    empty.empty_display_type = "ARROWS"
    empty.empty_display_size = 50.0
    return empty


def clear_object_templates():
    for me in list(bpy.data.meshes):
        if me.name.startswith("MUBMD_"):
            bpy.data.meshes.remove(me)
