# -*- coding: utf-8 -*-
"""3D-view sidebar panel for the map editor (tile previews + wall legend).

Blender 5.1 template_preview() only accepts material / texture / light /
world / line-style IDs - NOT bpy.types.Image.  So tile thumbnails and wall
swatches are shown via bpy.utils.previews icon_value + layout.template_icon().
All icon building happens in the import operator (writes allowed); the
panel draw only reads existing icons.
"""

import bpy, os, tempfile, struct, zlib, math
from bpy.types import Panel, UIList
from .core import terrain_build, wall_display


# ---- Preview icon cache (built in import operator) ----
_previews = None


def _save_png(path, w, h, rgba):
    def chunk(t, data):
        c = struct.pack(">I", len(data)) + t + data
        c += struct.pack(">I", zlib.crc32(t + data) & 0xffffffff)
        return c
    raw = b""
    for y in range(h):
        raw += b"\x00"
        for x in range(w):
            i = (y * w + x) * 4
            raw += bytes((int(rgba[i]*255), int(rgba[i+1]*255),
                          int(rgba[i+2]*255), int(rgba[i+3]*255)))
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + \
          chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)


def _avg_color_pil(tex_img):
    """Average RGBA (0.0-1.0) of a decoded TexImage, for chip swatches.

    Pillow-free: TexImage carries the raw bytes and averages them itself.
    A small thumbnail is enough, so we sample a downscaled copy first.
    """
    try:
        sm = tex_img
        if sm.width > 32 or sm.height > 32:
            sm = sm.copy().resize(32, 32)
        return sm.average_rgba()
    except Exception:
        return (0.5, 0.5, 0.5, 1.0)


def _tile_texture(idx):
    """A Blender Texture (IMAGE) bound to the tile's Blender image, so the
    panel can show a REAL rendered preview of the decoded texture via
    template_preview(tex).  Build in the import operator only (writes ID)."""
    img = bpy.data.images.get(terrain_build._tile_image_name(idx))
    if img is None:
        return None
    name = "mu_tile_tex_%d" % idx
    tex = bpy.data.textures.get(name)
    if tex is None:
        tex = bpy.data.textures.new(name, "IMAGE")
    if tex.image != img:
        tex.image = img
    return tex


def _get_tile_texture(idx):
    """READ-ONLY: return the pre-built texture for a tile (0-safe lookup)."""
    return bpy.data.textures.get("mu_tile_tex_%d" % idx)


def build_previews(data):
    """Build tile previews (icons + IMAGE textures) and wall swatches.
    Operator only (writes ID).  The IMAGE textures are the reliable path
    (bpy.utils.previews / GPU icons can be unavailable e.g. headless, but the
    textures always build and are shown with template_preview)."""
    global _previews
    if _previews is not None:
        try: _previews.close()
        except Exception: pass
    try:
        _previews = bpy.utils.previews.new()
        _have_previews = True
    except Exception:
        _previews = None
        _have_previews = False

    # tile textures (reliable IMAGE-texture previews) + thumbnails
    tile_pil = getattr(data, "tile_textures", None) or {}
    for idx in terrain_build.DEFAULT_TEXTURE_FILES:
        # 1) always build the IMAGE Texture bound to the decoded tile image
        try:
            _tile_texture(idx)
        except Exception:
            pass
        if not _have_previews:
            continue
        tmp = None
        avg = None   # average RGB, used for the guaranteed chip fallback
        try:
            pil_src = tile_pil.get(idx)
            if pil_src is not None:
                from .formats import teximage as _te
                tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
                tmp.close()
                _te.save_png(tmp.name, pil_src)
                avg = _avg_color_pil(pil_src)
            else:
                im = bpy.data.images.get(terrain_build._tile_image_name(idx))
                if im is not None and im.size[0] > 0:
                    w, h = im.size[0], im.size[1]
                    nw = min(w, 64)
                    nh = max(1, int(round(h * nw / w)))
                    tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
                    tmp.close()
                    px = list(im.pixels)
                    small = [0.0] * (nw * nh * 4)
                    acc = [0.0, 0.0, 0.0]
                    for oy in range(nh):
                        sy = min(h - 1, int(oy * h / nh))
                        for ox in range(nw):
                            sx = min(w - 1, int(ox * w / nw))
                            src = (sy * w + sx) * 4
                            dst = (oy * nw + ox) * 4
                            small[dst:dst + 4] = px[src:src + 4]
                            acc[0] += px[src]; acc[1] += px[src + 1]; acc[2] += px[src + 2]
                    n = nw * nh
                    avg = (acc[0] / n, acc[1] / n, acc[2] / n, 1.0)
                    _save_png(tmp.name, nw, nh, small)
        except Exception:
            if tmp is not None:
                try: os.unlink(tmp.name)
                except Exception: pass
            tmp = None
        if tmp is not None:
            try:
                _previews.load("tile_%d" % idx, tmp.name, "IMAGE")
            finally:
                try: os.unlink(tmp.name)
                except Exception: pass
        # guaranteed chip (average color) so every tile is visible & distinct
        try:
            if avg is None:
                avg = (0.5, 0.5, 0.5, 1.0)
            chip = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
            chip.close()
            _save_png(chip.name, 2, 2,
                      [avg[0], avg[1], avg[2], avg[3]] * 4)
            _previews.load("chip_%d" % idx, chip.name, "IMAGE")
            try: os.unlink(chip.name)
            except Exception: pass
        except Exception:
            pass

    # wall swatches (solid colors)
    try:
        colors = [c for _b, _p, c, _l in wall_display.WALL_DEFS]
        colors.append(wall_display.WALK_COLOR)
        seen = set()
        for color in colors:
            key = tuple(round(c, 2) for c in color)
            if key in seen: continue
            seen.add(key)
            nm = "sw_%02x%02x%02x" % (int(color[0]*255), int(color[1]*255), int(color[2]*255))
            try:
                tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
                tmp.close()
                px = [0.0]*16
                for i in range(4):
                    px[i*4] = color[0]; px[i*4+1] = color[1]; px[i*4+2] = color[2]; px[i*4+3] = 1.0
                _save_png(tmp.name, 2, 2, px)
                _previews.load(nm, tmp.name, "IMAGE")
                os.unlink(tmp.name)
            except Exception:
                pass
    except Exception:
        pass
    return _previews


def _icon(name):
    """Read-only: preview icon_value for a stored icon name (0 = none)."""
    global _previews
    if _previews is None: return 0
    pv = _previews.get(name)
    return pv.icon_id if pv is not None else 0


def tile_icon(idx):
    """Icon for a tile: real thumbnail if built, else the average-color chip."""
    iv = _icon("tile_%d" % idx)
    if iv:
        return iv
    return _icon("chip_%d" % idx)


def swatch_icon(color):
    return _icon("sw_%02x%02x%02x" % (int(color[0]*255), int(color[1]*255), int(color[2]*255)))


def _wall_type_color(wall_str):
    """Return the display color for a wall_type enum string (e.g. '0x0004')."""
    val = 0
    try:
        val = int(wall_str, 16)
    except Exception:
        return None
    if val == 0:
        return wall_display.WALK_COLOR
    for bit, _pri, color, _lbl in wall_display.WALL_DEFS:
        if val & bit:
            return color
    return None


def drop_previews():
    global _previews
    if _previews is not None:
        try: _previews.close()
        except Exception: pass
    _previews = None


class MUONLINE_UL_tiles(UIList):
    """Tile texture picker: one row per tile showing index + World file name
    (the selected tile's image is shown in the big preview above the list)."""
    bl_idname = "MUONLINE_UL_tiles"

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):
        fname = terrain_build.DEFAULT_TEXTURE_FILES.get(item.idx)
        row = layout.row(align=True)
        row.label(text="", icon="TEXTURE")
        row.label(text="%d  %s" % (item.idx, fname if fname else ""))


class MUONLINE_PT_map_editor(Panel):
    bl_label = "MU \u5730\u56fe\u7f16\u8f91\u5668 v0.2"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "MU \u5730\u56fe"

    def draw(self, context):
        layout = self.layout
        p = context.scene.muonline_map_props
        scene = context.scene

        box = layout.box()
        box.label(text="MU \u5730\u56fe\u7f16\u8f91\u5668 v0.2", icon="WORLD")
        box.prop(p, "data_dir")
        box.prop(p, "world_id")
        row = box.row(align=True)
        row.operator("muonline_map.import_map", icon="IMPORT")
        row.operator("muonline_map.export_map", icon="EXPORT")
        row = box.row(align=True)
        row.prop(p, "show_object_models")
        row.prop(p, "show_walls")

        if p.loaded:
            box.label(text="\u5df2\u52a0\u8f7d World%d" % p.world_id, icon="CHECKMARK")
        if p.status:
            box.label(text=p.status)

        layout.separator()
        box = layout.box()
        box.label(text="\u5de5\u5177", icon="BRUSH_DATA")
        box.prop(p, "tool_mode", expand=True)
        box.prop(p, "brush_size")
        box.prop(p, "brush_strength")

        mode = p.tool_mode
        if mode == "HEIGHT":
            box.prop(p, "height_mode")
            if p.height_mode == "flatten":
                box.prop(p, "flatten_height")
        elif mode == "TILE":
            row = box.row(align=True)
            row.prop(p, "tile_layer")
            row.prop(p, "tile_alpha")
            from .core import state
            if state.get_current() is None:
                box.label(text="\u8bf7\u5148\u70b9\u51fb\u4e0a\u65b9\u201c\u5bfc\u5165\u5730\u56fe\u201d", icon="INFO")
            else:
                items = scene.muonline_tile_items
                if items:
                    box.label(text="\u9009\u62e9\u74e6\u7247\u7eb9\u7406:", icon="TEXTURE")
                    # Big preview of the SELECTED tile, shown ABOVE the list.
                    # Use template_preview on a real IMAGE Texture bound to the
                    # decoded tile image (Blender renders it natively), falling
                    # back to an icon if the texture is not available.
                    sel = scene.muonline_tile_index
                    if 0 <= sel < len(items):
                        cur = items[sel].idx
                        tex = _get_tile_texture(cur)
                        if tex is not None:
                            box.template_preview(tex)
                        else:
                            ic = tile_icon(cur)
                            box.template_icon(icon_value=ic if ic else 0,
                                               scale=6.0)
                        fn = terrain_build.DEFAULT_TEXTURE_FILES.get(cur, "")
                        box.label(text="%d  %s" % (cur, fn if fn else ""))
                    # Tile list (rows = index + file name only)
                    box.template_list("MUONLINE_UL_tiles", "", scene,
                                      "muonline_tile_items",
                                      scene, "muonline_tile_index", rows=5)
                else:
                    box.label(text="\u672a\u627e\u5230\u74e6\u7247\u7eb9\u7406 (\u68c0\u67e5 Data/World%d)" % p.world_id, icon="ERROR")
        elif mode == "LIGHT":
            box.prop(p, "light_mode")
            box.prop(p, "light_color")
        elif mode == "WALL":
            wrow = box.row(align=True)
            wrow.prop(p, "wall_type", text="\u5c5e\u6027")
            # show the attribute color swatch right next to the wall-type menu
            wtc = _wall_type_color(p.wall_type)
            if wtc:
                ic = swatch_icon(wtc)
                wrow.label(text="", icon_value=(ic if ic else 0))
            box.prop(p, "wall_erase")
            from .core import state
            if state.get_current() is None:
                box.label(text="\u8bf7\u5148\u70b9\u51fb\u4e0a\u65b9\u201c\u5bfc\u5165\u5730\u56fe\u201d", icon="INFO")
            elif not p.show_walls:
                box.label(text="\u8bf7\u52fe\u9009\u4e0a\u65b9\u201c\u663e\u793a\u5899\u58c1\u201d", icon="INFO")

        box.separator()
        box.operator("muonline_map.brush_paint", text="\u5f00\u59cb\u7b14\u5237 (\u6309\u4f4f LMB)", icon="GREASEPENCIL")

        layout.separator()
        box = layout.box()
        box.label(text="\u7269\u4f53", icon="EMPTY_DATA")
        # type dropdown (like the wall-attribute dropdown) + custom fallback
        box.prop(p, "object_type", text="\u7c7b\u578b")
        if p.object_type == "custom":
            box.prop(p, "object_custom_type", text="\u81ea\u5b9a\u4e49\u7f16\u53f7")
        row = box.row(align=True)
        row.operator("muonline_map.object_add", icon="ADD")
        row.operator("muonline_map.object_add_model", text="\u6dfb\u52a0\u6a21\u578b", icon="IMPORT")
        row.operator("muonline_map.object_delete", icon="X")
        box.prop(p, "grid_snap")
        box.prop(p, "height_snap")
        box.operator("muonline_map.object_snap", icon="SNAP_ON")
        # imported-object attribute annotation + external model binding
        self._draw_object_selected(context, box)

    def _draw_object_selected(self, context, box):
        """Show the attributes of the selected placed object and let the user
        bind / clear an external model to it."""
        from .core import object_types
        tgt = None
        for o in context.selected_objects:
            if "mu_type" in o:
                tgt = o
                break
        if tgt is None:
            box.label(text="\u9009\u62e9\u4e00\u4e2a\u5730\u9762\u7269\u4f53\u67e5\u770b\u5c5e\u6027", icon="INFO")
            return
        t = int(tgt.get("mu_type", 0))
        mname = object_types.model_name_for_type(t) or "?"
        box.separator()
        sub = box.box()
        sub.label(text="\u5bfc\u5165\u7269\u4f53\u5c5e\u6027", icon="OBJECT_DATA")
        sub.label(text="\u7c7b\u578b: %d  %s" % (t, mname))
        loc = tgt.location
        rot = tgt.rotation_euler
        sc = tgt.scale.x if tgt.scale.x else 1.0
        sub.label(text="\u4f4d\u7f6e: (%.3f, %.3f, %.3f)" % (loc.x, loc.y, loc.z))
        sub.label(text="\u65cb\u8f6c: (%.2f, %.2f, %.2f)\u00b0" % (
            math.degrees(rot.x), math.degrees(rot.y), math.degrees(rot.z)))
        sub.label(text="\u7f29\u653e: %.3f" % sc)
        bound = tgt.get("mu_bound_model")
        if bound:
            sub.label(text="\u7ed1\u5b9a\u6a21\u578b: %s" % bound, icon="MESH_CUBE")
        row = sub.row(align=True)
        row.operator("muonline_map.object_bind_model", text="\u7ed1\u5b9a\u5916\u90e8\u6a21\u578b", icon="IMPORT")
        row.operator("muonline_map.object_clear_model", text="\u89e3\u9664", icon="X")

        # ---- per-object light (only for obj record versions >= 1) ----
        p = _props(context)
        from .core import state as _state
        _d = _state.get_current()
        from .formats.objdata import light_layout_for_version
        ver = _d.objects.version if _d is not None else 0
        n_flags, has_rgb = light_layout_for_version(ver)
        lbox = sub.box()
        lbox.label(text="\u7269\u4f53\u5149\u7167 (obj v%d)" % ver, icon="LIGHT")
        if n_flags == 0:
            lbox.label(text="\u6b64\u5730\u56fe\u7684 obj \u7248\u672c\u4e0d\u5b58\u50a8\u7269\u4f53\u5149\u7167", icon="INFO")
        else:
            flags = tgt.get("mu_light_enable")
            if flags:
                lbox.label(text="\u5f53\u524d: %s" % " ".join(
                    ("\u5f00" if f else "\u5173") for f in flags))
            else:
                lbox.label(text="\u5f53\u524d: \u65e0\u8bb0\u5f55")
            rgb = tgt.get("mu_light_rgb")
            if rgb:
                lbox.label(text="\u989c\u8272: (%.3f, %.3f, %.3f)" % tuple(rgb))
            row = lbox.row(align=True)
            row.prop(p, "obj_light1", toggle=True)
            row.prop(p, "obj_light2", toggle=True)
            if n_flags >= 3:
                row.prop(p, "obj_light3", toggle=True)
            if has_rgb:
                lbox.prop(p, "obj_light_color", text="")
            row = lbox.row(align=True)
            row.operator("muonline_map.object_light_load", text="\u8bfb\u53d6", icon="IMPORT")
            row.operator("muonline_map.object_light_apply", text="\u5e94\u7528", icon="CHECKMARK")


def _props(context):
    return context.scene.muonline_map_props


classes = (MUONLINE_UL_tiles, MUONLINE_PT_map_editor)
