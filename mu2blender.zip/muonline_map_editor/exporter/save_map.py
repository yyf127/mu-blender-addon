# -*- coding: utf-8 -*-
"""Write the edited MapEditorData back to the Data/World{id} folder.

Every file keeps the encryption/structure of the source file (from
data.*_meta), so an unmodified map round-trips byte-for-byte.
"""

import os

import bpy

from ..formats import writers
from ..formats.objdata import OBJData, MapObject, write_obj
from ..core.editor_data import TERRAIN_SIZE, resolve_object_collection

# Inverse of the import X offset (World1 obj data carries +2 tiles in X, which
# we add when placing objects in Blender).  Subtract it back on export so the
# written obj keeps the original coordinates.
MAP_OBJECT_X_OFFSET_TILES = {1: 2}
OBJ_X_SCALE = 100.0


def collect_objects_from_scene(data):
    """Read ground-object transforms from the MU objects collections.
    (Instances are grouped under per-type 'MU_Type{n}' sub-collections, so we
    gather from the object collection + all of its descendant collections.)"""
    objs = []
    col = resolve_object_collection(data)
    if col is None:
        return
    seen = set()
    marked = []
    for o in col.objects:
        if "mu_type" in o:
            marked.append(o)
    # gather from the per-model instance groups (MUGrp_{model}) created by
    # build_object_instances
    for c in list(bpy.data.collections):
        if c.name.startswith("MUGrp_"):
            for o in c.objects:
                if "mu_type" in o:
                    marked.append(o)
    # de-dup (in case an object is linked to both root and a type group)
    marked = [o for o in marked
              if (o.name not in seen) and not seen.add(o.name)]
    marked.sort(key=lambda o: o.get("mu_obj_index", 0))
    off_x = MAP_OBJECT_X_OFFSET_TILES.get(data.world_id, 0) * OBJ_X_SCALE
    import math as _math
    for o in marked:
        loc = o.location
        rot = o.rotation_euler
        sc = o.scale.x
        # If the object was not edited, reuse the exact original record so the
        # exported obj stays byte-identical (avoids radians<->degrees drift).
        # For edited imported objects Blender X already includes the import
        # offset, so subtract it back.
        ipos = o.get("mu_init_pos")
        iang = o.get("mu_init_angle")
        isc = o.get("mu_init_scale")
        has_init = ipos is not None and iang is not None and isc is not None
        if has_init:
            unchanged = (
                abs(loc.x - (ipos[0] + off_x)) < 0.01
                and abs(loc.y - ipos[1]) < 0.01
                and abs(loc.z - ipos[2]) < 0.01 and abs(sc - isc) < 0.01
                and abs(_math.degrees(rot.x) - iang[0]) < 0.01
                and abs(_math.degrees(rot.y) - iang[1]) < 0.01
                and abs(_math.degrees(rot.z) - iang[2]) < 0.01)
            if unchanged:
                objs.append(MapObject(type=int(o["mu_type"]),
                                      position=(ipos[0], ipos[1], ipos[2]),
                                      angle=(iang[0], iang[1], iang[2]),
                                      scale=isc,
                                      extra=o.get("mu_extra", b""),
                                      light_enable=o.get("mu_light_enable"),
                                      light_rgb=o.get("mu_light_rgb")))
                continue
            raw_x = loc.x - off_x
        else:
            # newly added object: never shifted, use location as-is
            raw_x = loc.x
        objs.append(MapObject(type=int(o["mu_type"]),
                              position=(raw_x, loc.y, loc.z),
                              angle=(_math.degrees(rot.x),
                                     _math.degrees(rot.y),
                                     _math.degrees(rot.z)),
                              scale=sc if sc else 1.0,
                              extra=o.get("mu_extra", b""),
                              light_enable=o.get("mu_light_enable"),
                              light_rgb=o.get("mu_light_rgb")))
    data.objects = OBJData(version=data.objects.version,
                           map_number=data.objects.map_number,
                           objects=objs)
    return objs


def export_new_object_models(data):
    """Copy the .bmd files behind user-added model objects into the world's
    Object folder so the real game client can load them.

    HOW THE GAME FINDS THE MODEL (filename-indexed, NOT type-by-type):
    WorldControl loads EncTerrain{world}.obj, and for each MapObject it picks
    an Object class via `MapTileObjects[type]` (WorldObjectFactory).
    * If `MapTileObjects[type]` is the fallback `MapTileObject` (a type the
      world did NOT specialize), its Load() reads exactly:
          Object{world}/Object{(type+1):02}.bmd
      (e.g. type 155 -> Object156.bmd).
    * If the world specialized that type (TreeObject/HouseObject/...), that
      class reads a HARD-CODED filename (Tree01.bmd, House01.bmd, ...), so the
      added model is only visible if that exact filename is written.
    So the file NAME the game reads is decided by the object class the type
    maps to.  For a freshly added model the reliable choice is a type that is
    NOT specialized -> it renders Object{type+1:02}.bmd, which is what we write
    below (re-encrypted v12/FileCryptor).

    When a user adds a model via "add model" (object_add_model), the mesh
    carries `mu_model_src` = the source .bmd path.  This re-encodes it to v12
    (matching the proven old-exporter path) and writes it under the type's
    canonical file name, so an exported .obj record referencing that type
    actually has a model to load in-game.

    Returns a list of (target_abs_path, ok) for reporting.
    """
    if not data or not data.data_dir:
        return []
    world_obj = os.path.join(data.data_dir, "Object%d" % data.world_id)
    results = []
    copied_abs = set()       # target abs paths already written
    # gather all placed objects (root + MUGrp_ groups) that have mu_type
    placed = []
    col = resolve_object_collection(data)
    if col is not None:
        placed.extend(o for o in col.objects if "mu_type" in o)
    for c in list(bpy.data.collections):
        if c.name.startswith("MUGrp_"):
            placed.extend(o for o in c.objects if "mu_type" in o)
    seen = set()
    placed = [o for o in placed
              if (o.name not in seen) and not seen.add(o.name)]

    for o in placed:
        me = o.data
        src = me.get("mu_model_src") if me else None
        if not src:
            continue
        if not isinstance(src, str) or not src.lower().endswith(".bmd"):
            continue
        if not os.path.isfile(src):
            continue
        t = int(o.get("mu_type", 0))
        n = t + 1
        dst = os.path.join(world_obj, "Object%d.bmd" % n)
        # Re-encode the source BMD as v12 (FileCryptor 16-byte XOR), the same
        # format the old io_scene_muonline exporter wrote for added objects and
        # which displays correctly in the real client.  The source may itself be
        # v12 or v15, so we cannot just copy its bytes - we always re-parse and
        # re-encrypt so the output matches the game's v12 FileCryptor layout.
        blob, parsed = _reencode_bmd(src)
        if blob is None:
            results.append((dst, False))
            continue
        if dst in copied_abs:
            continue
        try:
            os.makedirs(world_obj, exist_ok=True)
            with open(dst, "wb") as fdst:
                fdst.write(blob)
            copied_abs.add(dst)
            results.append((dst, True))
        except OSError as e:
            results.append((dst, False))
        # Also copy the texture(s) the BMD references so the game can texture
        # the object (the game only looks in Data/Object{world}/ for the .ozj/
        # .ozt referenced by the bmd's texture_path; Blender/viewer found them
        # from other search roots, which is why they display but the game does
        # not).
        if parsed is not None:
            for tex_result in _export_bmd_textures(parsed, src,
                                                   world_obj, data):
                results.append(tex_result)
    return results


def _export_bmd_textures(bmd, src_bmd, obj_dir, data):
    """Copy a parsed BMD's referenced texture files into obj_dir.

    Returns a list of (target_path, ok).  The bmd's texture_path is a logical
    name (e.g. 'bridge_01.jpg' or 'bridge_01.tga'); the game loads the sibling
    'stem.ozj' (jpg/png/bmp) or 'stem.ozt' (tga).  We look for that encoded
    file next to the source bmd and in the world's Object/Texture folders, and
    copy it in.
    """
    import re as _re
    out = []
    seen = set()
    roots = [os.path.dirname(src_bmd), obj_dir]
    tex_dir = os.path.join(str(data.data_dir or ""), "Texture")
    for i in [tex_dir] if os.path.isdir(tex_dir) else []:
        roots.append(i)
    for sm in bmd.meshes:
        tp = (sm.texture_path or "").replace("\\", "/")
        base = os.path.basename(tp)
        base = _re.sub(r"\.\d{3,}$", "", base)
        stem = os.path.splitext(base)[0]
        low = base.lower()
        # game file name: stem.ozj for jpg/png/bmp, stem.ozt for tga/ozt
        if low.endswith((".tga", ".ozt")):
            fn = stem + ".ozt"
        else:
            fn = stem + ".ozj"
        # also try raw basename match (some bmd store the .ozj/.ozt directly)
        candidates = [fn, base]
        for cand in candidates:
            if cand in seen:
                break
            found = None
            for r in roots:
                p = os.path.join(r, cand)
                if os.path.isfile(p):
                    found = p
                    break
            if found is not None:
                seen.add(cand)
                dst = os.path.join(obj_dir, cand)
                try:
                    with open(found, "rb") as fr, open(dst, "wb") as fw:
                        fw.write(fr.read())
                    out.append((dst, True))
                except OSError:
                    out.append((dst, False))
                break
    return out


def _reencode_bmd(src):
    """Read a source .bmd and re-encode it as v12 (FileCryptor) bytes.

    Returns (v12_bytes, parsed_bmd) or (None, None) if it cannot be parsed.

    v12 is used (not v15/LEA) because the old io_scene_muonline exporter
    writes added objects as v12 (FileCryptor 16-byte XOR) and that displays
    correctly in the real client.  The client's BMDReader can decrypt both
    v12 (FileCryptor) and v15 (LEA), but v15/LEA output from this plugin
    rendered incorrectly, so we stay on the proven v12 path.
    """
    try:
        from ..formats.bmd import parse_bmd, write_bmd
        with open(src, "rb") as f:
            data = f.read()
        bmd = parse_bmd(data)
        return write_bmd(bmd, version=12), bmd
    except Exception:
        return None, None


def save_map(data, out_dir=None):
    """Write all edited files.  Returns a list of (relative_path, ok)."""
    out_dir = out_dir or data.data_dir
    world_dir = os.path.join(out_dir, "World%d" % data.world_id)
    os.makedirs(world_dir, exist_ok=True)
    S = TERRAIN_SIZE
    results = []

    def _write(fname, blob):
        path = os.path.join(world_dir, fname)
        with open(path, "wb") as f:
            f.write(blob)
        results.append((fname, True))
        return path

    # ---- ATT ----
    m = data.att_meta
    _write("EncTerrain%d.att" % data.world_id,
           writers.write_att(data.att, m.algorithm_2, m.algorithm_1, m.key_2,
                             use_modulus=m.use_modulus))

    # ---- MAP ----
    m = data.map_meta
    _write("EncTerrain%d.map" % data.world_id,
           writers.write_map(data.mapping, m.algorithm_2, m.algorithm_1,
                             m.key_2, use_modulus=m.use_modulus))

    # ---- Light OZB ----
    m = data.light_meta
    rgb_rows = [(int(data.light[i][0] * 255),
                 int(data.light[i][1] * 255),
                 int(data.light[i][2] * 255)) for i in range(S * S)]
    _write("TerrainLight.OZB",
           writers.make_ozb_light(rgb_rows, version=m.version))

    # ---- Height OZB ----
    m = data.height_meta
    if m.is_192k:
        rgb = []
        for i in range(S * S):
            h = int(data.height[i]) + 500
            r = (h >> 16) & 0xFF
            g = (h >> 8) & 0xFF
            b = h & 0xFF
            rgb.append((r, g, b))
        _write("TerrainHeight.OZB",
               writers.make_ozb_height_192k(rgb, version=m.version))
    else:
        gray = [int(max(0, min(255, data.height[i] / 1.5)))
                for i in range(S * S)]
        _write("TerrainHeight.OZB",
               writers.make_ozb_height(gray, version=m.version))

    # ---- Objects ----
    collect_objects_from_scene(data)
    _write("EncTerrain%d.obj" % data.world_id, write_obj(data.objects))

    # ---- copy user-added .bmd models into the world Object folder so the game
    # client can load them (only for objects added via "add model" with a .bmd
    # source).  Report each copy as a result entry.
    try:
        for dst, ok in export_new_object_models(data):
            rel = os.path.relpath(dst, out_dir)
            results.append((rel, ok))
    except Exception:
        pass

    return results
