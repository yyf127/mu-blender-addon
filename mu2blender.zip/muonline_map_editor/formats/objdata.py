# -*- coding: utf-8 -*-
"""地图物件表 EncTerrain*.obj —— 对应 TS 工程 src/terrain/formats/OBJReader.ts / OBJWriter.ts。

布局(FileCryptor 解密后):
    [0] version | [1] mapNumber | [2..3] count(s16)
    记录 xN(版本相关长度):
        type(s16) | pos(f32x3) | angle(f32x3) | scale(f32) = 30B 基础
        v1=32B(v0+2B) v2=33B(v1+1B) v3=45B(v2+12B 光照) v4=46B v5=54B
"""

from dataclasses import dataclass, field

from .binary import BinaryReader, BinaryWriter
from ..crypto.file_cryptor import decrypt_file_cryptor, encrypt_file_cryptor

# 版本 → 每条记录字节数(与 MapObject.cs / OBJReader.ts 一致)
OBJ_RECORD_SIZES = {0: 30, 1: 32, 2: 33, 3: 45, 4: 46, 5: 54}
BASE_RECORD = 30


# ---- per-object LIGHT extra bytes (verified against real data) --------------
# Record versions carry extra bytes after the 30-byte base:
#   v1 (extra 2) : [0]=LightEnable1 [1]=LightEnable2
#   v2 (extra 3) : [0]=LightEnable1 [1]=LightEnable2 [2]=LightEnable3
#   v3 (extra 15): [0..2]=LightEnable1/2/3 [3..14]=zero padding
#   v4 (extra 16): [0..2]=LightEnable1/2/3 [3..14]=LightColor RGB (3x float32)
#                  [15]=flag (1 when LightEnable1 is on)
# Matches the reference WorldEditor struct ObjCreatePrepare
# (ModelID / Position / Angle / LightColor / Scale / LightEnable1/2/3).
# version -> (extra_bytes, num_light_flags, has_rgb)
LIGHT_EXTRA_LAYOUT = {
    1: (2, 2, False),
    2: (3, 3, False),
    3: (15, 3, False),
    4: (16, 3, True),
    5: (24, 3, True),
}


def light_layout_for_version(version):
    """Return (num_light_flags, has_rgb) for an OBJ record version."""
    _extra, n_flags, has_rgb = LIGHT_EXTRA_LAYOUT.get(version, (0, 0, False))
    return n_flags, has_rgb


def parse_object_lights(version, extra):
    """Decode (light_enable, light_rgb) from a record's extra bytes.

    light_enable is a list of 0/1 flags (length depends on the version);
    light_rgb is an (r, g, b) float tuple, or None when the version has no
    colour.  Returns (None, None) for versions without light data (v0).
    """
    n_flags, has_rgb = light_layout_for_version(version)
    if n_flags == 0 or len(extra) < n_flags:
        return None, None
    flags = [1 if extra[i] else 0 for i in range(n_flags)]
    rgb = None
    if has_rgb and len(extra) >= 15:
        import struct as _struct
        rgb = _struct.unpack("<3f", bytes(extra[3:15]))
    return flags, rgb


def apply_object_lights(version, extra, flags, rgb):
    """Return new extra bytes with the light flags/colour written in.

    Every other byte is preserved so a round-trip stays byte-identical when
    nothing changed.  `extra` may be bytes / bytearray / list.
    """
    n_flags, has_rgb = light_layout_for_version(version)
    if n_flags == 0:
        return bytes(extra)
    out = bytearray(extra)
    if len(out) < n_flags:
        out.extend(b"\x00" * (n_flags - len(out)))
    if flags is not None:
        for i, v in enumerate(flags[:n_flags]):
            out[i] = 1 if v else 0
    if has_rgb and rgb is not None and len(out) >= 15:
        import struct as _struct
        out[3:15] = _struct.pack("<3f", float(rgb[0]), float(rgb[1]),
                                 float(rgb[2]))
    return bytes(out)


@dataclass
class MapObject:
    type: int = 0
    position: tuple = (0.0, 0.0, 0.0)     # (x,y,z)
    angle: tuple = (0.0, 0.0, 0.0)        # (x,y,z) 弧度
    scale: float = 1.0
    extra: bytes = b""                    # 版本特有的额外字节
    # Decoded from `extra` (see parse_object_lights); None when the record
    # version carries no light data.
    light_enable: list = None             # [Light1, Light2, Light3]
    light_rgb: tuple = None               # (r, g, b) floats


@dataclass
class OBJData:
    version: int = 0
    map_number: int = 0
    objects: list = field(default_factory=list)   # [MapObject]


def read_obj(buffer: bytes) -> OBJData:
    u8 = decrypt_file_cryptor(buffer)
    br = BinaryReader(u8)
    version = br.read_u8()
    map_number = br.read_u8()
    count = br.read_s16()

    obj_size = OBJ_RECORD_SIZES.get(version)
    if obj_size is None:
        raise ValueError(f"OBJ: unsupported version {version}")

    objects = []
    for _ in range(count):
        type_ = br.read_s16()
        px, py, pz = br.read_vec3()
        ax, ay, az = br.read_vec3()
        scale = br.read_f32()
        extra_len = obj_size - BASE_RECORD
        extra = br.read(extra_len) if extra_len > 0 else b""
        lights, rgb = parse_object_lights(version, extra)
        objects.append(MapObject(type=type_, position=(px, py, pz),
                                 angle=(ax, ay, az), scale=scale, extra=extra,
                                 light_enable=lights, light_rgb=rgb))
    return OBJData(version=version, map_number=map_number, objects=objects)


def write_obj(data: OBJData) -> bytes:
    obj_size = OBJ_RECORD_SIZES.get(data.version)
    if obj_size is None:
        raise ValueError(f"OBJ: unsupported version {data.version}")
    if len(data.objects) > 0x7FFF:
        raise ValueError(f"OBJ: too many objects ({len(data.objects)})")

    br = BinaryWriter()
    br.write_u8(data.version & 0xFF)
    br.write_u8(data.map_number & 0xFF)
    br.write_s16(len(data.objects))

    for obj in data.objects:
        br.write_s16(obj.type)
        br.write_vec3(obj.position)
        br.write_vec3(obj.angle)
        br.write_f32(obj.scale)
        extra_len = obj_size - BASE_RECORD
        if extra_len > 0:
            raw = obj.extra if obj.extra else b"\x00" * extra_len
            # fold an edited light back into the version-specific layout
            raw = apply_object_lights(data.version, raw,
                                      obj.light_enable, obj.light_rgb)
            extra = bytes(raw)[:extra_len]
            br.write(extra.ljust(extra_len, b"\x00"))

    return encrypt_file_cryptor(br.getvalue())
