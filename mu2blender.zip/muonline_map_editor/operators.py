# -*- coding: utf-8 -*-
"Operators: import / export the map, the modal brush, and object tools."

import math
import os

import bpy
from bpy.types import Operator
from bpy.props import StringProperty
from bpy_extras.view3d_utils import (region_2d_to_origin_3d,
                                     region_2d_to_vector_3d)
from mathutils.bvhtree import BVHTree

from .core import state
from .core.editor_data import TERRAIN_SCALE, resolve_object_collection
from .importer import load_map as loader
from .exporter import save_map as saver
from .core import brushes
from .formats.objdata import MapObject

_wall_bitmap = {
    "0x0000": 0x0000, "0x0001": 0x0001, "0x0002": 0x0002, "0x0004": 0x0004,
    "0x0008": 0x0008, "0x0010": 0x0010, "0x0020": 0x0020,
    "0x0040": 0x0040, "0x0080": 0x0080, "0x0100": 0x0100,
}


def _props(context):
    return context.scene.muonline_map_props


def _terrain_obj():
    return bpy.data.objects.get("MU_Terrain")


_terrain_bvh_cache = None


def _terrain_bvh():
    """BVH of the terrain mesh only, so BMD object models never block the
    brush raycast."""
    global _terrain_bvh_cache
    obj = _terrain_obj()
    if obj is None:
        _terrain_bvh_cache = None
        return None
    if _terrain_bvh_cache is None:
        _terrain_bvh_cache = BVHTree.FromObject(
            obj, bpy.context.evaluated_depsgraph_get())
    return _terrain_bvh_cache


def _invalidate_terrain_bvh():
    global _terrain_bvh_cache
    _terrain_bvh_cache = None


def _cell_from_ray(context, co):
    region = context.region
    rv3d = context.region_data
    if not region or not rv3d:
        return None
    origin = region_2d_to_origin_3d(region, rv3d, co)
    direction = region_2d_to_vector_3d(region, rv3d, co)
    bvh = _terrain_bvh()
    if bvh is None:
        return None
    loc, _normal, _idx, _dist = bvh.ray_cast(origin, direction)
    if loc is None:
        return None
    cx = math.floor(loc.x / TERRAIN_SCALE)
    cy = math.floor(loc.y / TERRAIN_SCALE)
    return cx, cy, loc


def _refresh_wall_overlay(context):
    from .core import wall_display
    p = _props(context)
    if p.show_walls:
        data = state.get_current()
        if data is not None:
            wall_display.update_wall_overlay(data)


class MUONLINE_OT_import_map(Operator):
    bl_idname = "muonline_map.import_map"
    bl_label = "\u5bfc\u5165\u5730\u56fe"
    bl_description = "\u4ece Data \u76ee\u5f55\u5bfc\u5165\u5730\u56fe(\u5730\u5f62/\u74e6\u7247/\u5149\u5f71/\u5899\u58c1/\u7269\u4f53)"

    def execute(self, context):
        p = _props(context)
        data = loader.load_map(p.data_dir, p.world_id)
        if not (data.att.terrain_wall or data.mapping.layer1):
            self.report({"ERROR"}, "\u672a\u627e\u5230\u8be5\u5730\u56fe\u7684 ATT/MAP \u6587\u4ef6")
            return {"CANCELLED"}
        loader.build_scene(
            data, object_mode="model" if p.show_object_models else "empty")
        from .core import terrain_build as _tb
        # Build tile-preview images + fill the picker list HERE (an operator,
        # so writing ID data is legal - never do it in a panel draw).
        imgs = _tb.build_tile_previews(data)
        scene = context.scene
        items = scene.muonline_tile_items
        items.clear()
        for k in sorted(imgs.keys()):
            it = items.add()
            it.idx = k
        scene.muonline_tile_index = 0
        if items:
            p.tile_index = items[0].idx
        # Always create the wall overlay (user hides it manually in the
        # outliner; it is never auto-hidden).
        try:
            from .core import wall_display
            wo = wall_display.update_wall_overlay(data)
            scene.collection.objects.link(wo) if wo is not None else None
        except Exception:
            pass
        # Pre-build preview ICONS (tile thumbnails + wall swatches) via
        # bpy.utils.previews (legal here, never in draw). The panel reads these
        # with template_icon - NOT template_preview(Image), which Blender 5.1
        # rejects.
        try:
            from . import panels as _pan
            _pan.build_previews(data)
        except Exception:
            pass
        state.set_current(data)
        p.loaded = True
        p.world_name = "World%d" % data.world_id
        p.status = "\u5df2\u52a0\u8f7d World%d (%d \u7269\u4f53)" % (
            data.world_id, len(data.objects.objects))
        return {"FINISHED"}


class MUONLINE_OT_export_map(Operator):
    bl_idname = "muonline_map.export_map"
    bl_label = "\u5bfc\u51fa\u5730\u56fe"
    bl_description = "\u628a\u7f16\u8f91\u540e\u7684\u5730\u56fe\u5199\u56de Data/World{id}(ATT/MAP/OZB/OBJ)"

    def execute(self, context):
        p = _props(context)
        data = state.get_current()
        if data is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        results = saver.save_map(data, out_dir=p.data_dir)
        ok = sum(1 for _, good in results if good)
        p.status = "\u5df2\u5bfc\u51fa %d \u4e2a\u6587\u4ef6\u5230 World%d" % (ok, data.world_id)
        self.report({"INFO"}, "\u5bfc\u51fa %d \u4e2a\u6587\u4ef6" % ok)
        return {"FINISHED"}


class MUONLINE_OT_brush_paint(Operator):
    """Modal: hold LMB and drag to paint with the active brush."""
    bl_idname = "muonline_map.brush_paint"
    bl_label = "\u7b14\u5237\u7ed8\u5236"
    bl_options = {"REGISTER"}

    _mouse = (0, 0)
    _lmb = False
    _last_cell = None

    def _apply_at(self, context):
        p = _props(context)
        data = state.get_current()
        obj = _terrain_obj()
        cell = _cell_from_ray(context, self._mouse)
        if cell is None or data is None or obj is None:
            return
        cx, cy, loc = cell
        # radius follows brush_size directly: 0 -> exactly 1 cell, larger ->
        # a disk of that many cells. (No "+1"; that used to always paint >=5 cells.)
        r = p.brush_size
        mode = p.tool_mode
        if mode == "HEIGHT":
            brushes.brush_height(data, obj, cx, cy, r, p.height_mode,
                                 p.brush_strength, p.flatten_height)
        elif mode == "TILE":
            # Use the tile selected in the picker list (scene.muonline_tile_index
            # -> items[sel].idx), falling back to p.tile_index if the list is
            # empty.  This fixes painting always tile 0.
            tile_idx = p.tile_index
            try:
                items = context.scene.muonline_tile_items
                sel = context.scene.muonline_tile_index
                if items and 0 <= sel < len(items):
                    tile_idx = items[sel].idx
            except Exception:
                pass
            brushes.brush_tile(data, obj, cx, cy, r, p.tile_layer, tile_idx,
                               p.tile_alpha)
        elif mode == "LIGHT":
            brushes.brush_light(data, obj, cx, cy, r, p.light_color,
                                p.light_mode)
        elif mode == "WALL":
            # Wall display reads attr at (cx - xoff) to show at geometric cell
            # cx (World1 xoff=2).  So painting at the clicked cell must write to
            # (cx - xoff), otherwise the change appears +X2 tiles away.
            from .core import wall_display
            wt_x_off = wall_display.MAP_OBJECT_X_OFFSET_TILES.get(data.world_id, 0)
            bx = cx - wt_x_off if cx >= wt_x_off else cx
            wt = _wall_bitmap.get(p.wall_type, 0x0001)
            if p.wall_erase:
                # Erase = turn the cells into "NoMove" (forbidden zone).
                brushes.brush_wall(data, bx, cy, r, brushes.TWFlags.NoMove,
                                   on=True, overwrite=True)
            else:
                # Paint = overwrite the cells' attribute with the chosen wall
                # type so it visibly swaps to that region.
                brushes.brush_wall(data, bx, cy, r, wt, on=True,
                                   overwrite=True)
                if wt == 0x0000:  # walkable (walkable) -> NoGround face update not needed
                    pass
                elif wt == 0x0008:  # NoGround changes faces -> full rebuild
                    self._rebuild_terrain(data)
            _refresh_wall_overlay(context)
        data.terrain_obj = obj

    def _rebuild_terrain(self, data):
        from .core import terrain_build
        obj = _terrain_obj()
        if obj is None:
            return
        col = obj.users_collection[0] if obj.users_collection else None
        me = obj.data
        bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.meshes.remove(me)
        _invalidate_terrain_bvh()
        new_obj = terrain_build.build_terrain_mesh(data)
        if col:
            col.objects.link(new_obj)
        terrain_build.assign_tile_materials(data, new_obj)
        data.terrain_obj = new_obj

    def modal(self, context, event):
        p = _props(context)
        if state.get_current() is None or _terrain_obj() is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            context.area.header_text_set(None)
            return {"CANCELLED"}

        if event.type in {"RIGHTMOUSE", "ESC"}:
            self._lmb = False
            context.area.header_text_set(None)
            p.status = "\u7b14\u5237\u7ed3\u675f"
            return {"FINISHED"}

        if event.type == "LEFTMOUSE":
            self._lmb = (event.value == "PRESS")
            if self._lmb:
                context.area.header_text_set("\u6309\u4f4f LMB \u62d6\u52a8\u7ed8\u5236,\u53f3\u952e\u7ed3\u675f")
                self._mouse = (event.mouse_region_x, event.mouse_region_y)
                self._last_cell = None
                self._apply_at(context)
            return {"RUNNING_MODAL"}

        if event.type == "MOUSEMOVE":
            self._mouse = (event.mouse_region_x, event.mouse_region_y)
            if self._lmb:
                cell = _cell_from_ray(context, self._mouse)
                if cell is not None:
                    key = (cell[0], cell[1])
                    if key != self._last_cell:
                        self._last_cell = key
                        self._apply_at(context)
            return {"RUNNING_MODAL"}

        return {"PASS_THROUGH"}

    def invoke(self, context, event):
        if context.area.type != "VIEW_3D":
            self.report({"WARNING"}, "\u8bf7\u5728 3D \u89c6\u53e3\u4f7f\u7528")
            return {"CANCELLED"}
        self._mouse = (event.mouse_region_x, event.mouse_region_y)
        self._lmb = False
        self._last_cell = None
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}


class MUONLINE_OT_object_snap(Operator):
    bl_idname = "muonline_map.object_snap"
    bl_label = "\u7269\u4f53\u8d34\u5730/\u5438\u9644"
    bl_description = "\u628a\u9009\u4e2d\u7684\u5730\u9762\u7269\u4f53\u5438\u9644\u5230\u5730\u5f62\u9ad8\u5ea6(\u548c\u7f51\u683c)"

    def execute(self, context):
        p = _props(context)
        data = state.get_current()
        if data is None or _terrain_obj() is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        for o in context.selected_objects:
            if "mu_type" not in o:
                continue
            cx = math.floor(o.location.x / TERRAIN_SCALE)
            cy = math.floor(o.location.y / TERRAIN_SCALE)
            h = data.get_height(cx, cy)
            if p.grid_snap:
                o.location.x = round(o.location.x / 50.0) * 50.0
                o.location.y = round(o.location.y / 50.0) * 50.0
            if p.height_snap:
                o.location.z = h + (o["mu_off_z"] if "mu_off_z" in o else 0.0)
        return {"FINISHED"}


class MUONLINE_OT_object_add(Operator):
    bl_idname = "muonline_map.object_add"
    bl_label = "\u6dfb\u52a0\u7269\u4f53"
    bl_description = "\u5728 3D \u5149\u6807\u5904\u653e\u7f6e\u4e00\u4e2a\u5730\u9762\u7269\u4f53(\u7c7b\u578b\u6765\u81ea\u9762\u677f)"

    def execute(self, context):
        p = _props(context)
        data = state.get_current()
        if data is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        col = resolve_object_collection(data)
        if col is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        loc = context.scene.cursor.location
        from .core import object_types
        obj_type = object_types.enum_to_type(p.object_type,
                                             p.object_custom_type)
        empty = bpy.data.objects.new("MUObj_t%d" % obj_type, None)
        empty.empty_display_type = "ARROWS"
        empty.empty_display_size = 50.0
        empty.location = (loc.x, loc.y, loc.z)
        empty["mu_type"] = obj_type
        empty["mu_scale"] = 1.0
        col.objects.link(empty)
        data.objects.objects.append(MapObject(
            type=obj_type, position=(loc.x, loc.y, loc.z),
            angle=(0.0, 0.0, 0.0), scale=1.0))
        return {"FINISHED"}


class MUONLINE_OT_object_add_model(Operator):
    """Add a ground object from a model file (bmd/fbx/obj/glb/...).

    Picks a model file, then:
      * decodes/imports it once,
      * auto-groups every object of that model under one 'MUGrp_{name}'
        collection under the object root,
      * shares a single mesh per model file (auto-mesh / instancing),
      * places a new object using that shared mesh at the 3D cursor with the
        currently selected game object type (so it also exports as a game
        object record).
    """
    bl_idname = "muonline_map.object_add_model"
    bl_label = "\u6dfb\u52a0\u6a21\u578b\u7269\u4f53"
    bl_description = "\u9009\u62e9 bmd/fbx/obj/glb \u7b49\u6a21\u578b\u6dfb\u52a0\u5730\u9762\u7269\u4f53(\u81ea\u52a8\u5f52\u96c6+\u5171\u4eab\u7f51\u683c)"
    filepath: StringProperty(name="\u6a21\u578b\u6587\u4ef6", subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.bmd;*.fbx;*.obj;*.glb;*.gltf;*.stl;*.blend;*.abc;*.usd;*.usda;*.usdc", options={"HIDDEN"})

    def _type_col(self, data, name):
        tcol = bpy.data.collections.get(name)
        if tcol is None:
            tcol = bpy.data.collections.new(name)
            (resolve_object_collection(data) or bpy.context.scene.collection).children.link(tcol)
        return tcol

    def execute(self, context):
        data = state.get_current()
        if data is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        col = resolve_object_collection(data)
        if col is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        fp = self.filepath
        if not fp or not os.path.isfile(fp):
            self.report({"ERROR"}, "\u6a21\u578b\u6587\u4ef6\u4e0d\u5b58\u5728")
            return {"CANCELLED"}

        p = _props(context)
        from .core import object_types
        obj_type = object_types.enum_to_type(p.object_type,
                                             p.object_custom_type)
        loc = context.scene.cursor.location
        ext = os.path.splitext(fp)[1].lower()
        base = os.path.splitext(os.path.basename(fp))[0]
        mname = self._sanitize(base) or "model"

        mesh = self._build_shared_mesh(fp, ext, mname, context)
        if mesh is None:
            self.report({"ERROR"}, "\u6a21\u578b\u7f51\u683c\u6784\u5efa\u5931\u8d25: %s" % fp)
            return {"CANCELLED"}

        idx = len(data.objects.objects)
        obj = bpy.data.objects.new("MUObj_%s_%d" % (mname, idx), mesh)
        obj.location = (loc.x, loc.y, loc.z)
        obj.rotation_euler = (0.0, 0.0, 0.0)
        obj.scale = (1.0, 1.0, 1.0)
        obj["mu_type"] = obj_type
        obj["mu_obj_index"] = idx
        obj["mu_scale"] = 1.0
        # NOTE: no mu_init_* here so collect_objects_from_scene treats this as a
        # freshly added object and exports its raw location as-is (new objects
        # are placed at the bare cursor, they do NOT carry the imported-game
        # +X offset, so we must not subtract it back on export).

        # auto-group under MUGrp_{model}
        tcol = self._type_col(data, "MUGrp_%s" % mname)
        tcol.objects.link(obj)

        data.objects.objects.append(MapObject(
            type=obj_type, position=(loc.x, loc.y, loc.z),
            angle=(0.0, 0.0, 0.0), scale=1.0))
        return {"FINISHED"}

    def _build_shared_mesh(self, fp, ext, mname, context):
        """Return a shared mesh for this model file, or None."""
        cache_key = self._cache_key(fp)
        # mesh shared per file so all objects of the same file reuse it
        for me in bpy.data.meshes:
            if me.get("mu_model_src") == cache_key:
                return me
        if ext == ".bmd":
            mesh = self._bmd_mesh(fp, mname, context)
        else:
            mesh = self._external_mesh(fp, ext, mname, context)
        if mesh is not None:
            mesh["mu_model_src"] = cache_key
        return mesh

    def _cache_key(self, fp):
        try:
            return os.path.abspath(fp)
        except Exception:
            return fp

    def _bmd_mesh(self, fp, mname, context):
        try:
            from .formats.bmd import parse_bmd
            from .core import bmd_display
            bmd = parse_bmd(open(fp, "rb").read(), bind_pose_only=True)
            roots = [os.path.dirname(fp), data_dir_of(context)]
            mesh = bmd_display.build_bmd_mesh(bmd, "MUBMD_%s" % mname, search_roots=roots)
            if mesh is None:
                return None
            # give it a game-style collection slot as well
            return mesh
        except Exception as e:
            self.report({"WARNING"}, "BMD \u89e3\u7801\u5931\u8d25: %s" % e)
            return None

    def _external_mesh(self, fp, ext, mname, context):
        before = set(bpy.data.objects)
        imported = None
        if ext == ".blend":
            imported = self._import_blend(fp, before, context)
        else:
            imported = self._import_file(fp, ext, before, context)
        if imported is None:
            return None
        # find a mesh to share - the imported root's mesh (or first mesh)
        src = imported if imported.type == "MESH" else None
        if src is None:
            for c in imported.children:
                if c.type == "MESH":
                    src = c
                    break
        if src is None:
            # collect all newly-created mesh objects
            for o in bpy.data.objects:
                if o not in before and o.type == "MESH":
                    src = o
                    break
        if src is None:
            return None
        # share a single mesh datablock (auto-mesh): reuse existing by name
        me = src.data
        me.name = "MUBMD_%s" % mname
        return me

    def _import_file(self, fp, ext, before, context):
        op_map = {
            ".fbx": "import_scene.fbx", ".obj": "import_scene.obj",
            ".glb": "import_scene.gltf", ".gltf": "import_scene.gltf",
            ".stl": "import_mesh.stl", ".abc": "wm.alembic_import",
            ".usd": "wm.usd_import", ".usda": "wm.usd_import",
            ".usdc": "wm.usd_import",
        }
        op = op_map.get(ext)
        if not op:
            self.report({"ERROR"}, "\u4e0d\u652f\u6301\u7684\u683c\u5f0f: %s" % ext)
            return None
        mod, name = op.split(".")
        if not hasattr(bpy.ops, mod) or not hasattr(getattr(bpy.ops, mod), name):
            self.report({"ERROR"}, "\u7f3a\u5c11\u5bfc\u5165\u63d2\u4ef6: %s" % op)
            return None
        try:
            getattr(getattr(bpy.ops, mod), name)(filepath=fp)
        except Exception as e:
            self.report({"ERROR"}, "\u5bfc\u5165\u5931\u8d25(%s): %s" % (ext, e))
            return None
        added = [o for o in bpy.data.objects if o not in before]
        if not added:
            return None
        roots = [o for o in added if o.parent is None]
        return (roots[0] if roots else added[0])

    def _import_blend(self, fp, before, context):
        try:
            with bpy.data.libraries.load(fp, link=False) as (src, dst):
                dst.objects = [n for n in src.objects if n]
            if not dst.objects:
                return None
            imported = None
            for nm in dst.objects:
                if nm is None:
                    continue
                ob = bpy.data.objects.get(nm)
                if ob is None:
                    continue
                if ob.name not in context.scene.collection.objects:
                    context.scene.collection.objects.link(ob)
                if imported is None:
                    imported = ob
            return imported
        except Exception as e:
            self.report({"ERROR"}, "\u5bfc\u5165\u5931\u8d25(.blend): %s" % e)
            return None

    def _sanitize(self, name):
        out = []
        for ch in str(name):
            out.append(ch if (ch.isalnum() or ch in "_-.") else "_")
        s = "".join(out).strip("_. ")
        return s

    def invoke(self, context, event):
        data = state.get_current()
        if data is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        if resolve_object_collection(data) is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


def data_dir_of(context):
    data = state.get_current()
    if data is not None:
        return getattr(data, "data_dir", None)
    return None


class MUONLINE_OT_object_bind_model(Operator):
    """Attach an external model file to the selected placed object.

    The selected MU object keeps its game 'mu_type' (and export reads position/
    rotation/scale from it as usual), while the imported file becomes a child
    object that displays the custom model in its place.  This lets you preview /
    layout with a production model that is NOT one of the in-game BMDs, without
    changing the data that is written back to the .obj file.
    """
    bl_idname = "muonline_map.object_bind_model"
    bl_label = "\u7ed1\u5b9a\u5916\u90e8\u6a21\u578b"
    bl_description = "\u628a\u9009\u4e2d\u5730\u9762\u7269\u4f53\u7ed1\u5b9a\u4e00\u4e2a\u5916\u90e8 3D \u6a21\u578b(fbx/obj/glb/blend)\u7528\u4e8e\u663e\u793a\u917d\u5f62"
    filepath: StringProperty(name="\u6a21\u578b\u6587\u4ef6", subtype="FILE_PATH")

    def _selected_mu_obj(self, context):
        for o in context.selected_objects:
            if "mu_type" in o:
                return o
        return None

    def execute(self, context):
        data = state.get_current()
        if data is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        tgt = self._selected_mu_obj(context)
        if tgt is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u9009\u62e9\u4e00\u4e2a\u5730\u9762\u7269\u4f53(\u5305\u542b mu_type)")
            return {"CANCELLED"}
        fp = self.filepath
        if not fp:
            self.report({"ERROR"}, "\u672a\u9009\u62e9\u6a21\u578b\u6587\u4ef6")
            return {"CANCELLED"}
        if not os.path.isfile(fp):
            self.report({"ERROR"}, "\u6a21\u578b\u6587\u4ef6\u4e0d\u5b58\u5728: %s" % fp)
            return {"CANCELLED"}

        # drop any model already bound to this object
        self._clear_bound(context, tgt)

        # remember the object set before importing so we can find the new root
        before = set(bpy.data.objects)
        ext = os.path.splitext(fp)[1].lower()
        imported = None
        if ext == ".blend":
            imported = self._import_blend(fp, before, context)
        else:
            imported = self._import_file(fp, before, context)
        if imported is None:
            self.report({"ERROR"}, "\u4e0d\u652f\u6301\u6216\u5bfc\u5165\u5931\u8d25: %s" % ext)
            return {"CANCELLED"}

        # parent the custom model to the MU object so it follows it and the
        # game transform (export reads location/rotation/scale from the MU
        # empty as normal).
        imported.parent = tgt
        imported.matrix_local = Matrix.Identity(4)
        imported["mu_bound"] = True
        imported["mu_bound_of"] = tgt.name
        tgt["mu_bound_model"] = os.path.basename(fp)
        tgt.select_set(True)
        return {"FINISHED"}

    def _import_file(self, fp, before, context):
        op_map = {
            ".fbx": "import_scene.fbx", ".obj": "import_scene.obj",
            ".glb": "import_scene.gltf", ".gltf": "import_scene.gltf",
            ".stl": "import_mesh.stl", ".abc": "wm.alembic_import",
            ".usd": "wm.usd_import", ".usda": "wm.usd_import",
            ".usdc": "wm.usd_import",
        }
        op = op_map.get(os.path.splitext(fp)[1].lower())
        if not op:
            return None
        mod, name = op.split(".")
        if not hasattr(bpy.ops, mod) or not hasattr(getattr(bpy.ops, mod), name):
            self.report({"ERROR"}, "\u7f3a\u5c11\u5bfc\u5165\u63d2\u4ef6: %s" % op)
            return None
        try:
            getattr(getattr(bpy.ops, mod), name)(filepath=fp)
        except Exception as e:
            self.report({"ERROR"}, "\u5bfc\u5165\u5931\u8d25(%s): %s" % (os.path.splitext(fp)[1], e))
            return None
        added = [o for o in bpy.data.objects if o not in before]
        if not added:
            # some importers reuse existing objects; fall back to the last
            # top-level object that isn't part of the MU editor scene
            return self._last_free_top(context)
        # pick the top-most newly added object (the root, no parent)
        roots = [o for o in added if o.parent is None]
        return (roots[0] if roots else added[0])

    def _import_blend(self, fp, before, context):
        try:
            with bpy.data.libraries.load(fp, link=False) as (src, dst):
                dst.objects = [n for n in src.objects if n]
            if not dst.objects:
                self.report({"ERROR"}, "\u5bfc\u5165\u5931\u8d25: .blend \u65e0\u53ef\u5bfc\u5165\u5bf9\u8c61")
                return None
            imported = None
            for nm in dst.objects:
                if nm is None:
                    continue
                ob = bpy.data.objects.get(nm)
                if ob is None:
                    continue
                if ob.name not in context.scene.collection.objects:
                    context.scene.collection.objects.link(ob)
                if imported is None:
                    imported = ob
            return imported
        except Exception as e:
            self.report({"ERROR"}, "\u5bfc\u5165\u5931\u8d25(.blend): %s" % e)
            return None

    def _last_free_top(self, context):
        roots = [o for o in bpy.data.objects
                 if o.parent is None and "mu_type" not in o
                 and not o.name.startswith("MU_")]
        return roots[-1] if roots else None

    def _clear_bound(self, context, tgt):
        for o in list(bpy.data.objects):
            if o.get("mu_bound_of") == tgt.name:
                bpy.data.objects.remove(o, do_unlink=True)
        if "mu_bound_model" in tgt:
            del tgt["mu_bound_model"]

    def invoke(self, context, event):
        data = state.get_current()
        if data is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        tgt = self._selected_mu_obj(context)
        if tgt is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u9009\u62e9\u4e00\u4e2a\u5730\u9762\u7269\u4f53(\u5305\u542b mu_type)")
            return {"CANCELLED"}
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class MUONLINE_OT_object_clear_model(Operator):
    """Detach the externally-bound model from the selected placed object."""
    bl_idname = "muonline_map.object_clear_model"
    bl_label = "\u89e3\u9664\u5916\u90e8\u6a21\u578b"
    bl_description = "\u79fb\u9664\u9009\u4e2d\u7269\u4f53\u7ed1\u5b9a\u7684\u5916\u90e8\u6a21\u578b(\u6062\u590d\u663e\u793a\u6e38\u620f BMD/\u7a7a\u7269\u4f53)"

    def execute(self, context):
        data = state.get_current()
        if data is None:
            self.report({"ERROR"}, "\u8bf7\u5148\u5bfc\u5165\u5730\u56fe")
            return {"CANCELLED"}
        removed = 0
        for o in list(bpy.data.objects):
            if "mu_bound_of" in o:
                bpy.data.objects.remove(o, do_unlink=True)
                removed += 1
            if "mu_bound_model" in o:
                del o["mu_bound_model"]
        self.report({"INFO"}, "\u5df2\u89e3\u9664 %d \u4e2a\u7ed1\u5b9a\u6a21\u578b" % removed)
        return {"FINISHED"}


class MUONLINE_OT_object_delete(Operator):
    bl_idname = "muonline_map.object_delete"
    bl_label = "\u5220\u9664\u7269\u4f53"
    bl_description = "\u5220\u9664\u9009\u4e2d\u7684\u5730\u9762\u7269\u4f53(\u4ece obj \u8868\u79fb\u9664)"

    def execute(self, context):
        data = state.get_current()
        if data is None:
            return {"CANCELLED"}
        sel = [o for o in context.selected_objects if "mu_type" in o]
        for o in sel:
            bpy.data.objects.remove(o, do_unlink=True)
        saver.collect_objects_from_scene(data)
        return {"FINISHED"}


class MUONLINE_OT_toggle_walls(Operator):
    """Create or remove the wall-attribute overlay (called from the
    show_walls checkbox via its update callback - never from a draw)."""
    bl_idname = "muonline_map.toggle_walls"
    bl_label = "\u52fe\u9009\u663e\u793a\u5899\u58c1"

    def execute(self, context):
        p = _props(context)
        from .core import wall_display
        exists = bpy.data.objects.get(wall_display.WALL_OBJ_NAME) is not None
        if p.show_walls and not exists:
            data = state.get_current()
            if data is not None:
                wo = wall_display.update_wall_overlay(data)
                if wo is not None:
                    col = data.scene_collection
                    if col is None:
                        col = context.scene.collection
                    if wo.name not in col.objects:
                        col.objects.link(wo)
        elif not p.show_walls and exists:
            wall_display.remove_wall_overlay()
        return {"FINISHED"}


class MUONLINE_OT_object_light_load(Operator):
    bl_idname = "muonline_map.object_light_load"
    bl_label = "\u8bfb\u53d6\u7269\u4f53\u5149\u7167"
    bl_description = "\u628a\u9009\u4e2d\u7269\u4f53\u7684\u5149\u7167\u5f00\u5173/\u989c\u8272\u8bfb\u5230\u9762\u677f"

    def execute(self, context):
        p = _props(context)
        sel = [o for o in context.selected_objects if "mu_type" in o]
        if not sel:
            self.report({"WARNING"}, "\u8bf7\u5148\u9009\u4e2d\u4e00\u4e2a\u5730\u9762\u7269\u4f53")
            return {"CANCELLED"}
        o = sel[0]
        flags = list(o.get("mu_light_enable") or [1, 1, 1])
        while len(flags) < 3:
            flags.append(1)
        p.obj_light1, p.obj_light2, p.obj_light3 = (
            bool(flags[0]), bool(flags[1]), bool(flags[2]))
        rgb = o.get("mu_light_rgb")
        if rgb:
            p.obj_light_color = (float(rgb[0]), float(rgb[1]), float(rgb[2]))
        return {"FINISHED"}


class MUONLINE_OT_object_light_apply(Operator):
    bl_idname = "muonline_map.object_light_apply"
    bl_label = "\u5e94\u7528\u7269\u4f53\u5149\u7167"
    bl_description = "\u628a\u9762\u677f\u4e0a\u7684\u5149\u7167\u5f00\u5173/\u989c\u8272\u5199\u5165\u9009\u4e2d\u7269\u4f53(\u5bfc\u51fa\u65f6\u751f\u6548)"

    def execute(self, context):
        p = _props(context)
        data = state.get_current()
        if data is None:
            return {"CANCELLED"}
        from .formats.objdata import light_layout_for_version
        n_flags, has_rgb = light_layout_for_version(data.objects.version)
        if n_flags == 0:
            self.report({"WARNING"},
                        "\u8be5\u5730\u56fe\u7684 obj \u7248\u672c\u4e0d\u652f\u6301\u7269\u4f53\u5149\u7167")
            return {"CANCELLED"}
        flags = [1 if p.obj_light1 else 0,
                 1 if p.obj_light2 else 0,
                 1 if p.obj_light3 else 0][:n_flags]
        rgb = tuple(p.obj_light_color) if has_rgb else None
        n = 0
        for o in context.selected_objects:
            if "mu_type" not in o:
                continue
            o["mu_light_enable"] = list(flags)
            if rgb is not None:
                o["mu_light_rgb"] = rgb
            n += 1
        if n == 0:
            self.report({"WARNING"}, "\u8bf7\u5148\u9009\u4e2d\u4e00\u4e2a\u5730\u9762\u7269\u4f53")
            return {"CANCELLED"}
        saver.collect_objects_from_scene(data)
        self.report({"INFO"}, "\u5df2\u5e94\u7528\u7269\u4f53\u5149\u7167: %d" % n)
        return {"FINISHED"}


classes = (MUONLINE_OT_import_map, MUONLINE_OT_export_map,
           MUONLINE_OT_brush_paint, MUONLINE_OT_object_snap,
           MUONLINE_OT_object_add, MUONLINE_OT_object_delete,
           MUONLINE_OT_object_add_model,
           MUONLINE_OT_object_bind_model, MUONLINE_OT_object_clear_model,
           MUONLINE_OT_toggle_walls,
           MUONLINE_OT_object_light_load, MUONLINE_OT_object_light_apply)

