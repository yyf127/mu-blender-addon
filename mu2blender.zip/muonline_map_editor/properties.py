# -*- coding: utf-8 -*-
"""Property group holding the map-editor tool state (panel controls).

NOTE: this file must stay pure ASCII; all Chinese is written as \\uXXXX.
"""

import bpy
from bpy.props import (StringProperty, IntProperty, FloatProperty,
                       BoolProperty, EnumProperty, FloatVectorProperty)

TOOL_MODES = [
    ("HEIGHT", "\u9ad8\u5ea6", "\u5237\u9ad8/\u964d\u4f4e/\u6574\u5e73/\u5e73\u6ed1\u5730\u5f62\u9ad8\u5ea6"),
    ("TILE", "\u74e6\u7247", "\u9009\u7eb9\u7406\u5237 Layer1/Layer2 + \u6df7\u5408"),
    ("LIGHT", "\u5149\u5f71", "\u5237\u5149\u5f71\u989c\u8272 / \u5e73\u6ed1"),
    ("WALL", "\u5899\u58c1", "\u5237\u5899\u58c1\u5c5e\u6027(\u5b89\u5168\u533a/\u7981\u8d70/\u6c34\u7b49)"),
    ("OBJECT", "\u7269\u4f53", "\u79fb\u52a8/\u65cb\u8f6c/\u7f29\u653e/\u589e\u5220\u5730\u9762\u7269\u4f53"),
]

HEIGHT_MODES = [
    ("raise", "\u5237\u9ad8", "\u5411\u4e0a\u62ac\u9ad8\u5730\u5f62"),
    ("lower", "\u964d\u4f4e", "\u5411\u4e0b\u6316\u4f4e\u5730\u5f62"),
    ("flatten", "\u6574\u5e73", "\u62c9\u5e73\u5230\u76ee\u6807\u9ad8\u5ea6"),
    ("smooth", "\u5e73\u6ed1", "\u5e73\u5747\u76f8\u90bb\u9ad8\u5ea6"),
]

WALL_TYPES = [
    ("0x0000", "\u53ef\u884c\u533a Walkable", "TW_CLEAR (\u6e05\u9664\u6240\u6709\u5c5e\u6027)"),
    ("0x0001", "\u5b89\u5168\u533a SafeZone \u84dd", "TW_SAFEZONE"),
    ("0x0002", "\u89d2\u8272\u5360\u7528 Character \u6a59", "TW_CHARACTER"),
    ("0x0004", "\u7981\u884c NoMove \u7ea2", "TW_NOMOVE"),
    ("0x0008", "\u65e0\u5730\u9762 NoGround \u7d2b", "TW_NOGROUND (\u6316\u6d1e)"),
    ("0x0010", "\u6c34 Water \u9752", "TW_WATER"),
    ("0x0020", "\u52a8\u4f5c Action \u7eff", "TW_ACTION"),
    ("0x0040", "\u6052\u5b9a\u9ad8\u5ea6 Height \u6a59", "TW_HEIGHT"),
    ("0x0080", "\u955c\u5934\u62ac\u9ad8 CameraUp \u7c89", "TW_CAMERA_UP"),
    ("0x0100", "\u7981\u653b\u51fb NoAttack \u7c89", "TW_NOATTACKZONE"),
]

LIGHT_MODES = [
    ("set", "\u5237\u8272", "\u7528\u989c\u8272\u5237\u5149\u5f71"),
    ("smooth", "\u5e73\u6ed1", "5 \u683c\u90bb\u57df\u5e73\u5747"),
]


def _toggle_walls_cb():
    try:
        import bpy
        if hasattr(bpy.ops, "muonline_map") and hasattr(
                bpy.ops.muonline_map, "toggle_walls"):
            bpy.ops.muonline_map.toggle_walls()
    except Exception:
        pass
    return None


def _object_type_items(self, context):
    from .core import object_types
    wid = None
    ddir = None
    try:
        wid = int(getattr(self, "world_id", 0) or 0)
        ddir = getattr(self, "data_dir", None)
    except Exception:
        pass
    try:
        return object_types.object_type_enum_for_world(wid, ddir)
    except Exception:
        return object_types.object_type_enum()


class MUONLINE_MAP_Props(bpy.types.PropertyGroup):
    data_dir: StringProperty(
        name="Data \u76ee\u5f55", subtype="DIR_PATH",
        description="MU \u5ba2\u6237\u7aef Data \u76ee\u5f55(\u542b World{id})")
    world_id: IntProperty(name="\u5730\u56fe\u7f16\u53f7", default=1, min=0, max=255)
    world_name: StringProperty(name="\u4e16\u754c", default="")

    tool_mode: EnumProperty(items=TOOL_MODES, name="\u5de5\u5177", default="HEIGHT")
    brush_size: IntProperty(name="\u7b14\u5237\u534a\u5f84", default=2, min=0, max=20)
    brush_strength: FloatProperty(name="\u5f3a\u5ea6", default=10.0, min=0.1, max=200.0)
    height_mode: EnumProperty(items=HEIGHT_MODES, name="\u9ad8\u5ea6\u65b9\u5f0f",
                              default="raise")
    flatten_height: FloatProperty(name="\u6574\u5e73\u9ad8\u5ea6", default=0.0)
    tile_layer: IntProperty(name="\u5c42", default=0, min=0, max=1)
    tile_index: IntProperty(name="\u7eb9\u7406\u7d22\u5f15", default=0, min=0, max=104)
    tile_alpha: FloatProperty(name="\u6df7\u5408\u589e\u91cf", default=0.1, min=0.0, max=1.0)
    light_mode: EnumProperty(items=LIGHT_MODES, name="\u5149\u5f71\u65b9\u5f0f", default="set")
    light_color: FloatVectorProperty(name="\u5149\u5f71\u8272", subtype="COLOR",
                                     default=(1.0, 1.0, 1.0), min=0.0, max=1.0)
    wall_type: EnumProperty(items=WALL_TYPES, name="\u5899\u58c1\u5c5e\u6027", default="0x0001")
    wall_erase: BoolProperty(name="\u64e6\u9664", default=False)

    grid_snap: BoolProperty(name="\u7f51\u683c\u5438\u9644", default=False)
    height_snap: BoolProperty(name="\u8d34\u5730", default=True)
    object_type: EnumProperty(name="\u7269\u4f53\u7c7b\u578b",
                              items=lambda self, ctx: _object_type_items(self, ctx),
                              default=0)
    object_custom_type: IntProperty(name="\u81ea\u5b9a\u4e49\u7c7b\u578b",
                                    default=0, min=0, max=32767)


    # ---- per-object light (record versions >= 1 only) ----
    obj_light1: BoolProperty(name="\u5149\u7167 1", default=True)
    obj_light2: BoolProperty(name="\u5149\u7167 2", default=True)
    obj_light3: BoolProperty(name="\u5149\u7167 3", default=True)
    obj_light_color: FloatVectorProperty(
        name="\u7269\u4f53\u5149\u8272", subtype="COLOR",
        default=(1.0, 1.0, 1.0), min=0.0, max=1.0)

    show_object_models: BoolProperty(
        name="\u663e\u793a\u7269\u4f53\u6a21\u578b", default=True)
    show_walls: BoolProperty(
        name="\u663e\u793a\u5899\u58c1", default=True,
        update=lambda self, ctx: _toggle_walls_cb())

    loaded: BoolProperty(default=False)
    status: StringProperty(name="\u72b6\u6001", default="")


class MUONLINE_TILE_Item(bpy.types.PropertyGroup):
    """One entry in the tile-preview list (just holds the tile index)."""
    idx: IntProperty(name="\u7eb9\u7406\u7d22\u5f15", default=0, min=0, max=255)


classes = (MUONLINE_MAP_Props, MUONLINE_TILE_Item)
