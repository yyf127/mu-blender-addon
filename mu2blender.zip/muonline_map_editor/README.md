# muonline_map_editor

一个**独立的 Blender 插件**,用于快速修改导入的奇迹MU(MU Online)地图。
灵感来自 VD 的 `MuOnline-WorldEditor`(S16e1 游戏内世界编辑器),但完全在 Blender 里运行,
并可直接把修改**写回游戏文件**(ATT/MAP/OZB/OBJ),无需依赖旧插件 `io_scene_muonline`。

## 功能

- **独立读取 Data 文件夹**:`Data/World{id}/` 下的 `EncTerrain{id}.att`(墙壁属性)、
  `EncTerrain{id}.map`(瓦片 Layer1/2 + alpha)、`TerrainLight.OZB`(光影)、
  `TerrainHeight.OZB`(高度)、`EncTerrain{id}.obj`(地面物体)以及瓦片纹理,自动解析并建模。
- **地形场景**:257×257 顶点网格,逐瓦片材质(`terrain_tile_*`,双层混合如游戏公式
  `light * lerp(layer1, layer2, alpha/255)`),Lightmap 顶点色,`mu_alpha` float 属性。
- **笔刷工具**(3D 视口侧栏「MU 地图」,按住 LMB 拖动绘制):
  - 高度:刷高 / 降低 / 整平 / 平滑(半径衰减)
  - 瓦片:选纹理索引刷 Layer1/Layer2 + 混合 alpha,右键擦除 Layer2
  - 光影:刷颜色 / 5 邻域平滑
  - 墙壁:安全区 / 禁走 / 水 / 无地面(挖洞)等位标志
- **物体工具**:地面物体以箭头空物体显示;移动/旋转/缩放后一键贴地+网格吸附,增删物体。
- **写回游戏格式**:把编辑后的数据按**原文件的加密算法/密钥/格式**写回
  `Data/World{id}/`,未修改的地图保存后与源文件**逐字节一致**(已验证)。

- **物体光照**:obj 记录版本 >= 1 的地图带每物体光照开关(Light1/2/3),版本 4+ 还带光照颜色。
  选中地面物体后可「读取」当前光照,改开关/颜色后「应用」,导出时写回 obj。
  未修改的物体记录保持原字节不变。

## 使用

1. Blender 偏好设置启用插件 `muonline_map_editor`。
2. 3D 视口右侧边栏 →「MU 地图」面板。
3. 填 Data 目录(如 `D:\MU\Data`)与地图编号 →「导入地图」。
4. 选工具与笔刷参数 →「开始笔刷」,按住 LMB 在视口地形上拖动绘制。
5. 编辑物体(选中空物体 → 贴地/吸附,或 3D 光标处添加)。
6. 「导出地图」把修改写回。

## 结构

```
muonline_map_editor/
  __init__.py           注册
  properties.py         面板属性
  operators.py          导入/导出/笔刷(maybe modal)/物体算子
  panels.py             侧栏面板
  formats/              ATT/MAP/OZB/OBJ/OZJ/OZT 读写
  formats/teximage.py   TexImage(替代 PIL)+ PNG/TGA/JPEG 编解码(纯 Blender)
  crypto/               文件/ModulusCryptor 加解密(含写回所需的加密侧)
  core/                 editor_data(数据模型) / terrain_build / brushes / state
  importer/load_map.py  独立解析 Data 文件夹
  exporter/save_map.py  写回游戏文件
```

## 无外部依赖(纯 Blender 原生)

**不需要 Pillow**。所有纹理编解码都用 Blender 自带能力 + 自写实现:

| 功能 | 实现方式 |
|---|---|
| 读 Blender 图像 | `image.pixels.foreach_get()` |
| 写 Blender 图像 | 自写 PNG 编码 → `bpy.data.images.load()` → `pack()` |
| JPEG 编码(OZJ) | `image.save_render()` + `render.image_settings.file_format="JPEG"` |
| JPEG 解码(OZJ) | 临时文件 → `bpy.data.images.load()` |
| OZT 编解码 | 纯字节操作(`struct` / `bytearray`) |
| TGA 解码 | 自写(未压缩 + RLE,8/24/32 位) |
| PNG 编解码 | 自写(zlib + 滤波还原) |
| 缩放 | box filter / 最近邻 |

核心容器 `formats/teximage.py::TexImage`(flat RGBA 字节 + 宽高)替代了 `PIL.Image`,
`formats/textures.py` 的所有函数都返回 / 接受 `TexImage`。

> 已在**强制屏蔽 Pillow**(`import PIL` 抛 ImportError)下跑通全部功能:
> 地图导入导出 20/20 文件逐字节一致、BMD 纹理往返、重新导出的 `.OZT` 与原版游戏文件逐字节一致。
## 写回正确性(已验证)

- ModulusCryptor 加密侧(8 种算法: TEA/ThreeWay/CAST5/RC5/RC6/MARS/IDEA/GOST)
  与 C++ WorldEditor `MuCrypto::ModulusEncrypt` 逐字节一致;所有算法组合 round-trip 通过;
  真实文件(含算法字节 0..10)重加密后逐字节一致。
- OZB 写读往返 0 错;未修改的 World1 保存 = 原文件 5/5 逐字节一致。
- 编辑后(高度/瓦片/光影/物体)重载验证数据持久。

> 注:8 位高度格式精度为 1.5 单位/格(游戏本身即如此),高精度修改请配合整平与平滑笔刷。

## 每物体光照(obj extra 字节布局,已用真实数据验证)

obj 记录在 30 字节基础字段之后的额外字节里存光照(对应参考 C++ 编辑器的 `ObjCreatePrepare`):

| obj 版本 | extra 长度 | 布局 |
|---|---|---|
| 0 | 0 | 无光照 |
| 1 | 2 | `[0]`=Light1 `[1]`=Light2 |
| 2 | 3 | `[0..2]`=Light1/2/3 |
| 3 | 15 | `[0..2]`=Light1/2/3,`[3..14]`=零填充 |
| 4 | 16 | `[0..2]`=Light1/2/3,`[3..14]`=光照颜色(3x float32),`[15]`=标志 |

验证(全量 74 个 World):`read_obj`->`write_obj` 对未修改数据 **82/82 逐字节一致**;
编辑单个物体光照后,3546 条记录中**仅 1 条**的 extra 变化。
