# -*- coding: utf-8 -*-
"""Texture codecs for OZJ / OZT / TGA / PNG - no Pillow dependency.

OZT layout: [0..15] 16-byte header | nx(s16)@16 | ny(s16)@18 | depth(u8)@20
            | u1(u8)@21 | @22 BGRA pixels (bottom-up rows).
OZJ layout: [0..23] 24-byte header (isTopDownSort @17) | @24 embedded JPEG
            (the marker may appear slightly earlier, so we scan for FFD8FF).
TGA / PNG : decoded by this module (see teximage.decode_tga_bytes etc).

All decoders return a `TexImage` (flat top-down RGBA bytes) instead of a PIL
image, so the plugin runs on Blender builds without Pillow.
"""

from .teximage import (TexImage, decode_jpeg, decode_png_bytes,
                       decode_tga_bytes, encode_jpeg, scale_to_max,
                       from_blender_image, to_blender_image, save_png)

_JPEG_EXTS = (".jpg", ".jpeg")


def _find_jpeg_start(data, from_=16):
    """Locate the JPEG SOI marker (FF D8 FF) at or after `from_`."""
    n = len(data)
    for i in range(from_, max(from_, n - 2)):
        if data[i] == 0xFF and data[i + 1] == 0xD8 and data[i + 2] == 0xFF:
            return i
    return -1


def decode_ozj(buf):
    """Decode an OZJ into a TexImage.

    Two shapes exist in the wild:
      1. A plain JPEG, or a 24-byte "header" that is really just a copy of the
         JPEG's first 24 bytes.  Byte 17 is then NOT a reliable
         isTopDownSort flag, so we must not flip.
      2. A real OZJ: 24-byte header where byte 17 is isTopDownSort; a 0 means
         the stored JPEG is bottom-up and needs a vertical flip.
    """
    if len(buf) >= 3 and buf[0:3] == b"\xff\xd8\xff":
        jpg_start = _find_jpeg_start(buf, 24)
        if jpg_start == -1:
            jpg_start = 24
        return decode_jpeg(buf[jpg_start:], flip=False)

    jpg_start = _find_jpeg_start(buf, 16)
    if jpg_start == -1:
        raise ValueError("OZJ: JPEG marker not found")
    is_top_down = buf[17] != 0 if len(buf) > 17 else True
    return decode_jpeg(buf[jpg_start:], flip=not is_top_down)


def decode_ozt(buf, power_of_two=False):
    """Decode an OZT (BGRA, bottom-up) into a TexImage."""
    if len(buf) < 22:
        raise ValueError("OZT: file too small")
    nx = int.from_bytes(buf[16:18], "little", signed=True)
    ny = int.from_bytes(buf[18:20], "little", signed=True)
    depth = buf[20]
    # Real OZT files carry a TGA-2.0 heritage: byte 2 and byte 6 are the
    # constant 0x02 and byte 21 is usually 0x08 (verified across 1420
    # shipped .OZT files).  They are not needed for decoding but we
    # round-trip them on write so a re-export matches the original.

    expected = 22 + nx * ny * 4
    if not (0 < nx <= 1024 and 0 < ny <= 1024 and depth == 32
            and expected <= len(buf)):
        raise ValueError("OZT: unsupported header")

    width = _nearest_pow2(nx) if power_of_two else nx
    height = _nearest_pow2(ny) if power_of_two else ny
    tex = TexImage(width, height)            # transparent black
    px = tex.pixels
    off = 22
    for y in range(ny):
        # file rows are bottom-up -> flip into our top-down buffer
        row = (height - 1 - y) if power_of_two else (ny - 1 - y)
        base = row * width * 4
        for x in range(nx):
            b = buf[off]
            g = buf[off + 1]
            r = buf[off + 2]
            a = buf[off + 3]
            off += 4
            i = base + x * 4
            px[i] = r
            px[i + 1] = g
            px[i + 2] = b
            px[i + 3] = a
    return tex


def _nearest_pow2(v):
    p = 1
    while p < v:
        p <<= 1
    return p


def decode_tga(buf):
    return decode_tga_bytes(buf)


def decode_texture(buf, ext):
    """Decode a texture by extension.  ext e.g. '.ozj'/'.ozt'/'.tga'/'.png'."""
    ext = (ext or "").lower()
    if ext == ".ozj":
        return decode_ozj(buf)
    if ext == ".ozt":
        return decode_ozt(buf)
    if ext == ".tga":
        return decode_tga(buf)
    if ext == ".png":
        return decode_png_bytes(buf)
    if ext in _JPEG_EXTS:
        return decode_jpeg(buf, flip=False)
    raise ValueError("unsupported texture extension %s" % ext)


def encode_ozj(tex, top_down=True, quality=95):
    """Encode a TexImage to OZJ bytes (24-byte header + JPEG)."""
    img = tex if top_down else tex.copy().transpose_flip()
    jpg = encode_jpeg(img, quality=quality)

    header = bytearray(24)
    header[0:4] = (0x0A000002).to_bytes(4, "little")   # magic (matches C#)
    header[4:6] = (1).to_bytes(2, "little")            # version
    header[6:10] = b"OZJ\x00"                          # format
    header[17] = 1 if top_down else 0
    return bytes(header) + jpg


def encode_ozt(tex, tga_footer=True):
    """Encode a TexImage to OZT bytes (22-byte header + bottom-up BGRA).

    Two details reproduce the shipped game files exactly:
      * header[2] = header[6] = 0x02 and header[21] = 0x08 -- constant in
        all 1420 reference .OZT files (a TGA-conversion artefact).
      * the file ends with the TGA 2.0 signature area: the 26 bytes
        `00*8 + "TRUEVISION-XFILE." + 00`.  Adding it keeps our output
        byte-for-byte the same size as the original.
    """
    w, h = tex.width, tex.height
    header = bytearray(22)
    header[0:16] = b"\x00" * 16
    header[2] = 2
    header[6] = 2
    header[16:18] = w.to_bytes(2, "little", signed=True)
    header[18:20] = h.to_bytes(2, "little", signed=True)
    header[20] = 32
    header[21] = 8

    px = tex.pixels
    out = bytearray(h * w * 4)
    for y in range(h):
        src = y * w * 4                                   # top-down source
        dst = (h - 1 - y) * w * 4                         # bottom-up file
        for x in range(w):
            si = src + x * 4
            di = dst + x * 4
            out[di] = px[si + 2]        # B
            out[di + 1] = px[si + 1]    # G
            out[di + 2] = px[si]        # R
            out[di + 3] = px[si + 3]    # A
    body = bytes(header) + bytes(out)
    if tga_footer:
        body += b"\x00" * 8 + b"TRUEVISION-XFILE." + b"\x00"
    return body


__all__ = ["TexImage", "decode_ozj", "decode_ozt", "decode_tga",
           "decode_texture", "encode_ozj", "encode_ozt",
           "scale_to_max", "from_blender_image",
           "to_blender_image", "save_png"]
