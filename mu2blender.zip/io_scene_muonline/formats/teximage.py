# -*- coding: utf-8 -*-
"""Pillow-free texture container + JPEG codec for the MU Online plugins.

This module provides `TexImage`, a tiny stand-in for `PIL.Image.Image` that
stores plain RGBA8 pixels, plus helpers to encode/decode JPEG using Blender's
own image IO (`bpy.data.images` / `image.save_render`).  Nothing here imports
Pillow, so the plugins work on Blender builds that ship without it.

Pixel layout
------------
`TexImage.pixels` is a flat `bytearray` of RGBA bytes in **top-down** row
order (row 0 is the top row), matching the OZJ/OZT on-disk layout and the
conventional "image" orientation.  Blender's own `image.pixels` is a float
list in **bottom-up** order, so conversions flip the rows.

Why the flip matters: `bpy.data.images.load()` returns bottom-up pixels while
the texture formats store top-down; getting this backwards shows up as
vertically mirrored textures.
"""

import os
import struct
import tempfile


class TexImage:
    """A minimal RGBA image: flat top-down RGBA bytes + width/height.

    Deliberately mimics the small slice of the `PIL.Image.Image` API the
    plugins use (`size`, `mode`, `width`, `height`, `copy`, `convert`,
    `getpixel`, `putpixel`) so existing call sites keep working.
    """

    __slots__ = ("width", "height", "pixels")

    def __init__(self, width, height, pixels=None):
        self.width = int(width)
        self.height = int(height)
        n = self.width * self.height * 4
        if pixels is None:
            self.pixels = bytearray(n)          # transparent black
        else:
            b = bytearray(pixels)
            if len(b) != n:
                raise ValueError("TexImage: expected %d bytes, got %d"
                                 % (n, len(b)))
            self.pixels = b

    # ---- PIL-compatible surface -------------------------------------------
    @property
    def size(self):
        """(width, height) - matches PIL's 2-tuple."""
        return (self.width, self.height)

    @property
    def mode(self):
        """Always 'RGBA'; kept so `if img.mode != 'RGBA'` style checks work."""
        return "RGBA"

    def copy(self):
        return TexImage(self.width, self.height, self.pixels)

    def convert(self, mode):
        """PIL-compatible no-op: we always store RGBA.

        `convert('RGB')` is used by callers that want to drop alpha before
        JPEG encoding; returning self is correct because our JPEG encoder
        ignores alpha anyway.
        """
        return self

    def getpixel(self, xy):
        """(r, g, b, a) tuple at (x, y) in top-down coordinates."""
        x, y = xy
        i = (int(y) * self.width + int(x)) * 4
        return (self.pixels[i], self.pixels[i + 1],
                self.pixels[i + 2], self.pixels[i + 3])

    def putpixel(self, xy, rgba):
        x, y = xy
        i = (int(y) * self.width + int(x)) * 4
        self.pixels[i:i + 4] = bytes((rgba[0], rgba[1], rgba[2], rgba[3]))

    def transpose_flip(self):
        """Vertical flip, in place (top<->bottom rows)."""
        w = self.width
        stride = w * 4
        px = self.pixels
        for y in range(self.height // 2):
            a = y * stride
            b = (self.height - 1 - y) * stride
            row_a = px[a:a + stride]
            px[a:a + stride] = px[b:b + stride]
            px[b:b + stride] = row_a
        return self

    def resize(self, nw, nh):
        """Nearest-neighbour resize (no external library).

        Only used for preview thumbnails, where the exact filter is
        irrelevant; the real texture downscale uses `scale_to_max()`.
        """
        nw = max(1, int(nw))
        nh = max(1, int(nh))
        out = bytearray(nw * nh * 4)
        pw = self.width
        ph = self.height
        for oy in range(nh):
            sy = min(ph - 1, (oy * ph) // nh)
            src_row = sy * pw * 4
            dst_row = oy * nw * 4
            for ox in range(nw):
                sx = min(pw - 1, (ox * pw) // nw)
                si = src_row + sx * 4
                di = dst_row + ox * 4
                out[di:di + 4] = self.pixels[si:si + 4]
        self.width = nw
        self.height = nh
        self.pixels = out
        return self

    def average_rgba(self):
        """Average (r, g, b, a) each in 0.0-1.0 (used for swatch chips)."""
        px = self.pixels
        n = (self.width * self.height) or 1
        sr = sg = sb = sa = 0
        for i in range(0, len(px), 4):
            sr += px[i]
            sg += px[i + 1]
            sb += px[i + 2]
            sa += px[i + 3]
        return (sr / n / 255.0, sg / n / 255.0, sb / n / 255.0, sa / n / 255.0)

    def has_alpha(self, threshold=0.99):
        """True if any pixel is not fully opaque (used to pick OZJ vs OZT)."""
        px = self.pixels
        cut = int(threshold * 255)
        for i in range(3, len(px), 4):
            if px[i] < cut:
                return True
        return False


# ---------------------------------------------------------------------------
#  Blender <-> TexImage conversion
# ---------------------------------------------------------------------------

def from_blender_image(bimg):
    """Read a `bpy.types.Image` into a TexImage (handles the bottom-up flip).

    Blender stores pixels bottom-up as floats; we store top-down bytes.
    """
    w, h = bimg.size[0], bimg.size[1]
    if w <= 0 or h <= 0:
        raise ValueError("TexImage: Blender image has no pixels")
    buf = [0.0] * (w * h * 4)
    bimg.pixels.foreach_get(buf)
    out = bytearray(w * h * 4)
    stride = w * 4
    for y in range(h):
        # Blender row h-1-y (top-down dest) is stored at source row y
        src = y * stride
        dst = (h - 1 - y) * stride
        for x in range(w * 4):
            v = buf[src + x]
            if v <= 0.0:
                out[dst + x] = 0
            elif v >= 1.0:
                out[dst + x] = 255
            else:
                out[dst + x] = int(v * 255.0 + 0.5)
    return TexImage(w, h, out)


def to_blender_image(tex, name, pack=True, cleanup=True):
    """Create a `bpy.types.Image` from a TexImage via a temporary PNG.

    A temp PNG round-trip is used (rather than writing `.pixels` directly)
    because Blender's own loader also derives the correct colour space and
    alpha mode, which keeps the viewport result identical to loading the
    file by hand.
    """
    import bpy
    tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
    tmp.close()
    try:
        save_png(tmp.name, tex)
        bimg = bpy.data.images.load(tmp.name)
        # PACK before deleting the temp file: without packing Blender tries to
        # reload the (now missing) filepath when uploading to the GPU and logs
        # "Failed to create GPU texture from Blender image" on every redraw.
        if pack:
            try:
                bimg.pack()
            except Exception:
                pass
        try:
            bimg.name = name
        except Exception:
            pass
        return bimg
    finally:
        if cleanup:
            try:
                os.unlink(tmp.name)
            except OSError:
                pass


# ---------------------------------------------------------------------------
#  Minimal PNG writer (RGBA8, top-down -> PNG rows)
# ---------------------------------------------------------------------------

def save_png(path, tex_or_bytes, width=None, height=None):
    """Write an RGBA PNG without Pillow.

    Accepts either a TexImage or a raw bytearray plus explicit width/height.
    """
    import zlib
    # Duck-typing beats isinstance here: a TexImage coming from another
    # copy of this module (e.g. the sibling plugin) is not the same class
    # object, and an isinstance check would wrongly take the else-branch.
    if hasattr(tex_or_bytes, "pixels") and hasattr(tex_or_bytes, "width"):
        w = int(tex_or_bytes.width)
        h = int(tex_or_bytes.height)
        px = bytes(tex_or_bytes.pixels)
    else:
        if width is None or height is None:
            raise ValueError("save_png: raw bytes need width and height")
        w = int(width)
        h = int(height)
        px = bytes(tex_or_bytes)

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    stride = w * 4
    raw = bytearray()
    for y in range(h):
        raw += b"\x00"                      # filter type 0 (None)
        raw += px[y * stride:(y + 1) * stride]

    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr)
           + chunk(b"IDAT", zlib.compress(bytes(raw)))
           + chunk(b"IEND", b""))
    with open(path, "wb") as f:
        f.write(png)
    return png


# ---------------------------------------------------------------------------
#  JPEG encode / decode via Blender (no Pillow)
# ---------------------------------------------------------------------------

def encode_jpeg(tex, quality=90):
    """Encode a TexImage to JPEG bytes using Blender's own encoder.

    Blender has no direct "image -> jpeg bytes" call, so we build a Blender
    image and use `save_render()` with the scene image settings switched to
    JPEG.  The scene settings are restored afterwards so the user's render
    preferences are not permanently changed.
    """
    import bpy
    bimg = to_blender_image(tex, "mu_jpeg_tmp", pack=True, cleanup=False)
    tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
    tmp.close()
    scene = bpy.context.scene
    rs = scene.render.image_settings
    old_fmt = rs.file_format
    old_q = rs.quality
    try:
        rs.file_format = "JPEG"
        rs.quality = max(1, min(100, int(quality)))
        bimg.save_render(tmp.name, scene=scene)
        with open(tmp.name, "rb") as f:
            return f.read()
    finally:
        try:
            rs.file_format = old_fmt
        except Exception:
            rs.file_format = "PNG"
        try:
            rs.quality = old_q
        except Exception:
            pass
        try:
            os.unlink(tmp.name)
        except OSError:
            pass
        try:
            bpy.data.images.remove(bimg)
        except Exception:
            pass


def decode_jpeg(jpg_bytes, flip=False):
    """Decode JPEG bytes into a TexImage using Blender's loader.

    `flip` mirrors the result vertically (used for OZJ files whose
    isTopDownSort flag says the stored JPEG is bottom-up).
    """
    import bpy
    tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
    tmp.close()
    try:
        with open(tmp.name, "wb") as f:
            f.write(jpg_bytes)
        bimg = bpy.data.images.load(tmp.name)
        try:
            tex = from_blender_image(bimg)
        finally:
            try:
                bpy.data.images.remove(bimg)
            except Exception:
                pass
        if flip:
            tex.transpose_flip()
        return tex
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


def decode_png_bytes(buf):
    """Decode PNG bytes into a TexImage (RGBA8 / RGB8, no interlace)."""
    import zlib
    if buf[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("PNG: bad signature")
    pos = 8
    w = h = bitdepth = colortype = 0
    idat = bytearray()
    while pos + 8 <= len(buf):
        (ln,) = struct.unpack_from(">I", buf, pos)
        tag = buf[pos + 4:pos + 8]
        data = buf[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if tag == b"IHDR":
            w, h, bitdepth, colortype, comp, filt, inter = \
                struct.unpack(">IIBBBBB", data)
            if bitdepth != 8 or inter != 0 or colortype not in (2, 6):
                raise ValueError("PNG: unsupported variant")
        elif tag == b"IDAT":
            idat += data
        elif tag == b"IEND":
            break
    if not w or not h:
        raise ValueError("PNG: no IHDR")
    src_ch = 4 if colortype == 6 else 3
    raw = zlib.decompress(bytes(idat))
    stride = w * src_ch
    prev = bytearray(stride)
    out = bytearray(w * h * 4)
    p = 0
    for y in range(h):
        ft = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        bpp = src_ch
        if ft == 1:
            for i in range(bpp, stride):
                line[i] = (line[i] + line[i - bpp]) & 0xFF
        elif ft == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif ft == 3:
            for i in range(stride):
                a = line[i - bpp] if i >= bpp else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 0xFF
        elif ft == 4:
            for i in range(stride):
                a = line[i - bpp] if i >= bpp else 0
                b = prev[i]
                c = prev[i - bpp] if i >= bpp else 0
                pa = abs(b - c)
                pb = abs(a - c)
                pc = abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 0xFF
        prev = line
        drow = y * w * 4
        if src_ch == 4:
            out[drow:drow + stride] = line
        else:
            for x in range(w):
                si = x * 3
                di = drow + x * 4
                out[di] = line[si]
                out[di + 1] = line[si + 1]
                out[di + 2] = line[si + 2]
                out[di + 3] = 255
    return TexImage(w, h, out)


def decode_tga_bytes(buf):
    """Decode an uncompressed / RLE true-colour TGA into a TexImage."""
    if len(buf) < 18:
        raise ValueError("TGA: too small")
    id_len = buf[0]
    cmap_type = buf[1]
    img_type = buf[2]
    (w, h, bpp, desc) = struct.unpack_from("<HHBB", buf, 12)
    if cmap_type != 0 or img_type not in (2, 3, 10, 11):
        raise ValueError("TGA: unsupported type")
    src_ch = bpp // 8
    if src_ch not in (3, 4, 1):
        raise ValueError("TGA: unsupported depth")
    pos = 18 + id_len
    top_down = bool(desc & 0x20)

    def read_px(p):
        if img_type in (3, 11):          # grayscale
            v = buf[p]
            return (v, v, v, 255), p + 1
        if src_ch == 4:
            b, g, r, a = buf[p], buf[p + 1], buf[p + 2], buf[p + 3]
            return (r, g, b, a), p + 4
        b, g, r = buf[p], buf[p + 1], buf[p + 2]
        return (r, g, b, 255), p + 3

    total = w * h
    px_list = []
    if img_type in (2, 3):               # uncompressed
        for _ in range(total):
            c, pos = read_px(pos)
            px_list.append(c)
    else:                                # RLE
        while len(px_list) < total:
            hdr = buf[pos]
            pos += 1
            cnt = (hdr & 0x7F) + 1
            if hdr & 0x80:
                c, pos = read_px(pos)
                px_list.extend([c] * cnt)
            else:
                for _ in range(cnt):
                    c, pos = read_px(pos)
                    px_list.append(c)
        px_list = px_list[:total]

    out = bytearray(w * h * 4)
    for y in range(h):
        dst_y = y if top_down else (h - 1 - y)
        drow = dst_y * w * 4
        srow = y * w
        for x in range(w):
            r, g, b, a = px_list[srow + x]
            i = drow + x * 4
            out[i] = r
            out[i + 1] = g
            out[i + 2] = b
            out[i + 3] = a
    return TexImage(w, h, out)


def scale_to_max(tex, cap):
    """Downscale so neither side exceeds `cap` (box filter, keeps aspect).

    Used because the game's OZJ/OZT readers reject textures above 1024 and
    an oversized texture silently fails to load in-game.
    """
    w, h = tex.width, tex.height
    if max(w, h) <= cap:
        return tex
    ratio = cap / float(max(w, h))
    nw = max(1, int(round(w * ratio)))
    nh = max(1, int(round(h * ratio)))
    out = bytearray(nw * nh * 4)
    for oy in range(nh):
        y0 = (oy * h) // nh
        y1 = max(y0 + 1, ((oy + 1) * h) // nh)
        for ox in range(nw):
            x0 = (ox * w) // nw
            x1 = max(x0 + 1, ((ox + 1) * w) // nw)
            sr = sg = sb = sa = 0
            cnt = 0
            for sy in range(y0, y1):
                base = sy * w * 4
                for sx in range(x0, x1):
                    i = base + sx * 4
                    sr += tex.pixels[i]
                    sg += tex.pixels[i + 1]
                    sb += tex.pixels[i + 2]
                    sa += tex.pixels[i + 3]
                    cnt += 1
            cnt = cnt or 1
            di = (oy * nw + ox) * 4
            out[di] = sr // cnt
            out[di + 1] = sg // cnt
            out[di + 2] = sb // cnt
            out[di + 3] = sa // cnt
    return TexImage(nw, nh, out)
